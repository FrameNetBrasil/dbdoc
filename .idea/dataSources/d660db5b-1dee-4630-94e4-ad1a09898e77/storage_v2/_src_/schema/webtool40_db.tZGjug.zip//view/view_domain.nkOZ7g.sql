create definer = root@localhost view view_domain as
select `webtool40_db`.`domain`.`idDomain`   AS `idDomain`,
       `webtool40_db`.`domain`.`entry`      AS `entry`,
       `webtool40_db`.`domain`.`idEntity`   AS `idEntity`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`
from (`webtool40_db`.`domain` join `webtool40_db`.`entry`
      on (`webtool40_db`.`domain`.`idEntity` = `webtool40_db`.`entry`.`idEntity`));


create definer = root@localhost view view_video_dynamicobject as
select `aor`.`idAnnotationObjectRelation` AS `idVideoDynamicObject`,
       `v`.`idVideo`                      AS `idVideo`,
       `do`.`idDynamicObject`             AS `idDynamicObject`
from ((`webtool40_db`.`annotationobjectrelation` `aor` join `webtool40_db`.`video` `v`
       on (`aor`.`idAnnotationObject1` = `v`.`idAnnotationObject`)) join `webtool40_db`.`dynamicobject` `do`
      on (`aor`.`idAnnotationObject2` = `do`.`idAnnotationObject`));


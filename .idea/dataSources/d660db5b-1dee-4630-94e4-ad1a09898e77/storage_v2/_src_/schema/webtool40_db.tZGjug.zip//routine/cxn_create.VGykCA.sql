create
    definer = root@localhost function cxn_create(par_cxn longtext) returns int
BEGIN
	DECLARE v_nameEn VARCHAR(255);
	DECLARE v_entry VARCHAR(255);
    DECLARE v_abstract INT;
    DECLARE v_active INT;
    DECLARE v_idLanguage INT;
    DECLARE v_idUser INT;
    INSERT INTO entity (type) values ('CXN');
	SET @idEntity = (SELECT last_insert_id());
    SET v_nameEn = JSON_UNQUOTE(JSON_EXTRACT(par_cxn, '$.nameEn'));
    SET v_entry = CONCAT('cxn_',lower(v_nameEn));
    CALL entry_create(v_entry, v_nameEn, @idEntity);
    SET v_abstract = JSON_EXTRACT(par_cxn, '$.abstract');
    SET v_active = JSON_EXTRACT(par_cxn, '$.active');
    SET v_idLanguage = JSON_EXTRACT(par_cxn, '$.idLanguage');
    INSERT INTO construction(entry, active, abstract,idLanguage, idEntity) values (v_entry, v_active, v_abstract,v_idLanguage,@idEntity);
    SET @idConstruction = (SELECT last_insert_id());
    SET v_idUser = JSON_EXTRACT(par_cxn, '$.idUser');
    INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','construction', @idConstruction, v_idUser);
    RETURN @idConstruction;
 END;


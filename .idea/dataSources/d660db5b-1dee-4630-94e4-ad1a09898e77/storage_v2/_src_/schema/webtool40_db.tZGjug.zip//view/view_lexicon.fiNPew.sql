create definer = root@localhost view view_lexicon as
select `wf`.`idWordForm`                      AS `idWordForm`,
       `wf`.`form`                            AS `form`,
       `wf`.`md5`                             AS `md5`,
       `wf`.`altSpell`                        AS `altSpell`,
       `wf`.`idEntity`                        AS `idEntityWF`,
       `lx`.`idLexeme`                        AS `idLexeme`,
       `lx`.`name`                            AS `lexeme`,
       `lx`.`idLanguage`                      AS `idLanguageLX`,
       `lx`.`idEntity`                        AS `idEntityLX`,
       `poslx`.`POS`                          AS `posLX`,
       `le`.`idLexemeEntry`                   AS `idLexemeEntry`,
       `le`.`lexemeOrder`                     AS `lexemeOrder`,
       `le`.`breakBefore`                     AS `breakBefore`,
       `le`.`headWord`                        AS `headWord`,
       `lm`.`idLemma`                         AS `idLemma`,
       `lm`.`name`                            AS `lemma`,
       `lm`.`idEntity`                        AS `idEntityLM`,
       `lm`.`idLanguage`                      AS `idLanguageLM`,
       `lm`.`idPOS`                           AS `idPOSLM`,
       `poslm`.`POS`                          AS `posLM`,
       `webtool40_db`.`lu`.`idLU`             AS `idLU`,
       `webtool40_db`.`lu`.`name`             AS `lu`,
       `webtool40_db`.`lu`.`senseDescription` AS `senseDescription`,
       `webtool40_db`.`lu`.`incorporatedFE`   AS `incorporatedFE`,
       `webtool40_db`.`lu`.`idFrame`          AS `idFrame`,
       `webtool40_db`.`lu`.`idEntity`         AS `idEntityLU`
from ((((((`webtool40_db`.`wordform` `wf` join `webtool40_db`.`lexeme` `lx`
           on (`wf`.`idLexeme` = `lx`.`idLexeme`)) join `webtool40_db`.`pos` `poslx`
          on (`lx`.`idPOS` = `poslx`.`idPOS`)) left join `webtool40_db`.`lexemeentry` `le`
         on (`lx`.`idLexeme` = `le`.`idLexeme`)) left join `webtool40_db`.`lemma` `lm`
        on (`le`.`idLemma` = `lm`.`idLemma`)) left join `webtool40_db`.`pos` `poslm`
       on (`lm`.`idPOS` = `poslm`.`idPOS`)) left join `webtool40_db`.`lu`
      on (`lm`.`idLemma` = `webtool40_db`.`lu`.`idLemma`));


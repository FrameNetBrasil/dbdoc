create definer = root@localhost view view_constrainedby_festandsforfe as
select `e`.`idLanguage`        AS `idLanguage`,
       `e`.`name`              AS `conName`,
       `rt`.`idEntityRelation` AS `idConstraint`,
       `rt`.`idEntity1`        AS `idConstrained`,
       `rt`.`idEntity2`        AS `idConstrainedBy`,
       `rt`.`entity2Type`      AS `constrainedByType`,
       `rt`.`idEntityRelation` AS `idConstraintInstance`,
       `fe`.`name`             AS `name`
from ((`webtool40_db`.`view_relation` `rt` join `webtool40_db`.`entry` `e`
       on (`rt`.`idEntity` = `e`.`idEntity`)) join `webtool40_db`.`view_frameelement` `fe`
      on (`rt`.`idEntity2` = `fe`.`idEntity`))
where `fe`.`idLanguage` = `e`.`idLanguage`
  and `rt`.`relationType` = 'rel_festandsforfe';


create
    definer = root@localhost function video_create(par_json longtext) returns int
BEGIN 
   DECLARE v_title VARCHAR(255);
   DECLARE v_originalFile VARCHAR(255);
   DECLARE v_sha1Name VARCHAR(255);
   DECLARE v_currentURL VARCHAR(255);
   DECLARE v_width INT;
   DECLARE v_height INT;
   DECLARE v_idLanguage INT;
   SET v_title  = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.title'));
   SET v_originalFile  = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.originalFile'));
   SET v_sha1Name  = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.sha1Name'));
   SET v_currentURL  = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.currentURL'));
   SET v_width  = JSON_EXTRACT(par_json, '$.width');
   SET v_height  = JSON_EXTRACT(par_json, '$.height');
   SET v_idLanguage  = JSON_EXTRACT(par_json, '$.idLanguage');
   SET @idAnnotationObject = annotationobject_create(0,'VID');
   INSERT INTO video (title,originalFile,sha1Name,currentURL,width,height,idAnnotationObject,idLanguage)
	values (v_title,v_originalFile,v_sha1Name,v_currentURL,v_width,v_height,@idAnnotationObject,v_idLanguage);
   SET @idVideo = (SELECT last_insert_id());
   RETURN @idVideo;
END;


create
    definer = root@localhost function lemma_create(par_lemma longtext) returns int
BEGIN
		DECLARE v_name VARCHAR(255);
        DECLARE v_idLanguage INT;
        DECLARE v_idPOS INT;
        DECLARE v_idUser INT;
        INSERT INTO entity (type) values ('LEM');
        SET @idEntity = (SELECT last_insert_id());
        SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_lemma, '$.name'));
        SET v_idLanguage = JSON_EXTRACT(par_lemma, '$.idLanguage');
        SET v_idPOS = JSON_EXTRACT(par_lemma, '$.idPOS');
        INSERT INTO lemma(name, idLanguage, idPOS, idEntity) values (v_name, v_idLanguage, v_idPOS, @idEntity);
        SET @idLemma = (SELECT last_insert_id());
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','lemma', @idLemma, v_idUser);
        RETURN @idLemma;
    END;


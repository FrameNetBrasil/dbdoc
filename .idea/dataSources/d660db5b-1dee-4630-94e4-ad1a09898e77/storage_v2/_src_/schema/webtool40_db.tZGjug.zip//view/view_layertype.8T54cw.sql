create definer = root@localhost view view_layertype as
select `lt`.`idLayerType`       AS `idLayerType`,
       `lt`.`entry`             AS `entry`,
       `lt`.`allowsApositional` AS `allowsApositional`,
       `lt`.`isAnnotation`      AS `isAnnotation`,
       `lt`.`layerOrder`        AS `layerOrder`,
       `lt`.`idLayerGroup`      AS `idLayerGroup`,
       `lt`.`idEntity`          AS `idEntity`,
       `e`.`name`               AS `name`,
       `e`.`description`        AS `description`,
       `e`.`idLanguage`         AS `idLanguage`,
       `lg`.`name`              AS `layerGroup`,
       `lg`.`type`              AS `layerGroupType`
from ((`webtool40_db`.`layertype` `lt` join `webtool40_db`.`layergroup` `lg`
       on (`lt`.`idLayerGroup` = `lg`.`idLayerGroup`)) join `webtool40_db`.`entry` `e`
      on (`lt`.`idEntity` = `e`.`idEntity`));


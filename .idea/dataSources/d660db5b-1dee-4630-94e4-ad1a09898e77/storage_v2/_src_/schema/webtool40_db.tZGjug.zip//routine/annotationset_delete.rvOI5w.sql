create
    definer = root@localhost function annotationset_delete(par_idAnnotationSet int, par_idUser int) returns int
BEGIN
		DELETE FROM ascomments WHERE idAnnotationSet = par_idAnnotationSet;
        DELETE FROM annotation WHERE idAnnotationObject IN (
			SELECT idAnnotationObject FROM textspan WHERE idLayer IN (
				SELECT idLayer FROM layer WHERE idAnnotationSet = par_idAnnotationSet
            )
        ); 
		DELETE FROM textspan WHERE idLayer IN (SELECT idLayer FROM layer WHERE idAnnotationSet = par_idAnnotationSet);	
        DELETE FROM layer WHERE idAnnotationSet = par_idAnnotationSet;
		DELETE FROM annotationset WHERE idAnnotationSet = par_idAnnotationSet;
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','annotationset', par_idAnnotationSet,par_idUser);
        RETURN par_idAnnotationSet;
    END;


create definer = root@localhost view view_sentence as
select `s`.`idSentence`         AS `idSentence`,
       `s`.`text`               AS `text`,
       `s`.`paragraphOrder`     AS `paragraphOrder`,
       `s`.`idParagraph`        AS `idParagraph`,
       `s`.`idAnnotationObject` AS `idAnnotationObject`,
       `s`.`idLanguage`         AS `idLanguage`,
       `s`.`idOriginMM`         AS `idOriginMM`,
       `s`.`idRLSLabel`         AS `idRLSLabel`
from ((`webtool40_db`.`sentence` `s` join `webtool40_db`.`rls_label` `l`
       on (`s`.`idRLSLabel` = `l`.`idRLSLabel`)) join `webtool40_db`.`rls_access` `u` on (`u`.`user` = user()))
where `l`.`value` & `u`.`value`;


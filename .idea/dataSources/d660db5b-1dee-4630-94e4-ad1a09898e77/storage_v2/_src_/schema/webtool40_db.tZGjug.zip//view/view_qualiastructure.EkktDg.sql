create definer = root@localhost view view_qualiastructure as
select `qs`.`idQualiaStructure` AS `idQualiaStructure`,
       `f`.`idFrame`            AS `idFrame`,
       `f`.`idEntity`           AS `idEntity`,
       `f`.`name`               AS `name`,
       `f`.`idLanguage`         AS `idLanguage`,
       `qr`.`name`              AS `relation`,
       `qr`.`idQualiaRelation`  AS `idQualiaRelation`
from ((`webtool40_db`.`qualiastructure` `qs` join `webtool40_db`.`view_frame` `f`
       on (`qs`.`idFrame` = `f`.`idFrame`)) join `webtool40_db`.`qualiarelation` `qr`
      on (`qs`.`idQualiaRelation` = `qr`.`idQualiaRelation`));


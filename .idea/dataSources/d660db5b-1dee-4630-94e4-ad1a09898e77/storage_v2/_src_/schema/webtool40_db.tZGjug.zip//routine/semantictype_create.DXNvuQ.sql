create
    definer = root@localhost function semantictype_create(par_semantictype longtext) returns int
BEGIN
	DECLARE v_nameEn VARCHAR(255);
    DECLARE v_name VARCHAR(255);
	DECLARE v_entry VARCHAR(255);
    DECLARE v_idDomain INT;
    DECLARE v_idUser INT;
    INSERT INTO entity (type) values ('STY');
	SET @idEntity = (SELECT last_insert_id());
    SET v_idDomain = JSON_EXTRACT(par_semantictype, '$.idDomain');
    SET v_nameEn = JSON_UNQUOTE(JSON_EXTRACT(par_semantictype, '$.nameEn'));
    SET v_entry = CONCAT('sty_',lower(v_nameEn));
    SET v_name = CONCAT('@',v_nameEn);
    CALL entry_create(v_entry, v_name, @idEntity);
    INSERT INTO semantictype(entry, idEntity, idDomain) values (v_entry, @idEntity, v_idDomain);
    SET @idSemanticType = (SELECT last_insert_id());
    SET v_idUser = JSON_EXTRACT(par_semantictype, '$.idUser');
    INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','semantictype', @idSemanticType, v_idUser);
    RETURN @idSemanticType;
 END;


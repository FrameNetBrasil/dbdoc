create definer = root@localhost view view_object_relation as
select `aor`.`idAnnotationObjectRelation` AS `idAnnotationObjectRelation`,
       `rg`.`entry`                       AS `relationGroup`,
       `rt`.`idRelationType`              AS `idRelationType`,
       `rt`.`entry`                       AS `relationType`,
       `aor`.`idAnnotationObject1`        AS `idAnnotationObject1`,
       `o1`.`type`                        AS `object1Type`,
       `aor`.`idAnnotationObject2`        AS `idAnnotationObject2`,
       `o2`.`type`                        AS `object2Type`
from ((((`webtool40_db`.`annotationobjectrelation` `aor` join `webtool40_db`.`relationtype` `rt`
         on (`aor`.`idRelationType` = `rt`.`idRelationType`)) join `webtool40_db`.`relationgroup` `rg`
        on (`rt`.`idRelationGroup` = `rg`.`idRelationGroup`)) join `webtool40_db`.`annotationobject` `o1`
       on (`aor`.`idAnnotationObject1` = `o1`.`idAnnotationObject`)) join `webtool40_db`.`annotationobject` `o2`
      on (`aor`.`idAnnotationObject2` = `o2`.`idAnnotationObject`));


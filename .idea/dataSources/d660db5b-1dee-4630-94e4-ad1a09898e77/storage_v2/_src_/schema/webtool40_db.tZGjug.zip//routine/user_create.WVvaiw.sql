create
    definer = root@localhost function user_create(par_login varchar(255), par_passMD5 char(32)) returns int
BEGIN
		SET @idGroup = (SELECT idGroup from `group` where name = 'BEGINNER');
		INSERT INTO user (login, passMD5, active, status, idLanguage) VALUES (par_login, par_passMD5, 1, 0, 1);
        SET @idUser = (SELECT last_insert_id());
		INSERT INTO user_group (idUser, idGroup) values (@idUser, @idGroup);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id) VALUES (NOW(),'system','C','user', @idUser);
        RETURN @idUser;
    END;


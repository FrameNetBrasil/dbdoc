create
    definer = root@localhost function fe_delete(par_idFrameElement int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM frameelement WHERE (idFrameElement = par_idFrameElement);
        DELETE FROM entityrelation where (idEntity1 = v_idEntity) OR (idEntity2 = v_idEntity) OR (idEntity3 = v_idEntity);
        DELETE FROM entry where (idEntity = v_idEntity);
        DELETE FROM frameelement where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','frameelement', par_idFrameElement,par_idUser);
        RETURN par_idFrameElement;
    END;


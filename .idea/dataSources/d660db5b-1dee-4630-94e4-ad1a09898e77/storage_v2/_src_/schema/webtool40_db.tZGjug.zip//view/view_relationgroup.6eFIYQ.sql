create definer = root@localhost view view_relationgroup as
select `rg`.`idRelationGroup` AS `idRelationGroup`,
       `rg`.`entry`           AS `entry`,
       `rg`.`idEntity`        AS `idEntity`,
       `e`.`name`             AS `name`,
       `e`.`description`      AS `description`,
       `e`.`idLanguage`       AS `idLanguage`
from (`webtool40_db`.`relationgroup` `rg` join `webtool40_db`.`entry` `e` on (`rg`.`idEntity` = `e`.`idEntity`));


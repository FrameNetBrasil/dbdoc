create
    definer = root@localhost function ce_create(par_idConstruction int, par_name varchar(255), par_idColor int,
                                                par_optional int, par_head int, par_multiple int,
                                                par_idUser int) returns int
BEGIN
		DECLARE entry VARCHAR(255);
        set entry = CONCAT('ce_', LOWER(par_name));
		INSERT INTO entity (type) values ('CE');
        SET @idEntity = (SELECT last_insert_id());
        CALL entry_create(entry, par_name, @idEntity);
        INSERT INTO constructionelement(idConstruction, entry, idColor, optional, head, multiple, active, idEntity) 
			values (par_idConstruction, entry, par_idColor, par_optional, par_head, par_multiple, 1, @idEntity);
        SET @idConstructionElement = (SELECT last_insert_id());
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id) VALUES (NOW(),'user','C','constructionelement', @idConstructionElement);
        RETURN @idConstructionElement;
    END;


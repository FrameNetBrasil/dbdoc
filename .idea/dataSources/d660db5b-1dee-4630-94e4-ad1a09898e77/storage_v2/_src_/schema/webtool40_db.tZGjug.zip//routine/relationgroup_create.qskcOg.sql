create
    definer = root@localhost function relationgroup_create(par_json longtext) returns int
BEGIN 
   DECLARE v_nameEn VARCHAR(255);
   DECLARE v_entry VARCHAR(255);
   DECLARE v_idUser INT;
   INSERT INTO entity (type) values ('RGP');
   SET @idEntity = (SELECT last_insert_id());
   SET v_nameEn = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.nameEn'));
   SET v_entry = CONCAT('rgp_',lower(v_nameEn));
   CALL entry_create(v_entry, v_nameEn, @idEntity);
   INSERT INTO relationgroup(entry,idEntity) values (v_entry, @idEntity);
   SET @idRelationGroup = (SELECT last_insert_id());
   INSERT INTO timeline (tlDateTime,author,operation,tableName,id, idUser) VALUES (NOW(),'user','C','relationgroup', @idRelationGroup, v_idUser);
   RETURN @idRelationGroup;
END;


create definer = root@localhost view view_constrainedby_qualia as
select `e`.`idLanguage`        AS `idLanguage`,
       `qualia`.`name`         AS `conName`,
       `rt`.`idEntityRelation` AS `idConstraint`,
       `rt`.`idEntity1`        AS `idConstrained`,
       `rt`.`idEntity2`        AS `idConstrainedBy`,
       `rt`.`entity2Type`      AS `constrainedByType`,
       `rt`.`idEntityRelation` AS `idConstraintInstance`,
       `fe`.`name`             AS `name`
from (((`webtool40_db`.`view_relation` `rt` join `webtool40_db`.`entry` `e`
        on (`rt`.`idEntity` = `e`.`idEntity`)) join `webtool40_db`.`view_qualia` `qualia`
       on (`rt`.`idEntity3` = `qualia`.`idEntity`)) join `webtool40_db`.`view_frameelement` `fe`
      on (`rt`.`idEntity2` = `fe`.`idEntity`))
where `rt`.`relationType` = 'rel_qualia'
  and `e`.`idLanguage` = `qualia`.`idLanguage`
  and `e`.`idLanguage` = `fe`.`idLanguage`;


create definer = root@localhost view view_entrylanguage as
select `webtool40_db`.`entry`.`idEntry`     AS `idEntry`,
       `webtool40_db`.`entry`.`entry`       AS `entry`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`nick`        AS `nick`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `webtool40_db`.`language`.`language` AS `language`
from (`webtool40_db`.`entry` join `webtool40_db`.`language`
      on (`webtool40_db`.`entry`.`idLanguage` = `webtool40_db`.`language`.`idLanguage`));

-- comment on column view_entrylanguage.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


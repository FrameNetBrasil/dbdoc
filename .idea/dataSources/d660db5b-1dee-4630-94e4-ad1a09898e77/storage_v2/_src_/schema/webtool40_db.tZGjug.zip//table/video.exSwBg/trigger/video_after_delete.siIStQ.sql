create definer = root@localhost trigger video_AFTER_DELETE
    after delete
    on video
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


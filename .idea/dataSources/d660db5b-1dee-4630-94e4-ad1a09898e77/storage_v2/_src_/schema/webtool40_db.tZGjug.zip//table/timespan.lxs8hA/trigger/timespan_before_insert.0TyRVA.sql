create definer = root@localhost trigger timespan_BEFORE_INSERT
    before insert
    on timespan
    for each row
BEGIN
IF (NEW.idAnnotationObject = 0) THEN
	SET NEW.idAnnotationObject = annotationobject_create(0,'TIS');
END IF;    
END;


create definer = root@localhost view view_lemma as
select `webtool40_db`.`lemma`.`idLanguage`                                                    AS `idLanguage`,
       `webtool40_db`.`lemma`.`idLemma`                                                       AS `idLemma`,
       `webtool40_db`.`lemma`.`name`                                                          AS `name`,
       `webtool40_db`.`lemma`.`idPOS`                                                         AS `idPOS`,
       `webtool40_db`.`lemma`.`idEntity`                                                      AS `idEntity`,
       `webtool40_db`.`pos`.`POS`                                                             AS `POS`,
       concat(`webtool40_db`.`lemma`.`name`, ' [', `webtool40_db`.`language`.`language`, ']') AS `fullName`
from ((`webtool40_db`.`lemma` join `webtool40_db`.`pos`
       on (`webtool40_db`.`lemma`.`idPOS` = `webtool40_db`.`pos`.`idPOS`)) join `webtool40_db`.`language`
      on (`webtool40_db`.`lemma`.`idLanguage` = `webtool40_db`.`language`.`idLanguage`));


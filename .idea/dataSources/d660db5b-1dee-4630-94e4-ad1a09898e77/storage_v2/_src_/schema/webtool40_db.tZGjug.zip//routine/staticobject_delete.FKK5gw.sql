create
    definer = root@localhost function staticobject_delete(par_idStaticObject int, par_idUser int) returns int
BEGIN
		DECLARE v_idAnnotationObject INT;
        SELECT idAnnotationObject INTO v_idAnnotationObject FROM staticobject WHERE (idStaticObject = par_idStaticObject);
        DELETE FROM annotation WHERE idAnnotationObject = v_idAnnotationObject;
        DELETE FROM annotationobjectrelation WHERE (idAnnotationObject1 = v_idAnnotationObject) oR (idAnnotationObject2 = v_idAnnotationObject);
		DELETE FROM staticobject WHERE idStaticObject = par_idStaticObject;	
        DELETE FROM annotationobject WHERE idAnnotationObject = v_idAnnotationObject;
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','staticobject', par_idStaticObject,par_idUser);
        RETURN par_idStaticObject;
    END;


create definer = root@localhost view view_frame as
select `webtool40_db`.`frame`.`idFrame`     AS `idFrame`,
       `webtool40_db`.`frame`.`entry`       AS `entry`,
       `webtool40_db`.`frame`.`active`      AS `active`,
       `webtool40_db`.`frame`.`idEntity`    AS `idEntity`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`
from (`webtool40_db`.`frame` join `webtool40_db`.`entry`
      on (`webtool40_db`.`frame`.`idEntity` = `webtool40_db`.`entry`.`idEntity`));


create definer = root@localhost view view_group_user as
select `webtool40_db`.`group`.`idGroup`     AS `idGroup`,
       `webtool40_db`.`group`.`name`        AS `name`,
       `webtool40_db`.`user_group`.`idUser` AS `idUser`
from (`webtool40_db`.`group` join `webtool40_db`.`user_group`
      on (`webtool40_db`.`group`.`idGroup` = `webtool40_db`.`user_group`.`idGroup`));


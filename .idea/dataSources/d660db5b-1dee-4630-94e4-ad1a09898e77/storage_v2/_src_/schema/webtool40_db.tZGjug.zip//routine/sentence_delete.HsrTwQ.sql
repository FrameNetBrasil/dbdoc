create
    definer = root@localhost function sentence_delete(par_idSentence int, par_idUser int) returns int
BEGIN 
   DECLARE v_idAnnotationObject INT;
   DECLARE v_idAnnotationObjectTimespan INT;
   SELECT idAnnotationObject INTO v_idAnnotationObject FROM sentence WHERE (idSentence = par_idSentence);
   SELECT idAnnotationObject2 INTO v_idAnnotationObjectTimespan FROM annotationobjectrelation 
		WHERE (idAnnotationObject1 = v_idAnnotationObject)
        AND (idAnnotationObject2 IN (SELECT idAnnotationObject FROM timespan));
   UPDATE wordmm SET idDocumentSentence = null 
		WHERE (idDocumentSentence IN (SELECT idDocumentSentence from view_document_sentence WHERE (idSentence = par_idSentence)));
   DELETE FROM annotationobjectrelation where (idAnnotationObject1 = v_idAnnotationObject) or (idAnnotationObject2 = v_idAnnotationObject);
   DELETE FROM sentence WHERE (idSentence = par_idSentence);
   DELETE FROM timespan WHERE (idAnnotationObject = v_idAnnotationObjectTimespan);
   DELETE FROM annotationObject where idAnnotationObject IN (v_idAnnotationObject,v_idAnnotationObjectTimespan);	
   INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','sentence', par_idSentence,par_idUser);
   RETURN par_idSentence;
END;


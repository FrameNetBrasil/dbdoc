create
    definer = root@localhost function user_update(par_user longtext) returns int
BEGIN
		DECLARE v_name VARCHAR(255);
        DECLARE v_email VARCHAR(255);
        DECLARE v_idUser INT;
        DECLARE v_idGroup INT;
        SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_user, '$.name'));
        SET v_email = JSON_UNQUOTE(JSON_EXTRACT(par_user, '$.email'));
        SET v_idGroup = JSON_EXTRACT(par_user, '$.idGroup');
        SET v_idUser = JSON_EXTRACT(par_user, '$.idUser');
        DELETE FROM user_group WHERE (idUser = v_idUser);
        INSERT INTO user_group(idGroup, idUser) values (v_idGroup, v_idUser);
        UPDATE user set name = v_name, email = v_email WHERE idUser = v_idUser;
        RETURN v_idUser;
    END;


create definer = root@localhost trigger image_AFTER_DELETE
    after delete
    on image
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


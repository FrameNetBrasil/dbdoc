create definer = root@localhost view view_constrainedby_udfeature as
select `e`.`idLanguage`           AS `idLanguage`,
       `e`.`name`                 AS `conName`,
       `c`.`idConstraint`         AS `idConstraint`,
       `c`.`idConstrained`        AS `idConstrained`,
       `c`.`idConstrainedBy`      AS `idConstrainedBy`,
       `c`.`constrainedByType`    AS `constrainedByType`,
       `c`.`idConstraintInstance` AS `idConstraintInstance`,
       `con`.`info`               AS `name`
from ((`webtool40_db`.`view_constraint` `c` join `webtool40_db`.`entry` `e`
       on (`c`.`idEntity` = `e`.`idEntity`)) join `webtool40_db`.`udfeature` `con`
      on (`c`.`idConstrainedBy` = `con`.`idEntity`));


create definer = root@localhost trigger textspan_BEFORE_INSERT
    before insert
    on textspan
    for each row
BEGIN
IF (NEW.idAnnotationObject = 0) THEN
	SET NEW.idAnnotationObject = annotationobject_create(0,'TXS');
END IF;    
END;


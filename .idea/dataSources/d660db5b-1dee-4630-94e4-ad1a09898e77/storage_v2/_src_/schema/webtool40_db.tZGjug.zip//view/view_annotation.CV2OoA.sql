create definer = root@localhost view view_annotation as
select `a`.`idAnnotation`       AS `idAnnotation`,
       `a`.`idRelationType`     AS `idRelationType`,
       `rt`.`entry`             AS `relationType`,
       `a`.`idEntity`           AS `idEntity`,
       `e`.`type`               AS `entityType`,
       `a`.`idAnnotationObject` AS `idAnnotationObject`,
       `ao`.`type`              AS `objectType`,
       `a`.`idUserTask`         AS `idUserTask`,
       `t`.`idTask`             AS `idTask`,
       `t`.`name`               AS `name`,
       `ut`.`idUser`            AS `idUser`,
       `d`.`idDocument`         AS `idDocument`
from ((((((((`webtool40_db`.`annotation` `a` join `webtool40_db`.`relationtype` `rt`
             on (`a`.`idRelationType` = `rt`.`idRelationType`)) join `webtool40_db`.`entity` `e`
            on (`a`.`idEntity` = `e`.`idEntity`)) join `webtool40_db`.`annotationobject` `ao`
           on (`a`.`idAnnotationObject` = `ao`.`idAnnotationObject`)) join `webtool40_db`.`view_object_relation` `or1`
          on (`ao`.`idAnnotationObject` = `or1`.`idAnnotationObject2`)) join `webtool40_db`.`view_object_relation` `or2`
         on (`or1`.`idAnnotationObject1` = `or2`.`idAnnotationObject2`)) join `webtool40_db`.`document` `d`
        on (`or2`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) join `webtool40_db`.`usertask` `ut`
       on (`a`.`idUserTask` = `ut`.`idUserTask`)) join `webtool40_db`.`task` `t` on (`ut`.`idTask` = `t`.`idTask`));


create definer = root@localhost trigger boundingbox_BEFORE_INSERT
    before insert
    on boundingbox
    for each row
BEGIN
IF (NEW.idAnnotationObject = 0) THEN
	SET NEW.idAnnotationObject = annotationobject_create(0,'BBX');
END IF; 
END;


create definer = root@localhost view view_corpus as
select `webtool40_db`.`corpus`.`idCorpus`   AS `idCorpus`,
       `webtool40_db`.`corpus`.`active`     AS `active`,
       `webtool40_db`.`corpus`.`idEntity`   AS `idEntity`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`
from (`webtool40_db`.`corpus` join `webtool40_db`.`entry`
      on (`webtool40_db`.`corpus`.`idEntity` = `webtool40_db`.`entry`.`idEntity`));


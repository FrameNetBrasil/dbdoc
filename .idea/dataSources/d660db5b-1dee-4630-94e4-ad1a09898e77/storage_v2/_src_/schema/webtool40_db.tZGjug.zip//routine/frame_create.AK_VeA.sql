create
    definer = root@localhost function frame_create(par_frame longtext) returns int
BEGIN
	DECLARE v_nameEn VARCHAR(255);
	DECLARE v_entry VARCHAR(255);
    DECLARE v_idUser INT;
    INSERT INTO entity (type) values ('FRM');
	SET @idEntity = (SELECT last_insert_id());
    SET v_nameEn = JSON_UNQUOTE(JSON_EXTRACT(par_frame, '$.nameEn'));
    SET v_entry = CONCAT('frm_',lower(v_nameEn));
    CALL entry_create(v_entry, v_nameEn, @idEntity);
    INSERT INTO frame(entry, active, defaultName, defaultDefinition, idEntity) values (v_entry, 1, v_nameEn, v_nameEn, @idEntity);
    SET @idFrame = (SELECT last_insert_id());
    SET v_idUser = JSON_EXTRACT(par_frame, '$.idUser');
    INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','frame', @idFrame, v_idUser);
    RETURN @idFrame;
 END;


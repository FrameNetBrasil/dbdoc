create definer = root@localhost trigger dynamicobject_AFTER_DELETE
    after delete
    on dynamicobject
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


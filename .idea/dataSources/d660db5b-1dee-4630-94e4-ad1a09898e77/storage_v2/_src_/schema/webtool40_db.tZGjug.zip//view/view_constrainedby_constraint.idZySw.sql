create definer = root@localhost view view_constrainedby_constraint as
select `e`.`idLanguage`           AS `idLanguage`,
       `e`.`name`                 AS `conName`,
       `c`.`idConstraint`         AS `idConstraint`,
       `c`.`idConstrained`        AS `idConstrained`,
       `c`.`idConstrainedBy`      AS `idConstrainedBy`,
       `c`.`constrainedByType`    AS `constrainedByType`,
       `c`.`idConstraintInstance` AS `idConstraintInstance`,
       `conentry`.`name`          AS `name`
from (((`webtool40_db`.`view_constraint` `c` join `webtool40_db`.`entry` `e`
        on (`c`.`idEntity` = `e`.`idEntity`)) join `webtool40_db`.`view_constraint` `con`
       on (`c`.`idConstrainedBy` = `con`.`idConstraint`)) join `webtool40_db`.`entry` `conentry`
      on (`e`.`idLanguage` = `conentry`.`idLanguage`));


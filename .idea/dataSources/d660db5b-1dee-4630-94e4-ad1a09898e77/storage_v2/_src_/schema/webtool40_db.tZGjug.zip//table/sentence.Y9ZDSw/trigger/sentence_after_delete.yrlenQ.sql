create definer = root@localhost trigger sentence_AFTER_DELETE
    after delete
    on sentence
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


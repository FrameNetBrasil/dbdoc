create
    definer = root@localhost function lu_delete(par_idLU int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM lu WHERE (idLU = par_idLU);
        DELETE FROM entityrelation where (idEntity1 = v_idEntity) OR (idEntity2 = v_idEntity) OR (idEntity3 = v_idEntity);
        DELETE FROM entry where (idEntity = v_idEntity);
        DELETE FROM lu where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','lu', par_idLU,par_idUser);
        RETURN par_idLU;
    END;


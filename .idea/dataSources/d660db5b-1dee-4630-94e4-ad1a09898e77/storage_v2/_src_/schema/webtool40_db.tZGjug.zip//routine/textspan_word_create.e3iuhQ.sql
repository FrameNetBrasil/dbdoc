create
    definer = root@localhost function textspan_word_create(par_json longtext) returns int
BEGIN 
   DECLARE v_startWord INT;
   DECLARE v_endWord INT;
   SET v_startWord = JSON_EXTRACT(par_json, '$.startWord');
   SET v_endWord = JSON_EXTRACT(par_json, '$.endWord');
   SET @idAnnotationObject = annotationobject_create(0,'TXS');
   INSERT INTO textspan (startWord, endWord) values (v_startWord, v_endWord);
   SET @idTextSpan = (SELECT last_insert_id());
   RETURN @idTextSpan;
END;


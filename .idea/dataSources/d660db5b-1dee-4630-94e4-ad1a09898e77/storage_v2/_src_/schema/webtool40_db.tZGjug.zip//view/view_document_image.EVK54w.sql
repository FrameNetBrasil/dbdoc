create definer = root@localhost view view_document_image as
select `aor`.`idAnnotationObjectRelation` AS `idDocumentImage`,
       `d`.`idDocument`                   AS `idDocument`,
       `i`.`idImage`                      AS `idImage`
from ((`webtool40_db`.`annotationobjectrelation` `aor` join `webtool40_db`.`document` `d`
       on (`aor`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) join `webtool40_db`.`image` `i`
      on (`aor`.`idAnnotationObject2` = `i`.`idAnnotationObject`));


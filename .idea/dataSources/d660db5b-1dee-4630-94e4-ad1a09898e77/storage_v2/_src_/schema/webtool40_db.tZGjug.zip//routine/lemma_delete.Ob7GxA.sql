create
    definer = root@localhost function lemma_delete(par_idLemma int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM lemma WHERE (idLemma = par_idLemma);
        DELETE FROM lexemeentry where (idLemma = par_idLemma);
        DELETE FROM lemma where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','lemma', par_idLemma,par_idUser);
        RETURN par_idLemma;
    END;


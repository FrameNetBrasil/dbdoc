create definer = root@localhost trigger image_BEFORE_INSERT
    before insert
    on image
    for each row
BEGIN
IF (NEW.idAnnotationObject = 0) THEN
	SET NEW.idAnnotationObject = annotationobject_create(0,'IMG');
END IF;    
END;


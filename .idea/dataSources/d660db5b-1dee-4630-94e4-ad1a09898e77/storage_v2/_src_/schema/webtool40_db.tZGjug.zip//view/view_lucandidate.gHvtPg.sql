create definer = root@localhost view view_lucandidate as
select `frame`.`name`                      AS `frameName`,
       `lu`.`frameCandidate`               AS `frameCandidate`,
       `frame`.`idFrame`                   AS `idFrame`,
       `lu`.`idLUCandidate`                AS `idLUCandidate`,
       `lu`.`name`                         AS `name`,
       `lu`.`senseDescription`             AS `senseDescription`,
       `lu`.`idLemma`                      AS `idLemma`,
       `lu`.`discussion`                   AS `discussion`,
       `lu`.`idDocument`                   AS `idDocument`,
       `lu`.`idDocumentSentence`           AS `idDocumentSentence`,
       `lu`.`idBoundingBox`                AS `idBoundingBox`,
       `lu`.`idUser`                       AS `idUser`,
       `lu`.`incorporatedFE`               AS `incorporatedFE`,
       `lu`.`createdAt`                    AS `createdAt`,
       `webtool40_db`.`lemma`.`name`       AS `lemmaName`,
       `webtool40_db`.`lemma`.`idPOS`      AS `idPOS`,
       `webtool40_db`.`lemma`.`idLanguage` AS `idLanguage`,
       `webtool40_db`.`user`.`name`        AS `userName`,
       `webtool40_db`.`user`.`email`       AS `email`
from (((`webtool40_db`.`lucandidate` `lu` join `webtool40_db`.`lemma`
        on (`lu`.`idLemma` = `webtool40_db`.`lemma`.`idLemma`)) join `webtool40_db`.`user`
       on (`lu`.`idUser` = `webtool40_db`.`user`.`idUser`)) left join `webtool40_db`.`view_frame` `frame`
      on (`lu`.`idFrame` = `frame`.`idFrame`))
where `webtool40_db`.`lemma`.`idLanguage` = `frame`.`idLanguage`
   or `frame`.`idLanguage` is null;


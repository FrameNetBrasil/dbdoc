create definer = root@localhost view view_video_wordmm as
select `w`.`idWordMM`           AS `idWordMM`,
       `w`.`word`               AS `word`,
       `w`.`startTime`          AS `startTime`,
       `w`.`endTime`            AS `endTime`,
       `w`.`origin`             AS `origin`,
       `v`.`idVideo`            AS `idVideo`,
       `w`.`idDocumentSentence` AS `idDocumentSentence`,
       `ds`.`idDocument`        AS `idDocument`,
       `ds`.`idSentence`        AS `idSentence`
from ((`webtool40_db`.`wordmm` `w` join `webtool40_db`.`video` `v`
       on (`w`.`idVideo` = `v`.`idVideo`)) left join `webtool40_db`.`view_document_sentence` `ds`
      on (`w`.`idDocumentSentence` = `ds`.`idDocumentSentence`));


create
    definer = root@localhost function boundingbox_dynamic_create(par_json longtext) returns int
BEGIN 
   DECLARE v_frameNumber INT;
   DECLARE v_frameTime FLOAT;
   DECLARE v_x INT;
   DECLARE v_y INT;
   DECLARE v_width INT;
   DECLARE v_height INT;
   DECLARE v_blocked INT;
   DECLARE v_idDynamicObject INT;
   DECLARE v_idAnnotationObject1 INT;
   DECLARE v_idAnnotationObject2 INT;
   SET v_frameNumber = JSON_EXTRACT(par_json, '$.frameNumber');
   SET v_frameTime = JSON_EXTRACT(par_json, '$.frameTime');
   SET v_x = JSON_EXTRACT(par_json, '$.x');
   SET v_y = JSON_EXTRACT(par_json, '$.y');
   SET v_width = JSON_EXTRACT(par_json, '$.width');
   SET v_height = JSON_EXTRACT(par_json, '$.height');
   SET v_blocked = JSON_EXTRACT(par_json, '$.blocked');
   SET @idAnnotationObject2 = annotationobject_create(0,'BBX');
   INSERT INTO boundingbox (frameNumber, frameTime, x, y, width, height, blocked, idAnnotationObject) values (v_frameNumber, v_frameTime, v_x, v_y, v_width, v_height, v_blocked, @idAnnotationObject2);
   SET @idBoundingBox = (SELECT last_insert_id());
   SET v_idDynamicObject = JSON_EXTRACT(par_json, '$.idDynamicObject');
   SELECT idAnnotationObject INTO v_idAnnotationObject1 FROM dynamicobject where (idDynamicObject = v_idDynamicObject);
   SET @idAnnotationObjectRelation = objectrelation_create(JSON_OBJECT('idAnnotationObject1', v_idAnnotationObject1, 'idAnnotationObject2', @idAnnotationObject2, 'relationType', 'rel_dynobj_bbox'));
   RETURN @idBoundingBox;
END;


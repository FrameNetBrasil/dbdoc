create definer = root@localhost view view_constructionelement as
select `webtool40_db`.`construction`.`idConstruction` AS `idConstruction`,
       `webtool40_db`.`construction`.`entry`          AS `constructionEntry`,
       `webtool40_db`.`construction`.`idEntity`       AS `constructionIdEntity`,
       `ce`.`idConstructionElement`                   AS `idConstructionElement`,
       `ce`.`entry`                                   AS `entry`,
       `ce`.`active`                                  AS `active`,
       `ce`.`idEntity`                                AS `idEntity`,
       `ce`.`idColor`                                 AS `idColor`,
       `ce`.`optional`                                AS `optional`,
       `ce`.`head`                                    AS `head`,
       `ce`.`multiple`                                AS `multiple`,
       `webtool40_db`.`entry`.`name`                  AS `name`,
       `webtool40_db`.`entry`.`description`           AS `description`,
       `webtool40_db`.`entry`.`idLanguage`            AS `idLanguage`
from ((`webtool40_db`.`constructionelement` `ce` join `webtool40_db`.`construction`
       on (`ce`.`idConstruction` = `webtool40_db`.`construction`.`idConstruction`)) join `webtool40_db`.`entry`
      on (`ce`.`idEntity` = `webtool40_db`.`entry`.`idEntity`));


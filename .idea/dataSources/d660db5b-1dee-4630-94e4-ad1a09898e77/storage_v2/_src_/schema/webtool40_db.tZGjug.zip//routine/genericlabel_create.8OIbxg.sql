create
    definer = root@localhost function genericlabel_create(par_genericlabel longtext) returns int
BEGIN
	DECLARE v_name VARCHAR(255);
	DECLARE v_definition TEXT;
    DECLARE v_example TEXT;
    DECLARE v_idColor INT;
    DECLARE v_idLanguage INT;
    DECLARE v_idLayerType INT;
    DECLARE v_idUser INT;
    INSERT INTO entity (type) values ('GLB');
	SET @idEntity = (SELECT last_insert_id());
    SET v_idColor = JSON_EXTRACT(par_genericlabel, '$.idColor');
    SET v_idLanguage = JSON_EXTRACT(par_genericlabel, '$.idLanguage');
    SET v_idLayerType = JSON_EXTRACT(par_genericlabel, '$.idLayerType');
    SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_genericlabel, '$.name'));
    SET v_definition = JSON_UNQUOTE(JSON_EXTRACT(par_genericlabel, '$.definition'));
    SET v_example = JSON_UNQUOTE(JSON_EXTRACT(par_genericlabel, '$.example'));
    INSERT INTO genericlabel(name,definition, example, idEntity, idColor, idLanguage, idLayerType) values (v_name, v_definition, v_example, @idEntity, v_idColor, v_idLanguage, v_idLayerType);
    SET @idGenericLabel = (SELECT last_insert_id());
    SET v_idUser = JSON_EXTRACT(par_genericlabel, '$.idUser');
    INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','genericlabel', @idGenericLabel, v_idUser);
    RETURN @idGenericLabel;
 END;


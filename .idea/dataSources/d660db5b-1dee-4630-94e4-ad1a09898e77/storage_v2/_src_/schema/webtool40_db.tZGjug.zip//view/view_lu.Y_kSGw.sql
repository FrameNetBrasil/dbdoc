create definer = root@localhost view view_lu as
select `frame`.`idLanguage`                   AS `idLanguageFrame`,
       `frame`.`idFrame`                      AS `idFrame`,
       `frame`.`idEntity`                     AS `frameIdEntity`,
       `frame`.`name`                         AS `frameName`,
       `webtool40_db`.`lu`.`idLU`             AS `idLU`,
       `webtool40_db`.`lu`.`name`             AS `name`,
       `webtool40_db`.`lu`.`senseDescription` AS `senseDescription`,
       `webtool40_db`.`lu`.`active`           AS `active`,
       `webtool40_db`.`lu`.`importNum`        AS `importNum`,
       `webtool40_db`.`lu`.`incorporatedFE`   AS `incorporatedFE`,
       `webtool40_db`.`lu`.`idEntity`         AS `idEntity`,
       `webtool40_db`.`lu`.`idLemma`          AS `idLemma`,
       `webtool40_db`.`lemma`.`name`          AS `lemmaName`,
       `webtool40_db`.`lemma`.`idPOS`         AS `idPOS`,
       `webtool40_db`.`lemma`.`idLanguage`    AS `idLanguage`
from ((`webtool40_db`.`lu` join `webtool40_db`.`view_frame` `frame`
       on (`webtool40_db`.`lu`.`idFrame` = `frame`.`idFrame`)) join `webtool40_db`.`lemma`
      on (`webtool40_db`.`lu`.`idLemma` = `webtool40_db`.`lemma`.`idLemma`))
where `webtool40_db`.`lemma`.`idLanguage` = `frame`.`idLanguage`;


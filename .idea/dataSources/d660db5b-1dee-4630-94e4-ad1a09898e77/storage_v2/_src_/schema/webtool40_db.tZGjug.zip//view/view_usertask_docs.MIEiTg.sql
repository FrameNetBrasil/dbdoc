create definer = root@localhost view view_usertask_docs as
select distinct `utd`.`idUserTaskDocument` AS `idUserTaskDocument`,
                `ut`.`idUserTask`          AS `idUserTask`,
                `ut`.`isActive`            AS `isActive`,
                `ut`.`isIgnore`            AS `isIgnore`,
                `u`.`idUser`               AS `idUser`,
                `u`.`login`                AS `login`,
                `u`.`name`                 AS `userName`,
                `u`.`email`                AS `email`,
                `t`.`idTask`               AS `idTask`,
                `t`.`name`                 AS `taskName`,
                `d`.`idDocument`           AS `idDocument`,
                `d`.`name`                 AS `documentName`,
                `c`.`idCorpus`             AS `idCorpus`,
                `c`.`name`                 AS `corpusName`,
                `c`.`idLanguage`           AS `idLanguage`
from (((((`webtool40_db`.`usertask` `ut` join `webtool40_db`.`user` `u`
          on (`ut`.`idUser` = `u`.`idUser`)) join `webtool40_db`.`task` `t`
         on (`ut`.`idTask` = `t`.`idTask`)) join `webtool40_db`.`usertask_document` `utd`
        on (`ut`.`idUserTask` = `utd`.`idUserTask`)) join `webtool40_db`.`view_corpus` `c`
       on (`utd`.`idCorpus` = `c`.`idCorpus`)) left join `webtool40_db`.`view_document` `d`
      on (`utd`.`idDocument` = `d`.`idDocument`))
where `d`.`idLanguage` is null
   or `c`.`idLanguage` = `d`.`idLanguage` and `d`.`idLanguage` is not null;


create definer = root@localhost view view_coretype as
select `ti`.`entry`    AS `entry`,
       `ti`.`info`     AS `info`,
       `ti`.`flag`     AS `flag`,
       `ti`.`idType`   AS `idType`,
       `ti`.`idColor`  AS `idColor`,
       `ti`.`idEntity` AS `idEntity`
from (`webtool40_db`.`typeinstance` `ti` join `webtool40_db`.`type` on (`ti`.`idType` = `webtool40_db`.`type`.`idType`))
where `webtool40_db`.`type`.`entry` = 'typ_coretype';


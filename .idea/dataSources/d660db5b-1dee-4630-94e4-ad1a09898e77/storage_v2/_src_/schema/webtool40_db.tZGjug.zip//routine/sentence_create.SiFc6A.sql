create
    definer = root@localhost function sentence_create(par_json longtext) returns int
BEGIN 
   DECLARE v_text TEXT;
   DECLARE v_idDocument INT;
   DECLARE v_idLanguage INT;
   DECLARE v_idUser INT;
   DECLARE v_idAnnotationObjectDocument INT;
   SET v_text = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.text'));
   SET v_idDocument = JSON_EXTRACT(par_json, '$.idDocument');
   SET v_idLanguage = JSON_EXTRACT(par_json, '$.idLanguage');
   SET v_idUser = JSON_EXTRACT(par_json, '$.idUser');
   SET @idAnnotationObject = annotationobject_create(0,'SEN');
   INSERT INTO sentence (text, idAnnotationObject, idLanguage) values (v_text, @idAnnotationObject, v_idLanguage);
   SET @idSentence = (SELECT last_insert_id());
   SELECT idAnnotationObject INTO v_idAnnotationObjectDocument FROM document where (idDocument = v_idDocument);
   SET @idAnnotationObjectRelation = objectrelation_create(JSON_OBJECT('idAnnotationObject1', v_idAnnotationObjectDocument, 'idAnnotationObject2', @idAnnotationObject, 'relationType', 'rel_document_sentence'));
   INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','sentence', @idSentence, v_idUser);
   RETURN @idSentence;
END;


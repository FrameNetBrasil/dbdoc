create
    definer = root@localhost function timespan_create(par_json longtext) returns int
BEGIN 
   DECLARE v_startTime FLOAT;
   DECLARE v_endTime FLOAT;
   SET v_startTime = JSON_EXTRACT(par_json, '$.startTime');
   SET v_endTime = JSON_EXTRACT(par_json, '$.endTime');
   SET @idAnnotationObject = annotationobject_create(0,'TMS');
   INSERT INTO timespan (startTime, endTime, idAnnotationObject) values (v_startTime, v_endTime, @idAnnotationObject);
   SET @idTimeSpan = (SELECT last_insert_id());
   RETURN @idTimeSpan;
END;


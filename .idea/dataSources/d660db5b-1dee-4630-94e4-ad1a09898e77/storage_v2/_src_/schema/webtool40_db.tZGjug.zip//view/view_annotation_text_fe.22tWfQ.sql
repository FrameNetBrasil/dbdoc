create definer = root@localhost view view_annotation_text_fe as
select `a`.`idAnnotation`         AS `idAnnotation`,
       `ts`.`idTextSpan`          AS `idTextSpan`,
       `ts`.`startChar`           AS `startChar`,
       `ts`.`endChar`             AS `endChar`,
       `ts`.`multi`               AS `multi`,
       `ts`.`idLayer`             AS `idLayer`,
       `ts`.`idInstantiationType` AS `idInstantiationType`,
       `ts`.`idAnnotationObject`  AS `idAnnotationObject`,
       `fe`.`idFrame`             AS `idFrame`,
       `fe`.`idFrameElement`      AS `idFrameElement`,
       `fe`.`idEntity`            AS `idEntity`,
       `fe`.`idColor`             AS `idColor`,
       `fe`.`coreType`            AS `coreType`,
       `fe`.`name`                AS `name`,
       `fe`.`idLanguage`          AS `idLanguage`,
       `l`.`idAnnotationSet`      AS `idAnnotationSet`,
       `l`.`idLayerType`          AS `idLayerType`,
       `lt`.`layerOrder`          AS `layerOrder`,
       `lt`.`entry`               AS `layerTypeEntry`,
       `lt`.`idEntity`            AS `layerTypeIdEntity`
from ((((`webtool40_db`.`textspan` `ts` join `webtool40_db`.`annotation` `a`
         on (`ts`.`idAnnotationObject` = `a`.`idAnnotationObject`)) join `webtool40_db`.`view_frameelement` `fe`
        on (`a`.`idEntity` = `fe`.`idEntity`)) join `webtool40_db`.`layer` `l`
       on (`ts`.`idLayer` = `l`.`idLayer`)) join `webtool40_db`.`layertype` `lt`
      on (`l`.`idLayerType` = `lt`.`idLayerType`));


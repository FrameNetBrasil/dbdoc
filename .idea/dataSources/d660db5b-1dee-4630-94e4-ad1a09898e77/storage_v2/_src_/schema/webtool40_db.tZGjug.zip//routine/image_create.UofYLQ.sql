create
    definer = root@localhost function image_create(par_json longtext) returns int
BEGIN 
   DECLARE v_name VARCHAR(255);
   DECLARE v_currentURL VARCHAR(255);
   DECLARE v_width INT;
   DECLARE v_height INT;
   DECLARE v_depth INT;
   DECLARE v_idLanguage INT;
   SET v_name  = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.name'));
   SET v_currentURL  = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.currentURL'));
   SET v_width  = JSON_EXTRACT(par_json, '$.width');
   SET v_height  = JSON_EXTRACT(par_json, '$.height');
   SET v_depth  = JSON_EXTRACT(par_json, '$.depth');
   SET v_idLanguage  = JSON_EXTRACT(par_json, '$.idLanguage');
   SET @idAnnotationObject = annotationobject_create(0,'IMG');
   INSERT INTO image (name,currentURL,width,height,depth,idAnnotationObject,idLanguage)
	values (v_name,v_currentURL,v_width,v_height,v_depth,@idAnnotationObject,v_idLanguage);
   SET @idImage = (SELECT last_insert_id());
   RETURN @idImage;
END;


create definer = root@localhost view view_staticobject_textspan as
select `webtool40_db`.`staticobject`.`idStaticObject`     AS `idStaticObject`,
       `webtool40_db`.`staticobject`.`idAnnotationObject` AS `idAnnotationObject`,
       `webtool40_db`.`staticobject`.`name`               AS `name`,
       `webtool40_db`.`staticobject`.`scene`              AS `scene`,
       `webtool40_db`.`staticobject`.`nobndbox`           AS `nobndbox`,
       `ts`.`startWord`                                   AS `startWord`,
       `ts`.`endWord`                                     AS `endWord`,
       `d`.`idDocument`                                   AS `idDocument`,
       `s`.`idSentence`                                   AS `idSentence`
from (((((((`webtool40_db`.`staticobject` join `webtool40_db`.`annotationobject` `sob` on (`sob`.`idAnnotationObject` =
                                                                                           `webtool40_db`.`staticobject`.`idAnnotationObject`)) join `webtool40_db`.`annotationobject` `txs`
           on (`sob`.`externalId` = `txs`.`externalId`)) join `webtool40_db`.`textspan` `ts`
          on (`txs`.`idAnnotationObject` = `ts`.`idAnnotationObject`)) join `webtool40_db`.`view_object_relation` `r`
         on (`ts`.`idAnnotationObject` = `r`.`idAnnotationObject2`)) join `webtool40_db`.`view_object_relation` `ds`
        on (`ds`.`idAnnotationObject2` = `r`.`idAnnotationObject1`)) join `webtool40_db`.`document` `d`
       on (`ds`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) join `webtool40_db`.`sentence` `s`
      on (`r`.`idAnnotationObject1` = `s`.`idAnnotationObject`));


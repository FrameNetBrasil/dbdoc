create definer = root@localhost view view_typeinstance as
select `ti`.`idTypeInstance`                AS `idTypeInstance`,
       `ti`.`entry`                         AS `entry`,
       `ti`.`idEntity`                      AS `idEntity`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`nick`        AS `nick`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`
from (`webtool40_db`.`typeinstance` `ti` join `webtool40_db`.`entry`
      on (`ti`.`idEntity` = `webtool40_db`.`entry`.`idEntity`));


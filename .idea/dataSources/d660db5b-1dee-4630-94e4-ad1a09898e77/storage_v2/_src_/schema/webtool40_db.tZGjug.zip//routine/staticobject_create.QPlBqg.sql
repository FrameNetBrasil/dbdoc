create
    definer = root@localhost function staticobject_create(par_json longtext) returns int
BEGIN 
   DECLARE v_name VARCHAR(255);
   DECLARE v_scene INT;
   DECLARE v_nobndbox INT;
   DECLARE v_idFlickr30kEntitiesChain INT;
   DECLARE v_idUser INT;
   SET v_name  = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.name'));
   SET v_scene = JSON_EXTRACT(par_json, '$.scene');
   SET v_nobndbox = JSON_EXTRACT(par_json, '$.nobndbox');
   SET v_idFlickr30kEntitiesChain = JSON_EXTRACT(par_json, '$.idFlickr30kEntitiesChain');
   SET v_idUser = JSON_EXTRACT(par_json, '$.idUser');
   SET @idAnnotationObject = annotationobject_create(0,'SOB');
   INSERT INTO staticobject (name,scene,nobndbox,idFlickr30kEntitiesChain,idAnnotationObject)
	values (v_name,v_scene,v_nobndbox,v_idFlickr30kEntitiesChain,@idAnnotationObject);
   SET @idStaticObject = (SELECT last_insert_id());
   INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','staticobject', @idStaticObject,v_idUser);
   RETURN @idStaticObject;
END;


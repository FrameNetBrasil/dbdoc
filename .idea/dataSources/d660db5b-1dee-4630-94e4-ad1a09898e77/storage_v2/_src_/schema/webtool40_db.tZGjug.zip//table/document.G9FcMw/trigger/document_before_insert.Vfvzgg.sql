create definer = root@localhost trigger document_BEFORE_INSERT
    before insert
    on document
    for each row
BEGIN
	SET NEW.idAnnotationObject = annotationobject_create(0,'DOC');
END;


create
    definer = root@localhost procedure entry_create(IN par_entry varchar(255), IN par_name varchar(255),
                                                    IN par_idEntity int)
BEGIN
        DECLARE idLanguageE INT;
		DECLARE done INT DEFAULT FALSE;
		DECLARE cursorLanguage CURSOR FOR SELECT idLanguage FROM language;
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

		OPEN cursorLanguage;
		read_loop: LOOP
			FETCH cursorLanguage INTO idLanguageE;
			IF done THEN
				LEAVE read_loop;
			END IF;
			INSERT INTO entry (idLanguage, entry, name, description, idEntity) values (idLanguageE, par_entry, par_name, par_name, par_idEntity);
		END LOOP;
		CLOSE cursorLanguage;
    END;


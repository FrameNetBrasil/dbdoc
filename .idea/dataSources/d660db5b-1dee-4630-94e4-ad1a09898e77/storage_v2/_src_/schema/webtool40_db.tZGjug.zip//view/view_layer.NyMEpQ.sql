create definer = root@localhost view view_layer as
select `l`.`idLayer`                        AS `idLayer`,
       `l`.`rank`                           AS `rank`,
       `l`.`idAnnotationSet`                AS `idAnnotationSet`,
       `l`.`idLayerType`                    AS `idLayerType`,
       `lt`.`entry`                         AS `entry`,
       `lt`.`idEntity`                      AS `idEntity`,
       `lt`.`layerOrder`                    AS `layerOrder`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`
from ((`webtool40_db`.`layer` `l` join `webtool40_db`.`layertype` `lt`
       on (`l`.`idLayerType` = `lt`.`idLayerType`)) join `webtool40_db`.`entry`
      on (`lt`.`idEntity` = `webtool40_db`.`entry`.`idEntity`));


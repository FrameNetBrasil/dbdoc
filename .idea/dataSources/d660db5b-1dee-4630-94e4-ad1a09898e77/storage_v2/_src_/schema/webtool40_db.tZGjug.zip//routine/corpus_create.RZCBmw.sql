create
    definer = root@localhost function corpus_create(par_json longtext) returns int
BEGIN 
   DECLARE v_entry VARCHAR(255);
   DECLARE v_name VARCHAR(255);
   DECLARE v_idUser INT;
   INSERT INTO entity (type) values ('CRP');
   SET @idEntity = (SELECT last_insert_id());
   SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.name'));
   SET v_idUser = JSON_EXTRACT(par_json, '$.idUser');
   SET v_entry = LOWER(CONCAT('crp_', v_name));
   CALL entry_create(v_entry, v_name, @idEntity);
   INSERT INTO corpus(entry,active,idEntity) values (v_entry, 1, @idEntity);
   SET @idCorpus = (SELECT last_insert_id());
   INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','corpus', @idCorpus, v_idUser);
   RETURN @idCorpus;
END;


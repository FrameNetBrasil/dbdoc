create definer = root@localhost view view_document_sentence as
select `aor`.`idAnnotationObjectRelation` AS `idDocumentSentence`,
       `d`.`idDocument`                   AS `idDocument`,
       `s`.`idSentence`                   AS `idSentence`
from ((`webtool40_db`.`annotationobjectrelation` `aor` join `webtool40_db`.`document` `d`
       on (`aor`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) join `webtool40_db`.`sentence` `s`
      on (`aor`.`idAnnotationObject2` = `s`.`idAnnotationObject`));


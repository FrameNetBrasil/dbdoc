create definer = root@localhost view view_annotation_dynamic as
select `dob`.`idDynamicObject` AS `idDynamicObject`,
       `dob`.`name`            AS `name`,
       `dob`.`startFrame`      AS `startFrame`,
       `dob`.`endFrame`        AS `endFrame`,
       `dob`.`startTime`       AS `startTime`,
       `dob`.`endTime`         AS `endTime`,
       `dob`.`status`          AS `status`,
       `dob`.`origin`          AS `origin`,
       `alu`.`idAnnotation`    AS `idAnnotationLU`,
       `alu`.`idLU`            AS `idLU`,
       `alu`.`lu`              AS `lu`,
       `afe`.`idAnnotation`    AS `idAnnotationFE`,
       `afe`.`idFrameElement`  AS `idFrameElement`,
       `afe`.`idFrame`         AS `idFrame`,
       `afe`.`frame`           AS `frame`,
       `afe`.`fe`              AS `fe`,
       `afe`.`color`           AS `color`,
       `afe`.`idLanguage`      AS `idLanguage`,
       `d`.`idDocument`        AS `idDocument`
from (((((`webtool40_db`.`dynamicobject` `dob` join `webtool40_db`.`view_object_relation` `or1`
          on (`dob`.`idAnnotationObject` = `or1`.`idAnnotationObject2`)) join `webtool40_db`.`view_object_relation` `or2`
         on (`or1`.`idAnnotationObject1` = `or2`.`idAnnotationObject2`)) join `webtool40_db`.`document` `d`
        on (`or2`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) left join (select `a`.`idAnnotation`                                              AS `idAnnotation`,
                                                                                       `a`.`idAnnotationObject`                                        AS `idAnnotationObject`,
                                                                                       `lu`.`idLU`                                                     AS `idLU`,
                                                                                       if(`lu`.`idLU`, concat(`lu`.`frameName`, '.', `lu`.`name`), '') AS `lu`
                                                                                from (`webtool40_db`.`annotation` `a` join `webtool40_db`.`view_lu` `lu`
                                                                                      on (`a`.`idEntity` = `lu`.`idEntity`))) `alu`
       on (`dob`.`idAnnotationObject` = `alu`.`idAnnotationObject`)) left join (select `a`.`idAnnotation`             AS `idAnnotation`,
                                                                                       `a`.`idAnnotationObject`       AS `idAnnotationObject`,
                                                                                       `fe`.`idFrameElement`          AS `idFrameElement`,
                                                                                       `fe`.`idFrame`                 AS `idFrame`,
                                                                                       ifnull(`fe`.`frameName`, '')   AS `frame`,
                                                                                       ifnull(`fe`.`name`, '')        AS `fe`,
                                                                                       `webtool40_db`.`color`.`rgbBg` AS `color`,
                                                                                       `fe`.`idLanguage`              AS `idLanguage`
                                                                                from ((`webtool40_db`.`annotation` `a` join `webtool40_db`.`view_frameelement` `fe`
                                                                                       on (`a`.`idEntity` = `fe`.`idEntity`)) join `webtool40_db`.`color`
                                                                                      on (`fe`.`idColor` = `webtool40_db`.`color`.`idColor`))) `afe`
      on (`dob`.`idAnnotationObject` = `afe`.`idAnnotationObject`))
where `or1`.`relationType` = 'rel_video_dynobj'
  and `or2`.`relationType` = 'rel_document_video'
  and `dob`.`origin` in (1, 2)
order by `dob`.`startTime`, `dob`.`endTime`;


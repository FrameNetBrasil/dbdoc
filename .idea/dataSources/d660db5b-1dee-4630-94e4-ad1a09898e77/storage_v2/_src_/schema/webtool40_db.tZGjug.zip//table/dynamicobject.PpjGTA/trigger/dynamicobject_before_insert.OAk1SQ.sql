create definer = root@localhost trigger dynamicobject_BEFORE_INSERT
    before insert
    on dynamicobject
    for each row
BEGIN
IF (NEW.idAnnotationObject = 0) THEN
	SET NEW.idAnnotationObject = annotationobject_create(0,'DOB');
END IF;
END;


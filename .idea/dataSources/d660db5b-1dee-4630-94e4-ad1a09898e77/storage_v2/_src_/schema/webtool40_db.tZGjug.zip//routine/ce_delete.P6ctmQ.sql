create
    definer = root@localhost function ce_delete(par_idConstructionElement int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM constructionelement WHERE (idConstructionElement = par_idConstructionElement);
        DELETE FROM entityrelation where (idEntity1 = v_idEntity) OR (idEntity2 = v_idEntity) OR (idEntity3 = v_idEntity);
        DELETE FROM entry where (idEntity = v_idEntity);
        DELETE FROM constructionelement where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','constructionelement', par_idConstructionElement,par_idUser);
        RETURN par_idConstructionElement;
    END;


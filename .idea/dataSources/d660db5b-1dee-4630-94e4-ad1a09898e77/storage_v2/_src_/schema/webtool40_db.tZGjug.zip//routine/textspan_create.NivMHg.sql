create
    definer = root@localhost function textspan_create(par_json longtext) returns int
BEGIN 
   DECLARE v_x INT;
   DECLARE v_y INT;
   DECLARE v_width INT;
   DECLARE v_height INT;
   DECLARE v_idStaticObject INT;
   DECLARE v_idAnnotationObject1 INT;
   DECLARE v_idAnnotationObject2 INT;
   SET v_x = JSON_EXTRACT(par_json, '$.x');
   SET v_y = JSON_EXTRACT(par_json, '$.y');
   SET v_width = JSON_EXTRACT(par_json, '$.width');
   SET v_height = JSON_EXTRACT(par_json, '$.height');
   SET @idAnnotationObject2 = annotationobject_create(0,'BBX');
   INSERT INTO boundingbox (x,y,width,height,idAnnotationObject) values (v_x, v_y, v_width, v_height, @idAnnotationObject2);
   SET @idBoundingBox = (SELECT last_insert_id());
   SET v_idStaticObject = JSON_EXTRACT(par_json, '$.idStaticObject');
   SELECT idAnnotationObject INTO v_idAnnotationObject1 FROM staticobject where (idStaticObject = v_idStaticObject);
   SET @idAnnotationObjectRelation = objectrelation_create(JSON_OBJECT("idAnnotationObject1", v_idAnnotationObject1, "idAnnotationObject2", @idAnnotationObject2, "relationType", "rel_staobj_bbox"));
   RETURN @idBoundingBox;
END;


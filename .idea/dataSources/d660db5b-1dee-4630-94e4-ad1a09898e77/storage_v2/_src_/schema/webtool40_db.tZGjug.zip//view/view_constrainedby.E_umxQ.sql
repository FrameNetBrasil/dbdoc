create definer = root@localhost view view_constrainedby as
select `constraints`.`idLanguage`           AS `idLanguage`,
       `constraints`.`conName`              AS `conName`,
       `constraints`.`idConstraint`         AS `idConstraint`,
       `constraints`.`idConstrained`        AS `idConstrained`,
       `constraints`.`idConstrainedBy`      AS `idConstrainedBy`,
       `constraints`.`constrainedByType`    AS `constrainedByType`,
       `constraints`.`idConstraintInstance` AS `idConstraintInstance`,
       `constraints`.`name`                 AS `name`
from (select `view_constrainedby_frame`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_frame`.`conName`              AS `conName`,
             `view_constrainedby_frame`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_frame`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_frame`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_frame`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_frame`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_frame`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_frame`
      union
      select `view_constrainedby_construction`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_construction`.`conName`              AS `conName`,
             `view_constrainedby_construction`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_construction`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_construction`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_construction`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_construction`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_construction`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_construction`
      union
      select `view_constrainedby_ce`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_ce`.`conName`              AS `conName`,
             `view_constrainedby_ce`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_ce`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_ce`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_ce`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_ce`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_ce`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_ce`
      union
      select `view_constrainedby_semantictype`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_semantictype`.`conName`              AS `conName`,
             `view_constrainedby_semantictype`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_semantictype`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_semantictype`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_semantictype`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_semantictype`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_semantictype`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_semantictype`
      union
      select `view_constrainedby_constraint`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_constraint`.`conName`              AS `conName`,
             `view_constrainedby_constraint`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_constraint`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_constraint`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_constraint`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_constraint`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_constraint`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_constraint`
      union
      select `view_constrainedby_constraint_cx`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_constraint_cx`.`conName`              AS `conName`,
             `view_constrainedby_constraint_cx`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_constraint_cx`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_constraint_cx`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_constraint_cx`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_constraint_cx`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_constraint_cx`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_constraint_cx`
      union
      select `view_constrainedby_lexeme`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_lexeme`.`conName`              AS `conName`,
             `view_constrainedby_lexeme`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_lexeme`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_lexeme`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_lexeme`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_lexeme`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_lexeme`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_lexeme`
      union
      select `view_constrainedby_lemma`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_lemma`.`conName`              AS `conName`,
             `view_constrainedby_lemma`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_lemma`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_lemma`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_lemma`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_lemma`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_lemma`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_lemma`
      union
      select `view_constrainedby_lu`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_lu`.`conName`              AS `conName`,
             `view_constrainedby_lu`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_lu`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_lu`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_lu`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_lu`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_lu`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_lu`
      union
      select `view_constrainedby_udfeature`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_udfeature`.`conName`              AS `conName`,
             `view_constrainedby_udfeature`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_udfeature`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_udfeature`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_udfeature`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_udfeature`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_udfeature`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_udfeature`
      union
      select `view_constrainedby_udpos`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_udpos`.`conName`              AS `conName`,
             `view_constrainedby_udpos`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_udpos`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_udpos`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_udpos`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_udpos`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_udpos`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_udpos`
      union
      select `view_constrainedby_udrelation`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_udrelation`.`conName`              AS `conName`,
             `view_constrainedby_udrelation`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_udrelation`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_udrelation`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_udrelation`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_udrelation`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_udrelation`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_udrelation`
      union
      select `view_constrainedby_festandsforfe`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_festandsforfe`.`conName`              AS `conName`,
             `view_constrainedby_festandsforfe`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_festandsforfe`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_festandsforfe`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_festandsforfe`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_festandsforfe`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_festandsforfe`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_festandsforfe`
      union
      select `view_constrainedby_festandsforlu`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_festandsforlu`.`conName`              AS `conName`,
             `view_constrainedby_festandsforlu`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_festandsforlu`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_festandsforlu`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_festandsforlu`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_festandsforlu`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_festandsforlu`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_festandsforlu`
      union
      select `view_constrainedby_lustandsforlu`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_lustandsforlu`.`conName`              AS `conName`,
             `view_constrainedby_lustandsforlu`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_lustandsforlu`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_lustandsforlu`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_lustandsforlu`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_lustandsforlu`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_lustandsforlu`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_lustandsforlu`
      union
      select `view_constrainedby_luequivalence`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_luequivalence`.`conName`              AS `conName`,
             `view_constrainedby_luequivalence`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_luequivalence`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_luequivalence`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_luequivalence`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_luequivalence`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_luequivalence`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_luequivalence`
      union
      select `view_constrainedby_qualia`.`idLanguage`           AS `idLanguage`,
             `view_constrainedby_qualia`.`conName`              AS `conName`,
             `view_constrainedby_qualia`.`idConstraint`         AS `idConstraint`,
             `view_constrainedby_qualia`.`idConstrained`        AS `idConstrained`,
             `view_constrainedby_qualia`.`idConstrainedBy`      AS `idConstrainedBy`,
             `view_constrainedby_qualia`.`constrainedByType`    AS `constrainedByType`,
             `view_constrainedby_qualia`.`idConstraintInstance` AS `idConstraintInstance`,
             `view_constrainedby_qualia`.`name`                 AS `name`
      from `webtool40_db`.`view_constrainedby_qualia`) `constraints`;


create definer = root@localhost view view_annotation_text_ce as
select `a`.`idAnnotation`           AS `idAnnotation`,
       `ts`.`idTextSpan`            AS `idTextSpan`,
       `ts`.`startChar`             AS `startChar`,
       `ts`.`endChar`               AS `endChar`,
       `ts`.`multi`                 AS `multi`,
       `ts`.`idLayer`               AS `idLayer`,
       `ts`.`idInstantiationType`   AS `idInstantiationType`,
       `ts`.`idAnnotationObject`    AS `idAnnotationObject`,
       `ce`.`idConstruction`        AS `idConstruction`,
       `ce`.`idConstructionElement` AS `idConstructionElement`,
       `ce`.`idEntity`              AS `idEntity`,
       `ce`.`idColor`               AS `idColor`,
       `ce`.`name`                  AS `name`,
       `ce`.`idLanguage`            AS `idLanguage`,
       `l`.`idAnnotationSet`        AS `idAnnotationSet`,
       `l`.`idLayerType`            AS `idLayerType`,
       `lt`.`layerOrder`            AS `layerOrder`,
       `lt`.`entry`                 AS `layerTypeEntry`,
       `lt`.`idEntity`              AS `layerTypeIdEntity`
from ((((`webtool40_db`.`textspan` `ts` join `webtool40_db`.`annotation` `a`
         on (`ts`.`idAnnotationObject` = `a`.`idAnnotationObject`)) join `webtool40_db`.`view_constructionelement` `ce`
        on (`a`.`idEntity` = `ce`.`idEntity`)) join `webtool40_db`.`layer` `l`
       on (`ts`.`idLayer` = `l`.`idLayer`)) join `webtool40_db`.`layertype` `lt`
      on (`l`.`idLayerType` = `lt`.`idLayerType`));


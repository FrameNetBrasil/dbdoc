create
    definer = root@localhost function domain_create(par_domain longtext) returns int
BEGIN
	DECLARE v_nameEn VARCHAR(255);
	DECLARE v_entry VARCHAR(255);
    DECLARE v_idUser INT;
    INSERT INTO entity (type) values ('DOM');
	SET @idEntity = (SELECT last_insert_id());
    SET v_nameEn = JSON_UNQUOTE(JSON_EXTRACT(par_domain, '$.nameEn'));
    SET v_entry = CONCAT('dom_',lower(v_nameEn));
    CALL entry_create(v_entry, v_nameEn, @idEntity);
    INSERT INTO domain(entry, idEntity) values (v_entry, @idEntity);
    SET @idDomain = (SELECT last_insert_id());
    SET v_idUser = JSON_EXTRACT(par_domain, '$.idUser');
    INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','domain', @idDomain, v_idUser);
    RETURN @idDomain;
 END;


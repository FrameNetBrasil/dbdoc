create
    definer = root@localhost function annotationobject_create(par_externalId int, par_type char(3)) returns int
BEGIN 
   INSERT INTO annotationobject (externalId, type, createdAt) values (par_externalId, par_type, now());
   SET @idAnnotationObject = (SELECT last_insert_id());
   RETURN @idAnnotationObject;
END;


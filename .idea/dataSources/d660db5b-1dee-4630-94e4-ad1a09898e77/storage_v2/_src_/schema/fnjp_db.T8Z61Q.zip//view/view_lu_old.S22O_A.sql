create definer = webtool@`%` view view_lu_old as
select `fnjp_db`.`lu`.`idLU`             AS `idLU`,
       `fnjp_db`.`lu`.`name`             AS `name`,
       `fnjp_db`.`lu`.`senseDescription` AS `senseDescription`,
       `fnjp_db`.`lu`.`active`           AS `active`,
       `fnjp_db`.`lu`.`importNum`        AS `importNum`,
       `fnjp_db`.`lu`.`incorporatedFE`   AS `incorporatedFE`,
       `fnjp_db`.`lu`.`idEntity`         AS `idEntity`,
       `fnjp_db`.`lu`.`idLemma`          AS `idLemma`,
       `fnjp_db`.`frame`.`idFrame`       AS `idFrame`,
       `fnjp_db`.`frame`.`entry`         AS `frameEntry`,
       `fnjp_db`.`lemma`.`name`          AS `lemmaName`,
       `fnjp_db`.`lemma`.`idPOS`         AS `idPOS`,
       `fnjp_db`.`lemma`.`idLanguage`    AS `idLanguage`
from ((((`fnjp_db`.`lu` join `fnjp_db`.`entityrelation` `er1`
         on (`fnjp_db`.`lu`.`idEntity` = `er1`.`idEntity1`)) join `fnjp_db`.`relationtype` `rt1`
        on (`er1`.`idRelationType` = `rt1`.`idRelationType`)) join `fnjp_db`.`frame`
       on (`er1`.`idEntity2` = `fnjp_db`.`frame`.`idEntity`)) join `fnjp_db`.`lemma`
      on (`fnjp_db`.`lu`.`idLemma` = `fnjp_db`.`lemma`.`idLemma`))
where `rt1`.`entry` = 'rel_evokes';


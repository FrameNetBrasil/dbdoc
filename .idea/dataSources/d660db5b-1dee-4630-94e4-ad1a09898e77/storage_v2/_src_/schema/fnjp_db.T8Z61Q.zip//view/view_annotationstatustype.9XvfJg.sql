create definer = fnbrasil@`%` view view_annotationstatustype as
select `ti`.`entry`    AS `entry`,
       `ti`.`info`     AS `info`,
       `ti`.`flag`     AS `flag`,
       `ti`.`idType`   AS `idType`,
       `ti`.`idColor`  AS `idColor`,
       `ti`.`idEntity` AS `idEntity`
from (`fnjp_db`.`typeinstance` `ti` join `fnjp_db`.`type` on (`ti`.`idType` = `fnjp_db`.`type`.`idType`))
where `fnjp_db`.`type`.`entry` = 'typ_annotationstatustype';


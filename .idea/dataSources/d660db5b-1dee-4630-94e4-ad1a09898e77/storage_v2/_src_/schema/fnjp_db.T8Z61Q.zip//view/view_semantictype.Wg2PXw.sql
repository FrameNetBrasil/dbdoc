create definer = webtool@`%` view view_semantictype as
select `st`.`idSemanticType` AS `idSemanticType`,
       `st`.`entry`          AS `entry`,
       `st`.`idEntity`       AS `idEntity`,
       `st`.`idDomain`       AS `idDomain`,
       `d`.`entry`           AS `domainEntry`
from (`fnjp_db`.`semantictype` `st` join `fnjp_db`.`domain` `d` on (`st`.`idDomain` = `d`.`idDomain`));


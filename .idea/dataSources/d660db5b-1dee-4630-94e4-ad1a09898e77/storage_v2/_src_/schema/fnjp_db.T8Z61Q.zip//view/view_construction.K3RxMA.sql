create definer = webtool@`%` view view_construction as
select `fnjp_db`.`construction`.`idConstruction` AS `idConstruction`,
       `fnjp_db`.`construction`.`entry`          AS `entry`,
       `fnjp_db`.`construction`.`abstract`       AS `abstract`,
       `fnjp_db`.`construction`.`active`         AS `active`,
       `fnjp_db`.`construction`.`idEntity`       AS `idEntity`,
       `fnjp_db`.`construction`.`idLanguage`     AS `idLanguage`
from `fnjp_db`.`construction`;


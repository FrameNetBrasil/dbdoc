create definer = webtool@`%` view view_subcorpuslu as
select `sc`.`idSubCorpus`    AS `idSubCorpus`,
       `sc`.`name`           AS `name`,
       `sc`.`rank`           AS `rank`,
       `fnjp_db`.`lu`.`idLU` AS `idLU`
from (((`fnjp_db`.`lu` join `fnjp_db`.`entityrelation` `er1`
        on (`fnjp_db`.`lu`.`idEntity` = `er1`.`idEntity1`)) join `fnjp_db`.`relationtype` `rt1`
       on (`er1`.`idRelationType` = `rt1`.`idRelationType`)) join `fnjp_db`.`subcorpus` `sc`
      on (`er1`.`idEntity2` = `sc`.`idEntity`))
where `rt1`.`entry` = 'rel_hassubcorpus';


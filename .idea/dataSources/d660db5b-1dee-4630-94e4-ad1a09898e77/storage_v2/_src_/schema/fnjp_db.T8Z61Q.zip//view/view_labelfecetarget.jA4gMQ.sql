create definer = fnbrasil@`%` view view_labelfecetarget as
select `fnjp_db`.`annotationset`.`idAnnotationSet`                                AS `idAnnotationSet`,
       `fnjp_db`.`annotationset`.`idSubCorpus`                                    AS `idSubCorpus`,
       `fnjp_db`.`annotationset`.`idSentence`                                     AS `idSentence`,
       `fnjp_db`.`layertype`.`entry`                                              AS `layerTypeEntry`,
       `fe`.`idFrameElement`                                                      AS `idFrameElement`,
       `ce`.`idConstructionElement`                                               AS `idConstructionElement`,
       `gl`.`idGenericLabel`                                                      AS `idGenericLabel`,
       ifnull(`fnjp_db`.`label`.`startChar`, -1)                                  AS `startChar`,
       ifnull(`fnjp_db`.`label`.`endChar`, -1)                                    AS `endChar`,
       ifnull(`color_ce`.`rgbFg`, ifnull(`color_fe`.`rgbFg`, `color_gl`.`rgbFg`)) AS `rgbFg`,
       ifnull(`color_ce`.`rgbBg`, ifnull(`color_fe`.`rgbBg`, `color_gl`.`rgbBg`)) AS `rgbBg`,
       `entry_it`.`idLanguage`                                                    AS `idLanguage`,
       `entry_it`.`name`                                                          AS `instantiationType`
from (((((((((((`fnjp_db`.`annotationset` join `fnjp_db`.`layer` on (`fnjp_db`.`annotationset`.`idAnnotationSet` =
                                                                     `fnjp_db`.`layer`.`idAnnotationSet`)) join `fnjp_db`.`layertype`
               on (`fnjp_db`.`layer`.`idLayerType` = `fnjp_db`.`layertype`.`idLayerType`)) join `fnjp_db`.`label`
              on (`fnjp_db`.`layer`.`idLayer` = `fnjp_db`.`label`.`idLayer`)) join `fnjp_db`.`typeinstance`
             on (`fnjp_db`.`label`.`idInstantiationType` =
                 `fnjp_db`.`typeinstance`.`idTypeInstance`)) join `fnjp_db`.`entry` `entry_it`
            on (`fnjp_db`.`typeinstance`.`entry` = `entry_it`.`entry`)) left join `fnjp_db`.`frameelement` `fe`
           on (`fnjp_db`.`label`.`idLabelType` = `fe`.`idEntity`)) left join `fnjp_db`.`color` `color_fe`
          on (`fe`.`idColor` = `color_fe`.`idColor`)) left join `fnjp_db`.`constructionelement` `ce`
         on (`fnjp_db`.`label`.`idLabelType` = `ce`.`idEntity`)) left join `fnjp_db`.`color` `color_ce`
        on (`ce`.`idColor` = `color_ce`.`idColor`)) left join `fnjp_db`.`genericlabel` `gl`
       on (`fnjp_db`.`label`.`idLabelType` = `gl`.`idEntity`)) left join `fnjp_db`.`color` `color_gl`
      on (`gl`.`idColor` = `color_gl`.`idColor`))
where `fnjp_db`.`layertype`.`entry` = 'lty_fe'
   or `fnjp_db`.`layertype`.`entry` = 'lty_ce'
   or `fnjp_db`.`layertype`.`entry` = 'lty_target'
order by `fnjp_db`.`annotationset`.`idSentence`, `fnjp_db`.`label`.`startChar`;


create definer = webtool@`%` view view_subcorpuscxn as
select `sc`.`idSubCorpus`     AS `idSubCorpus`,
       `sc`.`name`            AS `name`,
       `sc`.`rank`            AS `rank`,
       `cxn`.`idConstruction` AS `idConstruction`
from (((`fnjp_db`.`construction` `cxn` join `fnjp_db`.`entityrelation` `er1`
        on (`cxn`.`idEntity` = `er1`.`idEntity1`)) join `fnjp_db`.`relationtype` `rt1`
       on (`er1`.`idRelationType` = `rt1`.`idRelationType`)) join `fnjp_db`.`subcorpus` `sc`
      on (`er1`.`idEntity2` = `sc`.`idEntity`))
where `rt1`.`entry` = 'rel_hassubcorpus';


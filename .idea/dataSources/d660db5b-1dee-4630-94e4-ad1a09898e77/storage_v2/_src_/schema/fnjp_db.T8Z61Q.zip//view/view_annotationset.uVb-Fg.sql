create definer = fnbrasil@`%` view view_annotationset as
select `a`.`idAnnotationSet`    AS `idAnnotationSet`,
       `a`.`idSubCorpus`        AS `idSubCorpus`,
       `a`.`idSentence`         AS `idSentence`,
       `a`.`idAnnotationStatus` AS `idAnnotationStatus`,
       `a`.`idEntityRelated`    AS `idEntityLU`,
       `fnjp_db`.`lu`.`idLU`    AS `idLU`,
       `a`.`idEntityRelated`    AS `idEntityCxn`,
       `cxn`.`idConstruction`   AS `idConstruction`,
       `ti`.`entry`             AS `entry`
from (((`fnjp_db`.`annotationset` `a` join `fnjp_db`.`typeinstance` `ti`
        on (`a`.`idAnnotationStatus` = `ti`.`idTypeInstance`)) left join `fnjp_db`.`lu`
       on (`a`.`idEntityRelated` = `fnjp_db`.`lu`.`idEntity`)) left join `fnjp_db`.`construction` `cxn`
      on (`a`.`idEntityRelated` = `cxn`.`idEntity`));


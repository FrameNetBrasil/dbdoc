create definer = fnbrasil@`%` view view_frame as
select `fnjp_db`.`frame`.`idFrame`  AS `idFrame`,
       `fnjp_db`.`frame`.`entry`    AS `entry`,
       `fnjp_db`.`frame`.`active`   AS `active`,
       `fnjp_db`.`frame`.`idEntity` AS `idEntity`
from `fnjp_db`.`frame`;


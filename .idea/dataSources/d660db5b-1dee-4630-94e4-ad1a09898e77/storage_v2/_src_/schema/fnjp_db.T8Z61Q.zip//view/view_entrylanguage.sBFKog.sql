create definer = fnbrasil@`%` view view_entrylanguage as
select `fnjp_db`.`entry`.`idEntry`     AS `idEntry`,
       `fnjp_db`.`entry`.`entry`       AS `entry`,
       `fnjp_db`.`entry`.`name`        AS `name`,
       `fnjp_db`.`entry`.`description` AS `description`,
       `fnjp_db`.`entry`.`nick`        AS `nick`,
       `fnjp_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `fnjp_db`.`language`.`language` AS `language`
from (`fnjp_db`.`entry` join `fnjp_db`.`language`
      on (`fnjp_db`.`entry`.`idLanguage` = `fnjp_db`.`language`.`idLanguage`));

-- comment on column view_entrylanguage.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


create definer = webtool@`%` view view_constructionelement_old as
select `fnjp_db`.`construction`.`entry`    AS `constructionEntry`,
       `fnjp_db`.`construction`.`idEntity` AS `constructionIdEntity`,
       `ce`.`idConstructionElement`        AS `idConstructionElement`,
       `ce`.`entry`                        AS `entry`,
       `ce`.`active`                       AS `active`,
       `ce`.`idEntity`                     AS `idEntity`,
       `ce`.`idColor`                      AS `idColor`,
       `ce`.`optional`                     AS `optional`,
       `ce`.`head`                         AS `head`,
       `ce`.`multiple`                     AS `multiple`,
       `ce`.`idConstruction`               AS `idConstruction`
from (((`fnjp_db`.`constructionelement` `ce` join `fnjp_db`.`entityrelation` `er1`
        on (`ce`.`idEntity` = `er1`.`idEntity1`)) join `fnjp_db`.`relationtype` `rt1`
       on (`er1`.`idRelationType` = `rt1`.`idRelationType`)) join `fnjp_db`.`construction`
      on (`er1`.`idEntity2` = `fnjp_db`.`construction`.`idEntity`))
where `rt1`.`entry` = 'rel_elementof';


create definer = fnbrasil@`%` view view_frameelement as
select `fnjp_db`.`frame`.`idFrame`  AS `idFrame`,
       `fnjp_db`.`frame`.`entry`    AS `frameEntry`,
       `fnjp_db`.`frame`.`idEntity` AS `frameIdEntity`,
       `fe`.`idFrameElement`        AS `idFrameElement`,
       `fe`.`entry`                 AS `entry`,
       `fe`.`active`                AS `active`,
       `fe`.`idEntity`              AS `idEntity`,
       `fe`.`idColor`               AS `idColor`,
       `fe`.`coreType`              AS `typeEntry`
from (`fnjp_db`.`frameelement` `fe` join `fnjp_db`.`frame` on (`fe`.`idFrame` = `fnjp_db`.`frame`.`idFrame`));


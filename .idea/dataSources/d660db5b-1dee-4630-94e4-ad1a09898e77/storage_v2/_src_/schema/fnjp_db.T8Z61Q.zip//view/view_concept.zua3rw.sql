create definer = webtool@`%` view view_concept as
select `cp`.`idConcept` AS `idConcept`, `cp`.`entry` AS `entry`, `cp`.`idEntity` AS `idEntity`
from `fnjp_db`.`concept` `cp`;


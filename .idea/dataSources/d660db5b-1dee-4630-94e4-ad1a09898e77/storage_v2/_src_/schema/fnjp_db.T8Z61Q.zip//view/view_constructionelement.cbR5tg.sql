create definer = webtool@`%` view view_constructionelement as
select `fnjp_db`.`construction`.`idConstruction` AS `idConstruction`,
       `fnjp_db`.`construction`.`entry`          AS `constructionEntry`,
       `fnjp_db`.`construction`.`idEntity`       AS `constructionIdEntity`,
       `ce`.`idConstructionElement`              AS `idConstructionElement`,
       `ce`.`entry`                              AS `entry`,
       `ce`.`active`                             AS `active`,
       `ce`.`idEntity`                           AS `idEntity`,
       `ce`.`idColor`                            AS `idColor`,
       `ce`.`optional`                           AS `optional`,
       `ce`.`head`                               AS `head`,
       `ce`.`multiple`                           AS `multiple`
from (`fnjp_db`.`constructionelement` `ce` join `fnjp_db`.`construction`
      on (`ce`.`idConstruction` = `fnjp_db`.`construction`.`idConstruction`));


create definer = fnbrasil@`%` view view_insper_comentario_pos_concessao_3_ano as
select `c`.`idInsperComentario` AS `idInsperComentario`,
       `c`.`user`               AS `user`,
       `c`.`dateComment`        AS `dateComment`,
       `c`.`text`               AS `text`,
       `c`.`concessao`          AS `concessao`,
       `c`.`priv`               AS `priv`,
       `c`.`category`           AS `category`,
       `c`.`anger`              AS `anger`,
       `c`.`antecipation`       AS `antecipation`,
       `c`.`disgust`            AS `disgust`,
       `c`.`fear`               AS `fear`,
       `c`.`joy`                AS `joy`,
       `c`.`sadness`            AS `sadness`,
       `c`.`surprise`           AS `surprise`,
       `c`.`trust`              AS `trust`,
       `c`.`negative`           AS `negative`,
       `c`.`positive`           AS `positive`,
       `c`.`md5`                AS `md5`,
       `c`.`idInsperConcessao`  AS `idInsperConcessao`,
       `c`.`data`               AS `data`
from (`daisy_db`.`insper_comentario` `c` join `daisy_db`.`insper_concessao` `o`
      on (`c`.`idInsperConcessao` = `o`.`idInsperConcessao`))
where `c`.`data` between `o`.`data` and `o`.`data` + interval 3 year;


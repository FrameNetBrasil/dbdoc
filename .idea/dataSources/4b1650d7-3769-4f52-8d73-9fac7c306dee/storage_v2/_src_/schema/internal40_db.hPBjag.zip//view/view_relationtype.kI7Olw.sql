create definer = fnbrasil@`%` view view_relationtype as
select `rt`.`idRelationType`  AS `idRelationType`,
       `rt`.`entry`           AS `entry`,
       `rt`.`prefix`          AS `prefix`,
       `rt`.`nameCanonical`   AS `nameCanonical`,
       `rt`.`nameDirect`      AS `nameDirect`,
       `rt`.`nameInverse`     AS `nameInverse`,
       `rt`.`color`           AS `color`,
       `rt`.`idRelationGroup` AS `idRelationGroup`,
       `rt`.`idEntity`        AS `idEntity`,
       `e`.`name`             AS `name`,
       `e`.`description`      AS `description`,
       `e`.`idLanguage`       AS `idLanguage`,
       `rg`.`entry`           AS `rgEntry`,
       `eg`.`name`            AS `rgName`
from (((`internal40_db`.`relationtype` `rt` join `internal40_db`.`entry` `e`
        on (`rt`.`idEntity` = `e`.`idEntity`)) join `internal40_db`.`relationgroup` `rg`
       on (`rt`.`idRelationGroup` = `rg`.`idRelationGroup`)) join `internal40_db`.`entry` `eg`
      on (`rg`.`idEntity` = `eg`.`idEntity`))
where `e`.`idLanguage` = `eg`.`idLanguage`;


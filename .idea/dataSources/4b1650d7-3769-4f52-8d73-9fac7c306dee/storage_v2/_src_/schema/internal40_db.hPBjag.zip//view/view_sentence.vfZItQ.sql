create definer = fnbrasil@`%` view view_sentence as
select `s`.`idSentence`     AS `idSentence`,
       `s`.`text`           AS `text`,
       `s`.`paragraphOrder` AS `paragraphOrder`,
       `s`.`idParagraph`    AS `idParagraph`,
       `s`.`idLanguage`     AS `idLanguage`,
       `p`.`documentOrder`  AS `documentOrder`,
       `p`.`idDocument`     AS `idDocument`,
       `d`.`entry`          AS `documentEntry`,
       `d`.`author`         AS `author`,
       `d`.`idGenre`        AS `idGenre`,
       `d`.`idCorpus`       AS `idCorpus`,
       `c`.`entry`          AS `corpusEntry`
from (((`internal40_db`.`sentence` `s` join `internal40_db`.`paragraph` `p`
        on (`s`.`idParagraph` = `p`.`idParagraph`)) join `internal40_db`.`document` `d`
       on (`p`.`idDocument` = `d`.`idDocument`)) join `internal40_db`.`corpus` `c`
      on (`d`.`idCorpus` = `c`.`idCorpus`));


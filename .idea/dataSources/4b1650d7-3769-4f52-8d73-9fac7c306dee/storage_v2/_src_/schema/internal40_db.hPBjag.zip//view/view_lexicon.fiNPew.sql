create definer = fnbrasil@`%` view view_lexicon as
select `wf`.`idWordForm`                       AS `idWordForm`,
       `wf`.`form`                             AS `form`,
       `wf`.`md5`                              AS `md5`,
       `wf`.`altSpell`                         AS `altSpell`,
       `wf`.`idEntity`                         AS `idEntityWF`,
       `lx`.`idLexeme`                         AS `idLexeme`,
       `lx`.`name`                             AS `lexeme`,
       `lx`.`idLanguage`                       AS `idLanguageLX`,
       `lx`.`idEntity`                         AS `idEntityLX`,
       `poslx`.`POS`                           AS `posLX`,
       `le`.`idLexemeEntry`                    AS `idLexemeEntry`,
       `le`.`lexemeOrder`                      AS `lexemeOrder`,
       `le`.`breakBefore`                      AS `breakBefore`,
       `le`.`headWord`                         AS `headWord`,
       `lm`.`idLemma`                          AS `idLemma`,
       `lm`.`name`                             AS `lemma`,
       `lm`.`idEntity`                         AS `idEntityLM`,
       `lm`.`idLanguage`                       AS `idLanguageLM`,
       `lm`.`idPOS`                            AS `idPOSLM`,
       `poslm`.`POS`                           AS `posLM`,
       `internal40_db`.`lu`.`idLU`             AS `idLU`,
       `internal40_db`.`lu`.`name`             AS `lu`,
       `internal40_db`.`lu`.`senseDescription` AS `senseDescription`,
       `internal40_db`.`lu`.`incorporatedFE`   AS `incorporatedFE`,
       `internal40_db`.`lu`.`idFrame`          AS `idFrame`,
       `internal40_db`.`lu`.`idEntity`         AS `idEntityLU`
from ((((((`internal40_db`.`wordform` `wf` join `internal40_db`.`lexeme` `lx`
           on (`wf`.`idLexeme` = `lx`.`idLexeme`)) join `internal40_db`.`pos` `poslx`
          on (`lx`.`idPOS` = `poslx`.`idPOS`)) left join `internal40_db`.`lexemeentry` `le`
         on (`lx`.`idLexeme` = `le`.`idLexeme`)) left join `internal40_db`.`lemma` `lm`
        on (`le`.`idLemma` = `lm`.`idLemma`)) left join `internal40_db`.`pos` `poslm`
       on (`lm`.`idPOS` = `poslm`.`idPOS`)) left join `internal40_db`.`lu`
      on (`lm`.`idLemma` = `internal40_db`.`lu`.`idLemma`));


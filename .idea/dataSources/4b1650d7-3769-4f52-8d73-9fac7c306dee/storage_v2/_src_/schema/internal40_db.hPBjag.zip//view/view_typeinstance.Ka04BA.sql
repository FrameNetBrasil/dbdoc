create definer = fnbrasil@`%` view view_typeinstance as
select `ti`.`idTypeInstance`                 AS `idTypeInstance`,
       `ti`.`entry`                          AS `entry`,
       `ti`.`idEntity`                       AS `idEntity`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`nick`        AS `nick`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`
from (`internal40_db`.`typeinstance` `ti` join `internal40_db`.`entry`
      on (`ti`.`idEntity` = `internal40_db`.`entry`.`idEntity`));


create definer = fnbrasil@`%` view view_semantictype as
select `st`.`idSemanticType` AS `idSemanticType`,
       `st`.`entry`          AS `entry`,
       `st`.`idEntity`       AS `idEntity`,
       `st`.`idDomain`       AS `idDomain`,
       `d`.`entry`           AS `domainEntry`,
       `e`.`name`            AS `name`,
       `e`.`description`     AS `description`,
       `e`.`idLanguage`      AS `idLanguage`
from ((`internal40_db`.`semantictype` `st` join `internal40_db`.`entry` `e`
       on (`e`.`idEntity` = `st`.`idEntity`)) join `internal40_db`.`domain` `d` on (`st`.`idDomain` = `d`.`idDomain`));


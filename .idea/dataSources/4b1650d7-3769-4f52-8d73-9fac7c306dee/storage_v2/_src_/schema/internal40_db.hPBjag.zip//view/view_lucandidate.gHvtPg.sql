create definer = fnbrasil@`%` view view_lucandidate as
select `frame`.`name`                       AS `frameName`,
       `lu`.`frameCandidate`                AS `frameCandidate`,
       `frame`.`idFrame`                    AS `idFrame`,
       `lu`.`idLUCandidate`                 AS `idLUCandidate`,
       `lu`.`name`                          AS `name`,
       `lu`.`senseDescription`              AS `senseDescription`,
       `lu`.`idLemma`                       AS `idLemma`,
       `lu`.`discussion`                    AS `discussion`,
       `lu`.`idDocument`                    AS `idDocument`,
       `lu`.`idDocumentSentence`            AS `idDocumentSentence`,
       `lu`.`idBoundingBox`                 AS `idBoundingBox`,
       `lu`.`idUser`                        AS `idUser`,
       `lu`.`incorporatedFE`                AS `incorporatedFE`,
       `lu`.`createdAt`                     AS `createdAt`,
       `internal40_db`.`lemma`.`name`       AS `lemmaName`,
       `internal40_db`.`lemma`.`idPOS`      AS `idPOS`,
       `internal40_db`.`lemma`.`idLanguage` AS `idLanguage`,
       `internal40_db`.`user`.`name`        AS `userName`,
       `internal40_db`.`user`.`email`       AS `email`
from (((`internal40_db`.`lucandidate` `lu` join `internal40_db`.`lemma`
        on (`lu`.`idLemma` = `internal40_db`.`lemma`.`idLemma`)) join `internal40_db`.`user`
       on (`lu`.`idUser` = `internal40_db`.`user`.`idUser`)) left join `internal40_db`.`view_frame` `frame`
      on (`lu`.`idFrame` = `frame`.`idFrame`))
where `internal40_db`.`lemma`.`idLanguage` = `frame`.`idLanguage`
   or `frame`.`idLanguage` is null;


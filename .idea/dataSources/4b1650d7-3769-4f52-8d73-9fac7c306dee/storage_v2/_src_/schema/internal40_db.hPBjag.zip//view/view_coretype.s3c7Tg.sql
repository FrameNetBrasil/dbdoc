create definer = fnbrasil@`%` view view_coretype as
select `ti`.`entry`    AS `entry`,
       `ti`.`info`     AS `info`,
       `ti`.`flag`     AS `flag`,
       `ti`.`idType`   AS `idType`,
       `ti`.`idColor`  AS `idColor`,
       `ti`.`idEntity` AS `idEntity`
from (`internal40_db`.`typeinstance` `ti` join `internal40_db`.`type`
      on (`ti`.`idType` = `internal40_db`.`type`.`idType`))
where `internal40_db`.`type`.`entry` = 'typ_coretype';


create definer = fnbrasil@`%` view view_annotation as
select `a`.`idAnnotation`       AS `idAnnotation`,
       `a`.`idRelationType`     AS `idRelationType`,
       `rt`.`entry`             AS `relationType`,
       `a`.`idEntity`           AS `idEntity`,
       `e`.`type`               AS `entityType`,
       `a`.`idAnnotationObject` AS `idAnnotationObject`,
       `ao`.`type`              AS `objectType`,
       `a`.`idUserTask`         AS `idUserTask`,
       `t`.`idTask`             AS `idTask`,
       `t`.`name`               AS `name`
from (((((`internal40_db`.`annotation` `a` join `internal40_db`.`relationtype` `rt`
          on (`a`.`idRelationType` = `rt`.`idRelationType`)) join `internal40_db`.`entity` `e`
         on (`a`.`idEntity` = `e`.`idEntity`)) join `internal40_db`.`annotationobject` `ao`
        on (`a`.`idAnnotationObject` = `ao`.`idAnnotationObject`)) join `internal40_db`.`usertask` `ut`
       on (`a`.`idUserTask` = `ut`.`idUserTask`)) join `internal40_db`.`task` `t` on (`ut`.`idTask` = `t`.`idTask`));


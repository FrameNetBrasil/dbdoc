create definer = fnbrasil@`%` view view_annotationset as
select `a`.`idAnnotationSet`            AS `idAnnotationSet`,
       `a`.`idAnnotationStatus`         AS `idAnnotationStatus`,
       `internal40_db`.`lu`.`idEntity`  AS `idEntityLU`,
       `internal40_db`.`lu`.`idLU`      AS `idLU`,
       `cxn`.`idEntity`                 AS `idEntityCxn`,
       `cxn`.`idConstruction`           AS `idConstruction`,
       `ti`.`idEntity`                  AS `idEntityTypeInstance`,
       `a`.`idAnnotationObjectRelation` AS `idDocumentSentence`,
       `ds`.`idSentence`                AS `idSentence`,
       `ds`.`idDocument`                AS `idDocument`
from ((((`internal40_db`.`annotationset` `a` join `internal40_db`.`typeinstance` `ti`
         on (`a`.`idAnnotationStatus` = `ti`.`idTypeInstance`)) join `internal40_db`.`view_document_sentence` `ds`
        on (`a`.`idAnnotationObjectRelation` = `ds`.`idDocumentSentence`)) left join `internal40_db`.`lu`
       on (`a`.`idLU` = `internal40_db`.`lu`.`idLU`)) left join `internal40_db`.`construction` `cxn`
      on (`a`.`idConstruction` = `cxn`.`idConstruction`));


create definer = fnbrasil@`%` view view_frameelement as
select `internal40_db`.`frame`.`idFrame`     AS `idFrame`,
       `internal40_db`.`frame`.`entry`       AS `frameEntry`,
       `internal40_db`.`frame`.`idEntity`    AS `frameIdEntity`,
       `entryframe`.`name`                   AS `frameName`,
       `fe`.`idFrameElement`                 AS `idFrameElement`,
       `fe`.`entry`                          AS `entry`,
       `fe`.`active`                         AS `active`,
       `fe`.`idEntity`                       AS `idEntity`,
       `fe`.`idColor`                        AS `idColor`,
       `fe`.`coreType`                       AS `coreType`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `entryen`.`name`                      AS `nameEn`
from (((((`internal40_db`.`frameelement` `fe` join `internal40_db`.`frame`
          on (`fe`.`idFrame` = `internal40_db`.`frame`.`idFrame`)) join `internal40_db`.`entry`
         on (`fe`.`idEntity` = `internal40_db`.`entry`.`idEntity`)) join `internal40_db`.`entry` `entryframe`
        on (`internal40_db`.`frame`.`idEntity` = `entryframe`.`idEntity`)) join `internal40_db`.`entry` `entryen`
       on (`fe`.`idEntity` = `entryen`.`idEntity` and `entryen`.`idLanguage` = 2)) join `internal40_db`.`typeinstance` `ti`
      on (`fe`.`coreType` = `ti`.`entry`))
where `internal40_db`.`entry`.`idLanguage` = `entryframe`.`idLanguage`
order by `ti`.`info`, `internal40_db`.`entry`.`name`;


create definer = fnbrasil@`%` view view_dynamicobject_boundingbox as
select `bb`.`idBoundingBox`      AS `idBoundingBox`,
       `bb`.`frameNumber`        AS `frameNumber`,
       `bb`.`frameTime`          AS `frameTime`,
       `bb`.`x`                  AS `x`,
       `bb`.`y`                  AS `y`,
       `bb`.`width`              AS `width`,
       `bb`.`height`             AS `height`,
       `bb`.`blocked`            AS `blocked`,
       `bb`.`idAnnotationObject` AS `idAnnotationObject`,
       `dob`.`idDynamicObject`   AS `idDynamicObject`
from ((`internal40_db`.`boundingbox` `bb` join `internal40_db`.`annotationobjectrelation` `aor`
       on (`bb`.`idAnnotationObject` = `aor`.`idAnnotationObject2`)) join `internal40_db`.`dynamicobject` `dob`
      on (`aor`.`idAnnotationObject1` = `dob`.`idAnnotationObject`));


create definer = fnbrasil@`%` view view_layertype_gl as
select `lt`.`idLayerType`       AS `idLayerType`,
       `lt`.`entry`             AS `entry`,
       `lt`.`allowsApositional` AS `allowsApositional`,
       `lt`.`isAnnotation`      AS `isAnnotation`,
       `lt`.`layerOrder`        AS `layerOrder`,
       `lt`.`idLayerGroup`      AS `idLayerGroup`,
       `lt`.`idEntity`          AS `idEntityLayerType`,
       `gl`.`idGenericLabel`    AS `idGenericLabel`,
       `gl`.`name`              AS `name`,
       `gl`.`definition`        AS `definition`,
       `gl`.`example`           AS `example`,
       `gl`.`idEntity`          AS `idEntityGenericLabel`,
       `gl`.`idColor`           AS `idColor`,
       `gl`.`idLanguage`        AS `idLanguage`
from ((`internal40_db`.`layertype` `lt` join `internal40_db`.`view_relation` `r`
       on (`lt`.`idEntity` = `r`.`idEntity1`)) join `internal40_db`.`genericlabel` `gl`
      on (`r`.`idEntity2` = `gl`.`idEntity`));


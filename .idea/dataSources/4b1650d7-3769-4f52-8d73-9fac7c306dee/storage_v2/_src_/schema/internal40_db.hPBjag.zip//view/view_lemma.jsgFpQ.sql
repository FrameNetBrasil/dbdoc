create definer = fnbrasil@`%` view view_lemma as
select `internal40_db`.`lemma`.`idLanguage`                                                     AS `idLanguage`,
       `internal40_db`.`lemma`.`idLemma`                                                        AS `idLemma`,
       `internal40_db`.`lemma`.`name`                                                           AS `name`,
       `internal40_db`.`lemma`.`idPOS`                                                          AS `idPOS`,
       `internal40_db`.`lemma`.`idEntity`                                                       AS `idEntity`,
       `internal40_db`.`pos`.`POS`                                                              AS `POS`,
       concat(`internal40_db`.`lemma`.`name`, ' [', `internal40_db`.`language`.`language`, ']') AS `fullName`
from ((`internal40_db`.`lemma` join `internal40_db`.`pos`
       on (`internal40_db`.`lemma`.`idPOS` = `internal40_db`.`pos`.`idPOS`)) join `internal40_db`.`language`
      on (`internal40_db`.`lemma`.`idLanguage` = `internal40_db`.`language`.`idLanguage`));


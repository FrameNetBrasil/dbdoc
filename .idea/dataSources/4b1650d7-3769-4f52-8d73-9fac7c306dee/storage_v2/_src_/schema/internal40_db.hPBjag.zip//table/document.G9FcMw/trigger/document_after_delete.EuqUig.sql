create definer = fnbrasil@`%` trigger document_AFTER_DELETE
    after delete
    on document
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


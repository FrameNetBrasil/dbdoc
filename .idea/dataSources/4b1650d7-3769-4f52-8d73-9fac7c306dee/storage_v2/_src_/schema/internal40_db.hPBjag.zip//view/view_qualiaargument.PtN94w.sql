create definer = fnbrasil@`%` view view_qualiaargument as
select `qa`.`idQualiaArgument`  AS `idQualiaArgument`,
       `qa`.`order`             AS `order`,
       `qa`.`type`              AS `type`,
       `qa`.`idQualiaStructure` AS `idQualiaStructure`,
       `fe`.`name`              AS `feName`,
       `fe`.`coreType`          AS `feCoreType`,
       `fe`.`idColor`           AS `feIdColor`,
       `fe`.`idLanguage`        AS `idLanguage`
from (`internal40_db`.`qualiaargument` `qa` join `internal40_db`.`view_frameelement` `fe`
      on (`qa`.`idFrameElement` = `fe`.`idFrameElement`));


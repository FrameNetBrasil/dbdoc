create definer = fnbrasil@`%` view view_constructionelement_relation as
select `relation`.`idEntityRelation` AS `idEntityRelation`,
       `relation`.`idRelationType`   AS `idRelationType`,
       `relation`.`relationType`     AS `relationType`,
       `relation`.`nameCanonical`    AS `nameCanonical`,
       `relation`.`nameDirect`       AS `nameDirect`,
       `relation`.`nameInverse`      AS `nameInverse`,
       `relation`.`color`            AS `color`,
       `ce1`.`name`                  AS `ce1Name`,
       `ce1`.`idConstructionElement` AS `ce1IdConstructionElement`,
       `ce1`.`idEntity`              AS `ce1IdEntity`,
       `ce1`.`idLanguage`            AS `idLanguage`,
       `ce2`.`name`                  AS `ce2Name`,
       `ce2`.`idConstructionElement` AS `ce2IdConstructionElement`,
       `ce2`.`idEntity`              AS `ce2IdEntity`
from ((`internal40_db`.`view_constructionelement` `ce1` join `internal40_db`.`view_relation` `relation`
       on (`ce1`.`idEntity` = `relation`.`idEntity1`)) join `internal40_db`.`view_constructionelement` `ce2`
      on (`relation`.`idEntity2` = `ce2`.`idEntity`))
where `relation`.`relationType` in ('rel_daughter_of', 'rel_inheritance_cxn')
  and `ce1`.`idLanguage` = `ce2`.`idLanguage`;


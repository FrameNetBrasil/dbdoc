create definer = fnbrasil@`%` view view_document_sentence as
select `aor`.`idAnnotationObjectRelation` AS `idDocumentSentence`,
       `d`.`idDocument`                   AS `idDocument`,
       `s`.`idSentence`                   AS `idSentence`
from ((`internal40_db`.`annotationobjectrelation` `aor` join `internal40_db`.`document` `d`
       on (`aor`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) join `internal40_db`.`sentence` `s`
      on (`aor`.`idAnnotationObject2` = `s`.`idAnnotationObject`));


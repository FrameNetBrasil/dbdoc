create definer = fnbrasil@`%` view view_entrylanguage as
select `internal40_db`.`entry`.`idEntry`     AS `idEntry`,
       `internal40_db`.`entry`.`entry`       AS `entry`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`nick`        AS `nick`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `internal40_db`.`language`.`language` AS `language`
from (`internal40_db`.`entry` join `internal40_db`.`language`
      on (`internal40_db`.`entry`.`idLanguage` = `internal40_db`.`language`.`idLanguage`));

-- comment on column view_entrylanguage.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


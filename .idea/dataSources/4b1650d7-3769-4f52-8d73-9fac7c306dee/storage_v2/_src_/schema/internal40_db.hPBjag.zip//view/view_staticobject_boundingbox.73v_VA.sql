create definer = fnbrasil@`%` view view_staticobject_boundingbox as
select `bb`.`idBoundingBox`      AS `idBoundingBox`,
       `bb`.`x`                  AS `x`,
       `bb`.`y`                  AS `y`,
       `bb`.`width`              AS `width`,
       `bb`.`height`             AS `height`,
       `bb`.`blocked`            AS `blocked`,
       `bb`.`idAnnotationObject` AS `idAnnotationObject`,
       `sob`.`idStaticObject`    AS `idStaticObject`
from ((`internal40_db`.`boundingbox` `bb` join `internal40_db`.`annotationobjectrelation` `aor`
       on (`bb`.`idAnnotationObject` = `aor`.`idAnnotationObject2`)) join `internal40_db`.`staticobject` `sob`
      on (`aor`.`idAnnotationObject1` = `sob`.`idAnnotationObject`));


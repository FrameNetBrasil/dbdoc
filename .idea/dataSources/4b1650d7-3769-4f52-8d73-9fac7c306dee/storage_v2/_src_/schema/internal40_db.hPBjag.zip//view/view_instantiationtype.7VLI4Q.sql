create definer = fnbrasil@`%` view view_instantiationtype as
select `ti`.`idTypeInstance`                 AS `idInstantiationType`,
       `ti`.`entry`                          AS `entry`,
       `ti`.`info`                           AS `info`,
       `ti`.`flag`                           AS `flag`,
       `ti`.`idTypeInstance`                 AS `idTypeInstance`,
       `ti`.`idType`                         AS `idType`,
       `ti`.`idColor`                        AS `idColor`,
       `ti`.`idEntity`                       AS `idEntity`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`
from ((`internal40_db`.`typeinstance` `ti` join `internal40_db`.`type`
       on (`ti`.`idType` = `internal40_db`.`type`.`idType`)) join `internal40_db`.`entry`
      on (`ti`.`idEntity` = `internal40_db`.`entry`.`idEntity`))
where `internal40_db`.`type`.`entry` = 'typ_instantiationtype';


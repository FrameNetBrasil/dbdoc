create definer = fnbrasil@`%` view view_staticobject_textspan as
select `internal40_db`.`staticobject`.`idStaticObject`     AS `idStaticObject`,
       `internal40_db`.`staticobject`.`idAnnotationObject` AS `idAnnotationObject`,
       `internal40_db`.`staticobject`.`name`               AS `name`,
       `internal40_db`.`staticobject`.`scene`              AS `scene`,
       `internal40_db`.`staticobject`.`nobndbox`           AS `nobndbox`,
       `ts`.`startWord`                                    AS `startWord`,
       `ts`.`endWord`                                      AS `endWord`,
       `d`.`idDocument`                                    AS `idDocument`,
       `s`.`idSentence`                                    AS `idSentence`
from (((((((`internal40_db`.`staticobject` join `internal40_db`.`annotationobject` `sob`
            on (`sob`.`idAnnotationObject` =
                `internal40_db`.`staticobject`.`idAnnotationObject`)) join `internal40_db`.`annotationobject` `txs`
           on (`sob`.`externalId` = `txs`.`externalId`)) join `internal40_db`.`textspan` `ts`
          on (`txs`.`idAnnotationObject` = `ts`.`idAnnotationObject`)) join `internal40_db`.`view_object_relation` `r`
         on (`ts`.`idAnnotationObject` = `r`.`idAnnotationObject2`)) join `internal40_db`.`view_object_relation` `ds`
        on (`ds`.`idAnnotationObject2` = `r`.`idAnnotationObject1`)) join `internal40_db`.`document` `d`
       on (`ds`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) join `internal40_db`.`sentence` `s`
      on (`r`.`idAnnotationObject1` = `s`.`idAnnotationObject`));


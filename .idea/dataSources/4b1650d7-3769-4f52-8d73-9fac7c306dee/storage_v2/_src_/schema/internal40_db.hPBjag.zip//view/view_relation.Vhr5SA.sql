create definer = fnbrasil@`%` view view_relation as
select `er`.`idEntityRelation` AS `idEntityRelation`,
       `rg`.`entry`            AS `relationGroup`,
       `rt`.`idRelationType`   AS `idRelationType`,
       `rt`.`entry`            AS `relationType`,
       `rt`.`idEntity`         AS `idEntity`,
       `rt`.`prefix`           AS `prefix`,
       `rt`.`nameCanonical`    AS `nameCanonical`,
       `rt`.`nameDirect`       AS `nameDirect`,
       `rt`.`nameInverse`      AS `nameInverse`,
       `rt`.`color`            AS `color`,
       `er`.`idEntity1`        AS `idEntity1`,
       `e1`.`type`             AS `entity1Type`,
       `er`.`idEntity2`        AS `idEntity2`,
       `e2`.`type`             AS `entity2Type`,
       `er`.`idEntity3`        AS `idEntity3`,
       `e3`.`type`             AS `entity3Type`,
       `er`.`idRelation`       AS `idRelation`
from (((((`internal40_db`.`entityrelation` `er` join `internal40_db`.`relationtype` `rt`
          on (`er`.`idRelationType` = `rt`.`idRelationType`)) join `internal40_db`.`relationgroup` `rg`
         on (`rt`.`idRelationGroup` = `rg`.`idRelationGroup`)) join `internal40_db`.`entity` `e1`
        on (`er`.`idEntity1` = `e1`.`idEntity`)) join `internal40_db`.`entity` `e2`
       on (`er`.`idEntity2` = `e2`.`idEntity`)) left join `internal40_db`.`entity` `e3`
      on (`er`.`idEntity3` = `e3`.`idEntity`));


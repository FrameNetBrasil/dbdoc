create definer = fnbrasil@`%` view view_fe_internal_relation as
select `relation`.`idEntityRelation` AS `idEntityRelation`,
       `relation`.`idRelationType`   AS `idRelationType`,
       `relation`.`relationType`     AS `relationType`,
       `relation`.`nameCanonical`    AS `nameCanonical`,
       `relation`.`nameDirect`       AS `nameDirect`,
       `relation`.`nameInverse`      AS `nameInverse`,
       `relation`.`color`            AS `color`,
       `fe1`.`name`                  AS `fe1Name`,
       `fe1`.`idFrameElement`        AS `fe1IdFrameElement`,
       `fe1`.`idEntity`              AS `fe1IdEntity`,
       `fe1`.`idFrame`               AS `fe1IdFrame`,
       `fe1`.`coreType`              AS `fe1CoreType`,
       `fe1`.`idColor`               AS `fe1IdColor`,
       `fe1`.`idLanguage`            AS `idLanguage`,
       `fe2`.`name`                  AS `fe2Name`,
       `fe2`.`idFrameElement`        AS `fe2IdFrameElement`,
       `fe2`.`idEntity`              AS `fe2IdEntity`,
       `fe2`.`idFrame`               AS `fe2IdFrame`,
       `fe2`.`coreType`              AS `fe2CoreType`,
       `fe2`.`idColor`               AS `fe2IdColor`
from ((`internal40_db`.`view_frameelement` `fe1` join `internal40_db`.`view_relation` `relation`
       on (`fe1`.`idEntity` = `relation`.`idEntity1`)) join `internal40_db`.`view_frameelement` `fe2`
      on (`relation`.`idEntity2` = `fe2`.`idEntity`))
where `relation`.`relationType` in ('rel_coreset', 'rel_excludes', 'rel_requires')
  and `fe1`.`idLanguage` = `fe2`.`idLanguage`;


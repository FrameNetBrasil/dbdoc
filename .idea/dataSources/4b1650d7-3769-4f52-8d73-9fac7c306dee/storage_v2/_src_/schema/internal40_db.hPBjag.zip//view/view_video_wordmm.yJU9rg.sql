create definer = fnbrasil@`%` view view_video_wordmm as
select `w`.`idWordMM`           AS `idWordMM`,
       `w`.`word`               AS `word`,
       `w`.`startTime`          AS `startTime`,
       `w`.`endTime`            AS `endTime`,
       `w`.`origin`             AS `origin`,
       `v`.`idVideo`            AS `idVideo`,
       `w`.`idDocumentSentence` AS `idDocumentSentence`,
       `ds`.`idDocument`        AS `idDocument`,
       `ds`.`idSentence`        AS `idSentence`
from ((`internal40_db`.`wordmm` `w` join `internal40_db`.`video` `v`
       on (`w`.`idVideo` = `v`.`idVideo`)) left join `internal40_db`.`view_document_sentence` `ds`
      on (`w`.`idDocumentSentence` = `ds`.`idDocumentSentence`));


create definer = fnbrasil@`%` view view_lu as
select `frame`.`idLanguage`                    AS `idLanguageFrame`,
       `frame`.`idFrame`                       AS `idFrame`,
       `frame`.`idEntity`                      AS `frameIdEntity`,
       `frame`.`name`                          AS `frameName`,
       `internal40_db`.`lu`.`idLU`             AS `idLU`,
       `internal40_db`.`lu`.`name`             AS `name`,
       `internal40_db`.`lu`.`senseDescription` AS `senseDescription`,
       `internal40_db`.`lu`.`active`           AS `active`,
       `internal40_db`.`lu`.`importNum`        AS `importNum`,
       `internal40_db`.`lu`.`incorporatedFE`   AS `incorporatedFE`,
       `internal40_db`.`lu`.`idEntity`         AS `idEntity`,
       `internal40_db`.`lu`.`idLemma`          AS `idLemma`,
       `internal40_db`.`lemma`.`name`          AS `lemmaName`,
       `internal40_db`.`lemma`.`idPOS`         AS `idPOS`,
       `internal40_db`.`lemma`.`idLanguage`    AS `idLanguage`
from ((`internal40_db`.`lu` join `internal40_db`.`view_frame` `frame`
       on (`internal40_db`.`lu`.`idFrame` = `frame`.`idFrame`)) join `internal40_db`.`lemma`
      on (`internal40_db`.`lu`.`idLemma` = `internal40_db`.`lemma`.`idLemma`))
where `internal40_db`.`lemma`.`idLanguage` = `frame`.`idLanguage`;


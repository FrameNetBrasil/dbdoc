create definer = fnbrasil@`%` view view_frame as
select `internal40_db`.`frame`.`idFrame`     AS `idFrame`,
       `internal40_db`.`frame`.`entry`       AS `entry`,
       `internal40_db`.`frame`.`active`      AS `active`,
       `internal40_db`.`frame`.`idEntity`    AS `idEntity`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`
from (`internal40_db`.`frame` join `internal40_db`.`entry`
      on (`internal40_db`.`frame`.`idEntity` = `internal40_db`.`entry`.`idEntity`));


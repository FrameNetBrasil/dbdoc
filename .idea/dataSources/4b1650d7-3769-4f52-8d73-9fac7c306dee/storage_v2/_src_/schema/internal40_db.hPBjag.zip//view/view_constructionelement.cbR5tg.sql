create definer = fnbrasil@`%` view view_constructionelement as
select `internal40_db`.`construction`.`idConstruction` AS `idConstruction`,
       `internal40_db`.`construction`.`entry`          AS `constructionEntry`,
       `internal40_db`.`construction`.`idEntity`       AS `constructionIdEntity`,
       `ce`.`idConstructionElement`                    AS `idConstructionElement`,
       `ce`.`entry`                                    AS `entry`,
       `ce`.`active`                                   AS `active`,
       `ce`.`idEntity`                                 AS `idEntity`,
       `ce`.`idColor`                                  AS `idColor`,
       `ce`.`optional`                                 AS `optional`,
       `ce`.`head`                                     AS `head`,
       `ce`.`multiple`                                 AS `multiple`,
       `internal40_db`.`entry`.`name`                  AS `name`,
       `internal40_db`.`entry`.`description`           AS `description`,
       `internal40_db`.`entry`.`idLanguage`            AS `idLanguage`
from ((`internal40_db`.`constructionelement` `ce` join `internal40_db`.`construction`
       on (`ce`.`idConstruction` = `internal40_db`.`construction`.`idConstruction`)) join `internal40_db`.`entry`
      on (`ce`.`idEntity` = `internal40_db`.`entry`.`idEntity`));


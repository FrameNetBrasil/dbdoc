create definer = fnbrasil@`%` view view_frame_classification as
select `st`.`idSemanticType`             AS `idSemanticType`,
       `relation`.`relationType`         AS `relationType`,
       `e`.`name`                        AS `name`,
       `e`.`idLanguage`                  AS `idLanguage`,
       `internal40_db`.`frame`.`idFrame` AS `idFrame`
from (((`internal40_db`.`frame` join `internal40_db`.`view_relation` `relation`
        on (`internal40_db`.`frame`.`idEntity` = `relation`.`idEntity1`)) join `internal40_db`.`semantictype` `st`
       on (`relation`.`idEntity2` = `st`.`idEntity`)) join `internal40_db`.`entry` `e`
      on (`e`.`idEntity` = `st`.`idEntity`))
where `relation`.`relationType` in ('rel_framal_type', 'rel_framal_domain');


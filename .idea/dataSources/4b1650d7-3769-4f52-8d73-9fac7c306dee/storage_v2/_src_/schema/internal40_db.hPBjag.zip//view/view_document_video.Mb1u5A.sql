create definer = fnbrasil@`%` view view_document_video as
select `aor`.`idAnnotationObjectRelation` AS `idDocumentVideo`,
       `d`.`idDocument`                   AS `idDocument`,
       `v`.`idVideo`                      AS `idVideo`
from ((`internal40_db`.`annotationobjectrelation` `aor` join `internal40_db`.`document` `d`
       on (`aor`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) join `internal40_db`.`video` `v`
      on (`aor`.`idAnnotationObject2` = `v`.`idAnnotationObject`));


create definer = fnbrasil@`%` view view_qualialu as
select `ql`.`idQualiaLU`      AS `idQualiaLU`,
       `lu1`.`idLU`           AS `idLU1`,
       `lu1`.`name`           AS `lu1`,
       `lu2`.`idLU`           AS `idLU2`,
       `lu2`.`name`           AS `lu2`,
       `qa1`.`idFrameElement` AS `idFrameElement1`,
       `qa1`.`order`          AS `order1`,
       `qa1`.`type`           AS `type1`,
       `qa2`.`idFrameElement` AS `idFrameElement2`,
       `qa2`.`order`          AS `order2`,
       `qa2`.`type`           AS `type2`
from (((((`internal40_db`.`qualialu` `ql` join `internal40_db`.`view_lu` `lu1`
          on (`ql`.`idLU1` = `lu1`.`idLU`)) join `internal40_db`.`view_lu` `lu2`
         on (`ql`.`idLU2` = `lu2`.`idLU`)) join `internal40_db`.`view_qualiastructure` `qs`
        on (`ql`.`idQualiaStructure` = `qs`.`idQualiaStructure`)) join `internal40_db`.`qualiaargument` `qa1`
       on (`qa1`.`idQualiaStructure` = `qs`.`idQualiaStructure` and
           `qa1`.`order` = 1)) join `internal40_db`.`qualiaargument` `qa2`
      on (`qa2`.`idQualiaStructure` = `qs`.`idQualiaStructure` and `qa2`.`order` = 2));


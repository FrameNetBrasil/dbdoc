create definer = fnbrasil@`%` view view_group_user as
select `internal40_db`.`group`.`idGroup`     AS `idGroup`,
       `internal40_db`.`group`.`name`        AS `name`,
       `internal40_db`.`user_group`.`idUser` AS `idUser`
from (`internal40_db`.`group` join `internal40_db`.`user_group`
      on (`internal40_db`.`group`.`idGroup` = `internal40_db`.`user_group`.`idGroup`));


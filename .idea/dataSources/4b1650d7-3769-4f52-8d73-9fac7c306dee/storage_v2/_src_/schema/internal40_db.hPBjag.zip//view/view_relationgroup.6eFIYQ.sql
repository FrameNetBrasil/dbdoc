create definer = fnbrasil@`%` view view_relationgroup as
select `rg`.`idRelationGroup` AS `idRelationGroup`,
       `rg`.`entry`           AS `entry`,
       `rg`.`idEntity`        AS `idEntity`,
       `e`.`name`             AS `name`,
       `e`.`description`      AS `description`,
       `e`.`idLanguage`       AS `idLanguage`
from (`internal40_db`.`relationgroup` `rg` join `internal40_db`.`entry` `e` on (`rg`.`idEntity` = `e`.`idEntity`));


create definer = fnbrasil@`%` view view_sentence_document as
select `s`.`idSentence`         AS `idSentence`,
       `s`.`text`               AS `text`,
       `s`.`idLanguage`         AS `idLanguageSentence`,
       `s`.`idAnnotationObject` AS `idAnnotationObject`,
       `s`.`idOriginMM`         AS `idOriginMM`,
       `d`.`idDocument`         AS `idDocument`,
       `d`.`name`               AS `name`,
       `d`.`idLanguage`         AS `idLanguage`
from ((`internal40_db`.`sentence` `s` join `internal40_db`.`annotationobjectrelation` `r`
       on (`s`.`idAnnotationObject` = `r`.`idAnnotationObject2`)) join `internal40_db`.`view_document` `d`
      on (`r`.`idAnnotationObject1` = `d`.`idAnnotationObject`));


create
    definer = fnbrasil@`%` function dataset_update(par_dataset longtext) returns int
BEGIN
		DECLARE v_name VARCHAR(255);
        DECLARE v_description VARCHAR(4000);
        DECLARE v_idProject INT;
        DECLARE v_idUser INT;
        DECLARE v_idDataset INT;
        SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_dataset, '$.name'));
        SET v_description = JSON_UNQUOTE(JSON_EXTRACT(par_dataset, '$.description'));
        SET v_idProject = JSON_EXTRACT(par_dataset, '$.idProject');
        SET v_idUser = JSON_EXTRACT(par_dataset, '$.idUser');
        SET v_idDataset = JSON_EXTRACT(par_dataset, '$.idDataset');
        UPDATE dataset set idProject=v_idProject, name = v_name, description = v_description WHERE (idDataset = v_idDataset);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','U','dataset', v_idDataset, v_idUser);
        RETURN v_idDataset;
    END;


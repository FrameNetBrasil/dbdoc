create definer = fnbrasil@`%` view view_document_image as
select `aor`.`idAnnotationObjectRelation` AS `idDocumentImage`,
       `d`.`idDocument`                   AS `idDocument`,
       `i`.`idImage`                      AS `idImage`
from ((`internal40_db`.`annotationobjectrelation` `aor` join `internal40_db`.`document` `d`
       on (`aor`.`idAnnotationObject1` = `d`.`idAnnotationObject`)) join `internal40_db`.`image` `i`
      on (`aor`.`idAnnotationObject2` = `i`.`idAnnotationObject`));


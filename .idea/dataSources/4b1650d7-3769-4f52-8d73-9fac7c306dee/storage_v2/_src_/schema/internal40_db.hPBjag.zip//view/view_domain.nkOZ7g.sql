create definer = fnbrasil@`%` view view_domain as
select `internal40_db`.`domain`.`idDomain`   AS `idDomain`,
       `internal40_db`.`domain`.`entry`      AS `entry`,
       `internal40_db`.`domain`.`idEntity`   AS `idEntity`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`
from (`internal40_db`.`domain` join `internal40_db`.`entry`
      on (`internal40_db`.`domain`.`idEntity` = `internal40_db`.`entry`.`idEntity`));


create definer = fnbrasil@`%` view view_usertask as
select `ut`.`idUserTask` AS `idUserTask`,
       `ut`.`isActive`   AS `isActive`,
       `ut`.`isIgnore`   AS `isIgnore`,
       `u`.`idUser`      AS `idUser`,
       `u`.`login`       AS `login`,
       `u`.`name`        AS `userName`,
       `u`.`email`       AS `email`,
       `t`.`idTask`      AS `idTask`,
       `t`.`name`        AS `taskName`
from ((`internal40_db`.`usertask` `ut` join `internal40_db`.`user` `u`
       on (`ut`.`idUser` = `u`.`idUser`)) join `internal40_db`.`task` `t` on (`ut`.`idTask` = `t`.`idTask`));


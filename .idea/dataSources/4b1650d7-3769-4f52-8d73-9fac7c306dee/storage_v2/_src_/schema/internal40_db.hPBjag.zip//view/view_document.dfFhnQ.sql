create definer = fnbrasil@`%` view view_document as
select `internal40_db`.`document`.`idDocument`         AS `idDocument`,
       `internal40_db`.`document`.`author`             AS `author`,
       `internal40_db`.`document`.`active`             AS `active`,
       `internal40_db`.`document`.`idGenre`            AS `idGenre`,
       `internal40_db`.`document`.`idCorpus`           AS `idCorpus`,
       `internal40_db`.`document`.`idEntity`           AS `idEntity`,
       `internal40_db`.`document`.`idAnnotationObject` AS `idAnnotationObject`,
       `view_corpus`.`name`                            AS `corpusName`,
       `view_corpus`.`description`                     AS `corpusDescription`,
       `internal40_db`.`entry`.`name`                  AS `name`,
       `internal40_db`.`entry`.`description`           AS `description`,
       `internal40_db`.`entry`.`idLanguage`            AS `idLanguage`
from ((`internal40_db`.`document` join `internal40_db`.`view_corpus`
       on (`internal40_db`.`document`.`idCorpus` = `view_corpus`.`idCorpus`)) join `internal40_db`.`entry`
      on (`internal40_db`.`document`.`idEntity` = `internal40_db`.`entry`.`idEntity`))
where `view_corpus`.`idLanguage` = `internal40_db`.`entry`.`idLanguage`;


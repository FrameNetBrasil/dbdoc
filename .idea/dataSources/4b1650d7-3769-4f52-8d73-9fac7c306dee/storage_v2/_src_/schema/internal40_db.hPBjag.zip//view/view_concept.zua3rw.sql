create definer = fnbrasil@`%` view view_concept as
select `cp`.`idConcept`                      AS `idConcept`,
       `cp`.`entry`                          AS `entry`,
       `cp`.`idEntity`                       AS `idEntity`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `ti`.`name`                           AS `tiName`,
       `ti`.`description`                    AS `tiDescription`,
       `ti`.`nick`                           AS `tiNick`
from ((`internal40_db`.`concept` `cp` join `internal40_db`.`entry`
       on (`cp`.`idEntity` = `internal40_db`.`entry`.`idEntity`)) join `internal40_db`.`view_typeinstance` `ti`
      on (`cp`.`idTypeInstance` = `ti`.`idTypeInstance`))
where `internal40_db`.`entry`.`idLanguage` = `ti`.`idLanguage`;


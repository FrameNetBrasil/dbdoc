create definer = fnbrasil@`%` view view_corpus as
select `internal40_db`.`corpus`.`idCorpus`   AS `idCorpus`,
       `internal40_db`.`corpus`.`active`     AS `active`,
       `internal40_db`.`corpus`.`idEntity`   AS `idEntity`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`
from (`internal40_db`.`corpus` join `internal40_db`.`entry`
      on (`internal40_db`.`corpus`.`idEntity` = `internal40_db`.`entry`.`idEntity`));


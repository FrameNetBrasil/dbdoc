create definer = fnbrasil@`%` view view_project_docs as
select distinct `p`.`idProject`    AS `idProject`,
                `p`.`name`         AS `projectName`,
                `c`.`idCorpus`     AS `idCorpus`,
                `c`.`name`         AS `corpusName`,
                `doc`.`idDocument` AS `idDocument`,
                `doc`.`name`       AS `documentName`,
                `doc`.`idLanguage` AS `idLanguage`
from ((((`internal40_db`.`project` `p` join `internal40_db`.`project_dataset` `d`
         on (`p`.`idProject` = `d`.`idProject`)) join `internal40_db`.`dataset_corpus` `dc`
        on (`d`.`idDataset` = `dc`.`idDataset`)) join `internal40_db`.`view_corpus` `c`
       on (`dc`.`idCorpus` = `c`.`idCorpus`)) join `internal40_db`.`view_document` `doc`
      on (`c`.`idCorpus` = `doc`.`idCorpus`))
where `doc`.`idLanguage` = `c`.`idLanguage`;


create definer = fnbrasil@`%` view view_construction as
select `internal40_db`.`construction`.`idConstruction` AS `idConstruction`,
       `internal40_db`.`construction`.`entry`          AS `entry`,
       `internal40_db`.`construction`.`abstract`       AS `abstract`,
       `internal40_db`.`construction`.`active`         AS `active`,
       `internal40_db`.`construction`.`idEntity`       AS `idEntity`,
       `internal40_db`.`construction`.`idLanguage`     AS `cxIdLanguage`,
       `internal40_db`.`entry`.`name`                  AS `name`,
       `internal40_db`.`entry`.`description`           AS `description`,
       `internal40_db`.`entry`.`idLanguage`            AS `idLanguage`
from (`internal40_db`.`construction` join `internal40_db`.`entry`
      on (`internal40_db`.`construction`.`idEntity` = `internal40_db`.`entry`.`idEntity`));


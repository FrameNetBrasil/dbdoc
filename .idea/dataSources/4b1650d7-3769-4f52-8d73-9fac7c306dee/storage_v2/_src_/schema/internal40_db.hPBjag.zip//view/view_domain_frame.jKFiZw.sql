create definer = fnbrasil@`%` view view_domain_frame as
select `d`.`idDomain`   AS `idDomain`,
       `d`.`entry`      AS `domainEntry`,
       `d`.`idEntity`   AS `domainIdEntity`,
       `d`.`name`       AS `domainName`,
       `f`.`idEntity`   AS `frameIdEntity`,
       `f`.`entry`      AS `frameEntry`,
       `f`.`name`       AS `frameName`,
       `f`.`idLanguage` AS `idLanguage`
from ((`internal40_db`.`view_domain` `d` join `internal40_db`.`entityrelation` `er`
       on (`d`.`idEntity` = `er`.`idEntity2`)) join `internal40_db`.`view_frame` `f`
      on (`er`.`idEntity1` = `f`.`idEntity`))
where `d`.`idLanguage` = `f`.`idLanguage`;


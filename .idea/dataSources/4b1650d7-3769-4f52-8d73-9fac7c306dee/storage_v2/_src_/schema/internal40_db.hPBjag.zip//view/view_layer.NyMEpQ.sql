create definer = fnbrasil@`%` view view_layer as
select `l`.`idLayer`                         AS `idLayer`,
       `l`.`rank`                            AS `rank`,
       `l`.`idAnnotationSet`                 AS `idAnnotationSet`,
       `l`.`idLayerType`                     AS `idLayerType`,
       `lt`.`entry`                          AS `entry`,
       `lt`.`idEntity`                       AS `idEntity`,
       `lt`.`layerOrder`                     AS `layerOrder`,
       `internal40_db`.`entry`.`name`        AS `name`,
       `internal40_db`.`entry`.`description` AS `description`,
       `internal40_db`.`entry`.`idLanguage`  AS `idLanguage`
from ((`internal40_db`.`layer` `l` join `internal40_db`.`layertype` `lt`
       on (`l`.`idLayerType` = `lt`.`idLayerType`)) join `internal40_db`.`entry`
      on (`lt`.`idEntity` = `internal40_db`.`entry`.`idEntity`));


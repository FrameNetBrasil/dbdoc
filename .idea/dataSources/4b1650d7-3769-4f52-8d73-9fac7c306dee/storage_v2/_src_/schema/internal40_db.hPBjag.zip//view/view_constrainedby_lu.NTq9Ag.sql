create definer = fnbrasil@`%` view view_constrainedby_lu as
select `e`.`idLanguage`           AS `idLanguage`,
       `e`.`name`                 AS `conName`,
       `c`.`idConstraint`         AS `idConstraint`,
       `c`.`idConstrained`        AS `idConstrained`,
       `c`.`idConstrainedBy`      AS `idConstrainedBy`,
       `c`.`constrainedByType`    AS `constrainedByType`,
       `c`.`idConstraintInstance` AS `idConstraintInstance`,
       `con`.`name`               AS `name`
from ((`internal40_db`.`view_constraint` `c` join `internal40_db`.`entry` `e`
       on (`c`.`idEntity` = `e`.`idEntity`)) join `internal40_db`.`lu` `con`
      on (`c`.`idConstrainedBy` = `con`.`idEntity`));


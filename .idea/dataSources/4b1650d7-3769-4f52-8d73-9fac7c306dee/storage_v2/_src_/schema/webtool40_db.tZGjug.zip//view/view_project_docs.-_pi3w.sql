create definer = fnbrasil@`%` view view_project_docs as
select distinct `p`.`idProject`      AS `idProject`,
                `p`.`name`           AS `projectName`,
                `p`.`idProjectGroup` AS `idProjectGroup`,
                `pg`.`name`          AS `projectGroup`,
                `c`.`idCorpus`       AS `idCorpus`,
                `c`.`name`           AS `corpusName`,
                `doc`.`idDocument`   AS `idDocument`,
                `doc`.`name`         AS `documentName`,
                `doc`.`idLanguage`   AS `idLanguage`
from (((((`webtool40_db`.`project` `p` join `webtool40_db`.`dataset` `d`
          on (`p`.`idProject` = `d`.`idProject`)) join `webtool40_db`.`dataset_corpus` `dc`
         on (`d`.`idDataset` = `dc`.`idDataset`)) join `webtool40_db`.`view_corpus` `c`
        on (`dc`.`idCorpus` = `c`.`idCorpus`)) join `webtool40_db`.`view_document` `doc`
       on (`c`.`idCorpus` = `doc`.`idCorpus`)) left join `webtool40_db`.`projectgroup` `pg`
      on (`p`.`idProjectGroup` = `pg`.`idProjectGroup`))
where `doc`.`idLanguage` = `c`.`idLanguage`;


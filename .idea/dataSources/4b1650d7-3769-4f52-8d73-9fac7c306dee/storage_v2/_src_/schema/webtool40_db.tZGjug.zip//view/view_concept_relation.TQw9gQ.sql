create definer = fnbrasil@`%` view view_concept_relation as
select `relation`.`idEntityRelation` AS `idEntityRelation`,
       `relation`.`idRelationType`   AS `idRelationType`,
       `relation`.`relationType`     AS `relationType`,
       `relation`.`nameCanonical`    AS `nameCanonical`,
       `relation`.`nameDirect`       AS `nameDirect`,
       `relation`.`nameInverse`      AS `nameInverse`,
       `relation`.`color`            AS `color`,
       `c1`.`name`                   AS `c1Name`,
       `c1`.`idConcept`              AS `c1IdConcept`,
       `c1`.`idEntity`               AS `c1IdEntity`,
       `c1`.`idLanguage`             AS `idLanguage`,
       `c2`.`name`                   AS `c2Name`,
       `c2`.`idConcept`              AS `c2IdConcept`,
       `c2`.`idEntity`               AS `c2IdEntity`
from ((`webtool40_db`.`view_concept` `c1` join `webtool40_db`.`view_relation` `relation`
       on (`c1`.`idEntity` = `relation`.`idEntity1`)) join `webtool40_db`.`view_concept` `c2`
      on (`relation`.`idEntity2` = `c2`.`idEntity`))
where `relation`.`relationType` in ('rel_subtypeof', 'rel_standsfor', 'rel_partwhole', 'rel_hasconcept')
  and `c1`.`idLanguage` = `c2`.`idLanguage`;


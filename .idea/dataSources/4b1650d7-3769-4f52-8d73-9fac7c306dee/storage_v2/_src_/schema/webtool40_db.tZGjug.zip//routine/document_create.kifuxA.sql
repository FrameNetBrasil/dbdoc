create
    definer = fnbrasil@`%` function document_create(par_json longtext) returns int
BEGIN 
   DECLARE v_entry VARCHAR(255);
   DECLARE v_name VARCHAR(255);
   DECLARE v_idCorpus INT;
   DECLARE v_idUser INT;
   INSERT INTO entity (type) values ('DOC');
   SET @idEntity = (SELECT last_insert_id());
   SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.name'));
   SET v_idCorpus = JSON_EXTRACT(par_json, '$.idCorpus');
   SET v_idUser = JSON_EXTRACT(par_json, '$.idUser');
   SET v_entry = LOWER(CONCAT('doc_', v_name));
   CALL entry_create(v_entry, v_name, @idEntity);
   SET @idAnnotationObject = annotationobject_create(0,'DOC');
   INSERT INTO document(entry,active,idGenre,idCorpus,idEntity,idAnnotationObject) values (v_entry, 1, 1, v_idCorpus, @idEntity,@idAnnotationObject);
   SET @idDocument = (SELECT last_insert_id());
   INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','document', @idDocument, v_idUser);
   RETURN @idDocument;
END;


create
    definer = fnbrasil@`%` function lexeme_delete(par_idLexeme int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM lexeme WHERE (idLexeme = par_idLexeme);
        DELETE FROM lexemeentry where (idLexeme = par_idLexeme);
        DELETE FROM wordform where (idLexeme = par_idLexeme);
        DELETE FROM lexeme where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','lexeme', par_idLexeme,par_idUser);
        RETURN par_idLexeme;
    END;


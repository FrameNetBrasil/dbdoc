create
    definer = fnbrasil@`%` function annotation_create(par_json longtext) returns int
BEGIN 
   DECLARE v_idEntity INT;
   DECLARE v_idAnnotationObject INT;
   DECLARE v_relationType VARCHAR(255);
   DECLARE v_idUserTask INT;
   DECLARE v_idRelationType INT;
   SET v_idEntity = JSON_EXTRACT(par_json, '$.idEntity');
   SET v_idAnnotationObject = JSON_EXTRACT(par_json, '$.idAnnotationObject');
   SET v_idUserTask = JSON_EXTRACT(par_json, '$.idUserTask');
   SET v_relationType = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.relationType'));
   SELECT idRelationType INTO v_idRelationType FROM relationtype where entry = v_relationType;
   INSERT INTO annotation (idEntity, idAnnotationObject, idUserTask, idRelationType) values (v_idEntity, v_idAnnotationObject, v_idUserTask, v_idRelationType);
   SET @idAnnotation = (SELECT last_insert_id());
   RETURN @idAnnotation;
END;


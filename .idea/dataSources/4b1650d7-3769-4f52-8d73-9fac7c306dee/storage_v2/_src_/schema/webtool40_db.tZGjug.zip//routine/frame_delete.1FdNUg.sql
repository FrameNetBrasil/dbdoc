create
    definer = fnbrasil@`%` function frame_delete(par_idFrame int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM frame WHERE (idFrame = par_idFrame);
        DELETE FROM entityrelation where (idEntity1 = v_idEntity) OR (idEntity2 = v_idEntity) OR (idEntity3 = v_idEntity);
        DELETE FROM entry where (idEntity = v_idEntity);
        DELETE FROM frameelement where (idFrame = par_idFrame);
        DELETE FROM lu where (idFrame = par_idFrame);
        DELETE FROM frame where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','frame', par_idFrame,par_idUser);
        RETURN par_idFrame;
    END;


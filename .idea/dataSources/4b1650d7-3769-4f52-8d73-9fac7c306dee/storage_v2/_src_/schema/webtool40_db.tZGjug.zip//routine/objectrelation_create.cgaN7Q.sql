create
    definer = fnbrasil@`%` function objectrelation_create(par_json longtext) returns int
BEGIN 
   DECLARE v_idAnnotationObject1 INT;
   DECLARE v_idAnnotationObject2 INT;
   DECLARE v_relationType VARCHAR(255);
   DECLARE v_idRelationType INT;
   SET v_idAnnotationObject1 = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.idAnnotationObject1'));
   SET v_idAnnotationObject2 = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.idAnnotationObject2'));
   SET v_relationType = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.relationType'));
   SELECT idRelationType INTO v_idRelationType FROM relationtype where entry = v_relationType;
   INSERT INTO annotationobjectrelation (idAnnotationObject1, idAnnotationObject2, idRelationType) values (v_idAnnotationObject1, v_idAnnotationObject2, v_idRelationType);
   SET @idAnnotationObjectRelation = (SELECT last_insert_id());
   RETURN @idAnnotationObjectRelation;
END;


create
    definer = fnbrasil@`%` function fe_create(par_idFrame int, par_name varchar(255), par_coreType char(32),
                                              par_idColor int, par_idUser int) returns int
BEGIN
		DECLARE entry VARCHAR(255);
        set entry = CONCAT('fe_', LOWER(par_name));
		INSERT INTO entity (type) values ('FE');
        SET @idEntity = (SELECT last_insert_id());
        CALL entry_create(entry, par_name, @idEntity);
        INSERT INTO frameelement(idFrame, entry, coreType, idColor, idEntity) values (par_idFrame, entry, par_coreType, par_idColor, @idEntity);
        SET @idFrameElement = (SELECT last_insert_id());
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id) VALUES (NOW(),'user','C','frameelement', @idFrameElement);
        RETURN @idFrameElement;
    END;


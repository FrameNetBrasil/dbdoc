create definer = fnbrasil@`%` trigger video_BEFORE_INSERT
    before insert
    on video
    for each row
BEGIN
IF (NEW.idAnnotationObject = 0) THEN
	SET NEW.idAnnotationObject = annotationobject_create(0,'VID');
END IF;    
END;


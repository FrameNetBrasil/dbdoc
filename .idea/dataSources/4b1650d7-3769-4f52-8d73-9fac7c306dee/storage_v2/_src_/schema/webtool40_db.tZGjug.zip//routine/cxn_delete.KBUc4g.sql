create
    definer = fnbrasil@`%` function cxn_delete(par_idConstruction int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM frame WHERE (idConstruction = par_idConstruction);
        DELETE FROM entityrelation where (idEntity1 = v_idEntity) OR (idEntity2 = v_idEntity) OR (idEntity3 = v_idEntity);
        DELETE FROM entry where (idEntity = v_idEntity);
        DELETE FROM constructionelement where (idConstruction = par_idConstruction);
        DELETE FROM construction where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','construction', par_idConstruction,par_idUser);
        RETURN par_idConstruction;
    END;


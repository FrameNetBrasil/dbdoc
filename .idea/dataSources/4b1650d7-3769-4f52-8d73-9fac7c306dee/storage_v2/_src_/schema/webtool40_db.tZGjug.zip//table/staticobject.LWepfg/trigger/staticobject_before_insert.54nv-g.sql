create definer = fnbrasil@`%` trigger staticobject_BEFORE_INSERT
    before insert
    on staticobject
    for each row
BEGIN
IF (NEW.idAnnotationObject = 0) THEN
	SET NEW.idAnnotationObject = annotationobject_create(0,'SOB');
END IF;    
END;


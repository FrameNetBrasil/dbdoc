create definer = fnbrasil@`%` trigger token_AFTER_DELETE
    after delete
    on token
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


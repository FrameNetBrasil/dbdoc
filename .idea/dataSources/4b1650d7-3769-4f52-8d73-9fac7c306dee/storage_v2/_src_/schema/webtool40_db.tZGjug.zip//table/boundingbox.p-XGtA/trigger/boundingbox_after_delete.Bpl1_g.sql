create definer = fnbrasil@`%` trigger boundingbox_AFTER_DELETE
    after delete
    on boundingbox
    for each row
BEGIN
   DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


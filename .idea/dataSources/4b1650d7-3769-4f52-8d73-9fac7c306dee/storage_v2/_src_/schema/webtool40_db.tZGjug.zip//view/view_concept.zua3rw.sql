create definer = fnbrasil@`%` view view_concept as
select `cp`.`idConcept`                     AS `idConcept`,
       `cp`.`entry`                         AS `entry`,
       `cp`.`idEntity`                      AS `idEntity`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `ti`.`name`                          AS `tiName`,
       `ti`.`description`                   AS `tiDescription`,
       `ti`.`nick`                          AS `tiNick`
from ((`webtool40_db`.`concept` `cp` join `webtool40_db`.`entry`
       on (`cp`.`idEntity` = `webtool40_db`.`entry`.`idEntity`)) join `webtool40_db`.`view_typeinstance` `ti`
      on (`cp`.`idTypeInstance` = `ti`.`idTypeInstance`))
where `webtool40_db`.`entry`.`idLanguage` = `ti`.`idLanguage`;


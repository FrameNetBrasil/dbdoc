create definer = fnbrasil@`%` view view_constrainedby_lustandsforlu as
select `e`.`idLanguage`        AS `idLanguage`,
       `e`.`name`              AS `conName`,
       `rt`.`idEntityRelation` AS `idConstraint`,
       `rt`.`idEntity1`        AS `idConstrained`,
       `rt`.`idEntity2`        AS `idConstrainedBy`,
       `rt`.`entity2Type`      AS `constrainedByType`,
       `rt`.`idEntityRelation` AS `idConstraintInstance`,
       `lu`.`name`             AS `name`
from ((`webtool40_db`.`view_relation` `rt` join `webtool40_db`.`entry` `e`
       on (`rt`.`idEntity` = `e`.`idEntity`)) join `webtool40_db`.`view_lu` `lu`
      on (`rt`.`idEntity2` = `lu`.`idEntity`))
where `rt`.`relationType` = 'rel_lustandsforlu';


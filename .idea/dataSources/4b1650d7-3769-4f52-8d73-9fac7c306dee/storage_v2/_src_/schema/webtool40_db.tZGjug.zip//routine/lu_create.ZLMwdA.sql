create
    definer = fnbrasil@`%` function lu_create(par_lu longtext) returns int
BEGIN
		DECLARE v_name VARCHAR(255);
        DECLARE v_idFrame INT;
        DECLARE v_incorporatedFE INT;
        DECLARE v_senseDescription VARCHAR(4000);
        DECLARE v_idLemma INT;
        DECLARE v_idUser INT;
        INSERT INTO entity (type) values ('LU');
        SET @idEntity = (SELECT last_insert_id());
        SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_lu, '$.name'));
        SET v_idFrame = JSON_EXTRACT(par_lu, '$.idFrame');
        IF (JSON_EXTRACT(par_lu, '$.incorporatedFE')) THEN
			SET v_incorporatedFE = JSON_EXTRACT(par_lu, '$.incorporatedFE');
        END IF;    
        SET v_senseDescription = JSON_UNQUOTE(JSON_EXTRACT(par_lu, '$.senseDescription'));
        SET v_idLemma = JSON_EXTRACT(par_lu, '$.idLemma');
        SET v_idUser = JSON_EXTRACT(par_lu, '$.idUser');
        INSERT INTO lu(idFrame, name, senseDescription, importNum, active, incorporatedFE, idLemma, idEntity) values (v_idFrame, v_name, v_senseDescription, 0, 1, v_incorporatedFE, v_idLemma, @idEntity);
        SET @idLU = (SELECT last_insert_id());
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','lu', @idLU, v_idUser);
        RETURN @idLU;
    END;


create definer = fnbrasil@`%` view view_constraint as
select `ci`.`idEntityRelation` AS `idConstraintInstance`,
       `ct`.`entry`            AS `entry`,
       `ci`.`idEntity1`        AS `idConstraint`,
       `e1`.`type`             AS `constraintType`,
       `ci`.`idEntity2`        AS `idConstrained`,
       `e2`.`type`             AS `constrainedType`,
       `ci`.`idEntity3`        AS `idConstrainedBy`,
       `e3`.`type`             AS `constrainedByType`,
       `ct`.`idRelationType`   AS `idConstraintType`,
       `ct`.`idEntity`         AS `idEntity`,
       `ct`.`prefix`           AS `prefix`
from ((((`webtool40_db`.`entityrelation` `ci` join `webtool40_db`.`relationtype` `ct`
         on (`ci`.`idRelationType` = `ct`.`idRelationType`)) join `webtool40_db`.`entity` `e1`
        on (`ci`.`idEntity1` = `e1`.`idEntity`)) join `webtool40_db`.`entity` `e2`
       on (`ci`.`idEntity2` = `e2`.`idEntity`)) left join `webtool40_db`.`entity` `e3`
      on (`ci`.`idEntity3` = `e3`.`idEntity`))
where `ct`.`idRelationGroup` = 6;


create
    definer = fnbrasil@`%` function user_delete(par_idUser int) returns int
BEGIN
        DELETE FROM user_group WHERE (idUser = par_idUser);
        DELETE FROM timeline WHERE (idUser = par_idUser);
        DELETE FROM user WHERE (idUser = par_idUser);
        RETURN par_idUser;
    END;


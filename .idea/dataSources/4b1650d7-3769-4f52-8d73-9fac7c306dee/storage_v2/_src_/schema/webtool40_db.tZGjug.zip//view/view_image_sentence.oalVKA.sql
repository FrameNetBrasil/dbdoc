create definer = fnbrasil@`%` view view_image_sentence as
select `aor`.`idAnnotationObjectRelation` AS `idImageSentence`,
       `i`.`idImage`                      AS `idImage`,
       `s`.`idSentence`                   AS `idSentence`
from ((`webtool40_db`.`annotationobjectrelation` `aor` join `webtool40_db`.`image` `i`
       on (`aor`.`idAnnotationObject1` = `i`.`idAnnotationObject`)) join `webtool40_db`.`sentence` `s`
      on (`aor`.`idAnnotationObject2` = `s`.`idAnnotationObject`));


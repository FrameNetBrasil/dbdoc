create definer = fnbrasil@`%` trigger token_BEFORE_INSERT
    before insert
    on token
    for each row
BEGIN
	SET NEW.idAnnotationObject = annotationobject_create(0,'TOK');
END;


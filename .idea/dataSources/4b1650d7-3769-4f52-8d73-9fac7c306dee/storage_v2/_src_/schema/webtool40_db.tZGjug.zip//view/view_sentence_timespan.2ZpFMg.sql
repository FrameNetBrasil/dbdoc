create definer = fnbrasil@`%` view view_sentence_timespan as
select `s`.`idSentence`         AS `idSentence`,
       `s`.`text`               AS `text`,
       `s`.`idLanguage`         AS `idLanguageSentence`,
       `s`.`idAnnotationObject` AS `idAnnotationObject`,
       `s`.`idOriginMM`         AS `idOriginMM`,
       `t`.`idTimespan`         AS `idTimeSpan`,
       `t`.`startTime`          AS `startTime`,
       `t`.`endTime`            AS `endTime`
from ((`webtool40_db`.`sentence` `s` join `webtool40_db`.`annotationobjectrelation` `r`
       on (`s`.`idAnnotationObject` = `r`.`idAnnotationObject1`)) join `webtool40_db`.`timespan` `t`
      on (`r`.`idAnnotationObject2` = `t`.`idAnnotationObject`));


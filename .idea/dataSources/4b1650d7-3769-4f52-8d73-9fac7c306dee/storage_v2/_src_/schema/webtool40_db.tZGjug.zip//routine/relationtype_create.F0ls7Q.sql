create
    definer = fnbrasil@`%` function relationtype_create(par_json longtext) returns int
BEGIN 
   DECLARE v_nameCanonical VARCHAR(255);
   DECLARE v_entry VARCHAR(255);
   DECLARE v_nameDirect VARCHAR(255);
   DECLARE v_nameInverse VARCHAR(255);
   DECLARE v_color VARCHAR(255);
   DECLARE v_prefix VARCHAR(255);
   DECLARE v_idRelationGroup INT;
   DECLARE v_idUser INT;
   INSERT INTO entity (type) values ('RTY');
   SET @idEntity = (SELECT last_insert_id());
   SET v_nameCanonical = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.nameCanonical'));
   SET v_nameDirect = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.nameDirect'));
   SET v_nameInverse = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.nameInverse'));
   SET v_color = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.color'));
   SET v_prefix = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.prefix'));
   SET v_idRelationGroup = JSON_EXTRACT(par_json, '$.idRelationGroup');
   SET v_idUser = JSON_EXTRACT(par_json, '$.idUser');
   SET v_entry = CONCAT('rel_',lower(v_nameCanonical));
   CALL entry_create(v_entry, v_nameCanonical, @idEntity);
   INSERT INTO relationtype(entry,nameCanonical,nameDirect,nameInverse,color,prefix,idRelationGroup,idEntity) values (v_entry, v_nameCanonical, v_nameDirect, v_nameInverse, v_color, v_prefix, v_idRelationGroup,@idEntity);
   SET @idRelationType = (SELECT last_insert_id());
   INSERT INTO timeline (tlDateTime,author,operation,tableName,id, idUser) VALUES (NOW(),'user','C','relationtype', @idRelationType, v_idUser);
   RETURN @idRelationType;
END;


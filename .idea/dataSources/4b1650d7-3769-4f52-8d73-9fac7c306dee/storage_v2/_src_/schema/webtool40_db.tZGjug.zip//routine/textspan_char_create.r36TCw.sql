create
    definer = fnbrasil@`%` function textspan_char_create(par_json longtext) returns int
BEGIN 
   DECLARE v_startChar INT;
   DECLARE v_endChar INT;
   DECLARE v_multi INT;
   DECLARE v_idLayer INT;
   DECLARE v_idInstantiationType INT;
   SET v_startChar = JSON_EXTRACT(par_json, '$.startChar');
   SET v_endChar = JSON_EXTRACT(par_json, '$.endChar');
   SET v_multi = JSON_EXTRACT(par_json, '$.multi');
   SET v_idLayer = JSON_EXTRACT(par_json, '$.idLayer');
   SET v_idInstantiationType = JSON_EXTRACT(par_json, '$.idInstantiationType');
   SET @idAnnotationObject = annotationobject_create(0,'TXS');
   INSERT INTO textspan (startChar, endChar, multi, idLayer, idInstantiationType, idAnnotationObject) values (v_startChar, v_endChar, v_multi, v_idLayer, v_idInstantiationType, @idAnnotationObject);
   SET @idTextSpan = (SELECT last_insert_id());
   RETURN @idTextSpan;
END;


create
    definer = fnbrasil@`%` function layertype_delete(par_idLayerType int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM layertype WHERE (idLayerType = par_idLayerType);
        DELETE FROM entry where (idEntity = v_idEntity);
        DELETE FROM layertype where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','layertype', par_idLayerType,par_idUser);
        RETURN par_idLayerType;
    END;


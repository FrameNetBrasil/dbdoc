create definer = fnbrasil@`%` view view_document_wordmm as
select `w`.`idWordMM`           AS `idWordMM`,
       `w`.`word`               AS `word`,
       `w`.`startTime`          AS `startTime`,
       `w`.`endTime`            AS `endTime`,
       `w`.`origin`             AS `origin`,
       `w`.`idDocumentSentence` AS `idDocumentSentence`,
       `ds`.`idDocument`        AS `idDocument`,
       `ds`.`idSentence`        AS `idSentence`
from (`webtool40_db`.`wordmm` `w` join `webtool40_db`.`view_document_sentence` `ds`
      on (`w`.`idDocumentSentence` = `ds`.`idDocumentSentence`));


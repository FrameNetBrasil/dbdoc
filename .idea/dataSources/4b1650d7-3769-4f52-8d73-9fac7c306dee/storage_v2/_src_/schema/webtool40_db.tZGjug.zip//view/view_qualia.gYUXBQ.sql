create definer = fnbrasil@`%` view view_qualia as
select `eq`.`idLanguage`          AS `idLanguage`,
       `q`.`idQualia`             AS `idQualia`,
       substr(`t`.`entry`, 5, 15) AS `type`,
       `q`.`info`                 AS `info`,
       `q`.`infoInverse`          AS `infoinverse`,
       `q`.`idEntity`             AS `idEntity`,
       `eq`.`name`                AS `name`,
       `eq`.`description`         AS `description`,
       `q`.`idTypeInstance`       AS `idTypeInstance`,
       `f`.`idFrame`              AS `idFrame`,
       `f`.`name`                 AS `frameName`,
       `fe1`.`idFrameElement`     AS `idFrameElement1`,
       `fe1`.`name`               AS `fe1Name`,
       `fe2`.`idFrameElement`     AS `idFrameElement2`,
       `fe2`.`name`               AS `fe2Name`
from (((((`webtool40_db`.`qualia` `q` join `webtool40_db`.`entry` `eq`
          on (`q`.`idEntity` = `eq`.`idEntity`)) join `webtool40_db`.`typeinstance` `t`
         on (`q`.`idTypeInstance` = `t`.`idTypeInstance`)) left join `webtool40_db`.`view_frame` `f`
        on (`q`.`idFrame` = `f`.`idFrame`)) left join `webtool40_db`.`view_frameelement` `fe1`
       on (`q`.`idFrameElement1` = `fe1`.`idFrameElement`)) left join `webtool40_db`.`view_frameelement` `fe2`
      on (`q`.`idFrameElement2` = `fe2`.`idFrameElement`))
where (`f`.`idLanguage` = `eq`.`idLanguage` or `f`.`idLanguage` is null)
  and (`fe1`.`idLanguage` = `eq`.`idLanguage` or `fe1`.`idLanguage` is null)
  and (`fe2`.`idLanguage` = `eq`.`idLanguage` or `fe2`.`idLanguage` is null);


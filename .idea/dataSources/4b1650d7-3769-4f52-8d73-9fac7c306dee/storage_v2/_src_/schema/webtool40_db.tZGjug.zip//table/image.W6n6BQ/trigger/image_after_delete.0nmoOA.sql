create definer = fnbrasil@`%` trigger image_AFTER_DELETE
    after delete
    on image
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


create definer = fnbrasil@`%` trigger textspan_AFTER_DELETE
    after delete
    on textspan
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


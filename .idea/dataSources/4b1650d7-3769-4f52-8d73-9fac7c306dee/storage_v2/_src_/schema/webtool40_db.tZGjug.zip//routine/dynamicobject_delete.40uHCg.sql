create
    definer = fnbrasil@`%` function dynamicobject_delete(par_idDynamicObject int, par_idUser int) returns int
BEGIN
		DECLARE v_idAnnotationObject INT;
        SELECT idAnnotationObject INTO v_idAnnotationObject FROM dynamicobject WHERE (idDynamicObject = par_idDynamicObject);
        DELETE FROM annotation WHERE idAnnotationObject = v_idAnnotationObject;
        DELETE FROM annotationobjectrelation WHERE (idAnnotationObject1 = v_idAnnotationObject) oR (idAnnotationObject2 = v_idAnnotationObject);
		DELETE FROM dynamicobject WHERE idDynamicObject = par_idDynamicObject;	
        DELETE FROM annotationobject WHERE idAnnotationObject = v_idAnnotationObject;
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','dynamicobject', par_idDynamicObject,par_idUser);
        RETURN par_idDynamicObject;
    END;


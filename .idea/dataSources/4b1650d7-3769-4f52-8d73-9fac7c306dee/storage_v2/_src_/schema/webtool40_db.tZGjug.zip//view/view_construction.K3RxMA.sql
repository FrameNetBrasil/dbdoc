create definer = fnbrasil@`%` view view_construction as
select `webtool40_db`.`construction`.`idConstruction` AS `idConstruction`,
       `webtool40_db`.`construction`.`entry`          AS `entry`,
       `webtool40_db`.`construction`.`abstract`       AS `abstract`,
       `webtool40_db`.`construction`.`active`         AS `active`,
       `webtool40_db`.`construction`.`idEntity`       AS `idEntity`,
       `webtool40_db`.`construction`.`idLanguage`     AS `cxIdLanguage`,
       `webtool40_db`.`entry`.`name`                  AS `name`,
       `webtool40_db`.`entry`.`description`           AS `description`,
       `webtool40_db`.`entry`.`idLanguage`            AS `idLanguage`
from (`webtool40_db`.`construction` join `webtool40_db`.`entry`
      on (`webtool40_db`.`construction`.`idEntity` = `webtool40_db`.`entry`.`idEntity`));


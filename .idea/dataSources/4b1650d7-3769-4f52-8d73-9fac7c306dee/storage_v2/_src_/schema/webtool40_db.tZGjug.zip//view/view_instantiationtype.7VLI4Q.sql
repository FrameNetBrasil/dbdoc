create definer = fnbrasil@`%` view view_instantiationtype as
select `ti`.`idTypeInstance`                AS `idInstantiationType`,
       `ti`.`entry`                         AS `entry`,
       `ti`.`info`                          AS `info`,
       `ti`.`flag`                          AS `flag`,
       `ti`.`idTypeInstance`                AS `idTypeInstance`,
       `ti`.`idType`                        AS `idType`,
       `ti`.`idColor`                       AS `idColor`,
       `ti`.`idEntity`                      AS `idEntity`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`
from ((`webtool40_db`.`typeinstance` `ti` join `webtool40_db`.`type`
       on (`ti`.`idType` = `webtool40_db`.`type`.`idType`)) join `webtool40_db`.`entry`
      on (`ti`.`idEntity` = `webtool40_db`.`entry`.`idEntity`))
where `webtool40_db`.`type`.`entry` = 'typ_instantiationtype';


create definer = fnbrasil@`%` trigger staticobject_AFTER_DELETE
    after delete
    on staticobject
    for each row
BEGIN
   DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


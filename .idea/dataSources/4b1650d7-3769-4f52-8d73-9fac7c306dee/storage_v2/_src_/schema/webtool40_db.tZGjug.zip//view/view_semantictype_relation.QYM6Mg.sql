create definer = fnbrasil@`%` view view_semantictype_relation as
select `relation`.`idEntityRelation` AS `idEntityRelation`,
       `relation`.`idRelationType`   AS `idRelationType`,
       `relation`.`relationType`     AS `relationType`,
       `relation`.`nameCanonical`    AS `nameCanonical`,
       `relation`.`nameDirect`       AS `nameDirect`,
       `relation`.`nameInverse`      AS `nameInverse`,
       `relation`.`color`            AS `color`,
       `st1`.`name`                  AS `st1Name`,
       `st1`.`idSemanticType`        AS `st1IdSemanticType`,
       `st1`.`idEntity`              AS `st1IdEntity`,
       `st1`.`idLanguage`            AS `idLanguage`,
       `st2`.`name`                  AS `st2Name`,
       `st2`.`idSemanticType`        AS `st2IdSemanticType`,
       `st2`.`idEntity`              AS `stIdEntity`
from ((`webtool40_db`.`view_semantictype` `st1` join `webtool40_db`.`view_relation` `relation`
       on (`st1`.`idEntity` = `relation`.`idEntity1`)) join `webtool40_db`.`view_semantictype` `st2`
      on (`relation`.`idEntity2` = `st2`.`idEntity`))
where `relation`.`relationType` = 'rel_subtypeof'
  and `st1`.`idLanguage` = `st2`.`idLanguage`;


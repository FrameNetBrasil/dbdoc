create definer = fnbrasil@`%` view view_alloweddocs as
select distinct `allowed`.`idCorpus`     AS `idCorpus`,
                `allowed`.`corpusName`   AS `corpusName`,
                `allowed`.`idDocument`   AS `idDocument`,
                `allowed`.`documentName` AS `documentName`,
                `allowed`.`idUser`       AS `idUser`,
                `allowed`.`idLanguage`   AS `idLanguage`
from (select `c`.`idCorpus`     AS `idCorpus`,
             `c`.`name`         AS `corpusName`,
             `doc`.`idDocument` AS `idDocument`,
             `doc`.`name`       AS `documentName`,
             `ut`.`idUser`      AS `idUser`,
             `doc`.`idLanguage` AS `idLanguage`
      from (((`webtool40_db`.`usertask` `ut` join `webtool40_db`.`usertask_document` `utd`
              on (`ut`.`idUserTask` = `utd`.`idUserTask`)) join `webtool40_db`.`view_document` `doc`
             on (`utd`.`idDocument` = `doc`.`idDocument`)) join `webtool40_db`.`view_corpus` `c`
            on (`doc`.`idCorpus` = `c`.`idCorpus`))
      where `ut`.`isActive` = 1
        and `doc`.`idLanguage` = `c`.`idLanguage`
      union
      select `c`.`idCorpus`     AS `idCorpus`,
             `c`.`name`         AS `corpusName`,
             `doc`.`idDocument` AS `idDocument`,
             `doc`.`name`       AS `documentName`,
             `ut`.`idUser`      AS `idUser`,
             `doc`.`idLanguage` AS `idLanguage`
      from (((`webtool40_db`.`usertask` `ut` join `webtool40_db`.`usertask_document` `utd`
              on (`ut`.`idUserTask` = `utd`.`idUserTask`)) join `webtool40_db`.`view_corpus` `c`
             on (`utd`.`idCorpus` = `c`.`idCorpus`)) join `webtool40_db`.`view_document` `doc`
            on (`c`.`idCorpus` = `doc`.`idCorpus`))
      where `utd`.`idDocument` is null
        and `ut`.`isActive` = 1
        and `doc`.`idLanguage` = `c`.`idLanguage`) `allowed`;


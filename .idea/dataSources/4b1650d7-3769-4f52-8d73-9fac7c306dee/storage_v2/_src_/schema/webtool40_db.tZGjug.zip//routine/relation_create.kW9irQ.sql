create
    definer = fnbrasil@`%` function relation_create(par_json longtext) returns int
BEGIN
		DECLARE v_relationType VARCHAR(255);
		DECLARE v_idEntity1 INT;
		DECLARE v_idEntity2 INT;
		DECLARE v_idEntity3 INT DEFAULT NULL;
		DECLARE v_idRelation INT DEFAULT NULL;
        DECLARE v_idUser INT;
		DECLARE v_idRelationType INT;
        SET v_relationType = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.relationType'));
        SET v_idEntity1 = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.idEntity1'));
        SET v_idEntity2 = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.idEntity2'));
        IF JSON_EXTRACT(par_json, '$.idEntity3') THEN
           SET v_idEntity3 = JSON_EXTRACT(par_json, '$.idEntity3');
        END IF;   
        IF (JSON_EXTRACT(par_json, '$.idRelation')) THEN 
			SET v_idRelation = JSON_EXTRACT(par_json, '$.idRelation');
        END IF;    
        SET v_idUser = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.idUser'));
SELECT 
    idRelationType
INTO v_idRelationType FROM
    relationtype
WHERE
    entry = v_relationType;
		INSERT INTO entityrelation (idRelationType, idEntity1, idEntity2, idEntity3, idRelation) values (v_idRelationType, v_idEntity1, v_idEntity2, v_idEntity3, v_idRelation);
        SET @idEntityRelation = (SELECT last_insert_id());
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id, idUser) VALUES (NOW(),'user','C','entityrelation', @idEntityRelation, v_idUser);
        RETURN @idEntityRelation;
    END;


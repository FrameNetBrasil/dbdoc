create
    definer = fnbrasil@`%` function genericlabel_delete(par_idGenericLabel int, par_idUser int) returns int
BEGIN
		DECLARE v_idEntity INT;
		SELECT idEntity INTO v_idEntity FROM genericlabel WHERE (idGenericLabel = par_idGenericLabel);
        DELETE FROM genericlabel where (idEntity = v_idEntity);
        DELETE FROM entity where (idEntity = v_idEntity);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','genericlabel', par_idGenericLabel,par_idUser);
        RETURN par_idGenericLabel;
    END;


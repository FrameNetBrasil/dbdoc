create
    definer = fnbrasil@`%` function dynamicobject_create(par_json longtext) returns int
BEGIN 
   DECLARE v_name VARCHAR(255);
   DECLARE v_startFrame INT;
   DECLARE v_endFrame INT;
   DECLARE v_startTime FLOAT;
   DECLARE v_endTime FLOAT;
   DECLARE v_status INT;
   DECLARE v_origin INT;
   DECLARE v_idUser INT;
   SET v_name  = JSON_UNQUOTE(JSON_EXTRACT(par_json, '$.name'));
   SET v_startFrame  = JSON_EXTRACT(par_json, '$.startFrame');
   SET v_endFrame  = JSON_EXTRACT(par_json, '$.endFrame');
   SET v_startTime  = JSON_EXTRACT(par_json, '$.startTime');
   SET v_endTime  = JSON_EXTRACT(par_json, '$.endTime');
   SET v_status = JSON_EXTRACT(par_json, '$.status');
   SET v_origin = JSON_EXTRACT(par_json, '$.origin');
   SET v_idUser = JSON_EXTRACT(par_json, '$.idUser');
   SET @idAnnotationObject = annotationobject_create(0,'DOB');
   INSERT INTO dynamicobject (name,startFrame,endFrame,startTime,endTime,status,origin,idAnnotationObject)
	values (v_name,v_startFrame,v_endFrame,v_startTime,v_endTime,v_status,v_origin,@idAnnotationObject);
   SET @idDynamicObject = (SELECT last_insert_id());
   INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','dynamicobject', @idDynamicObject,v_idUser);
   RETURN @idDynamicObject;
END;


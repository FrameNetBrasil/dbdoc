create
    definer = fnbrasil@`%` function dataset_create(par_dataset longtext) returns int
BEGIN
		DECLARE v_name VARCHAR(255);
        DECLARE v_description VARCHAR(4000);
        DECLARE v_idProject INT;
        DECLARE v_idUser INT;
        SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_dataset, '$.name'));
        SET v_description = JSON_UNQUOTE(JSON_EXTRACT(par_dataset, '$.description'));
        SET v_idProject = JSON_EXTRACT(par_dataset, '$.idProject');
        SET v_idUser = JSON_EXTRACT(par_dataset, '$.idUser');
        INSERT INTO dataset(name,description) values (v_name, v_description);
        SET @idDataset = (SELECT last_insert_id());
        INSERT INTO project_dataset(idProject,idDataset) values (v_idProject, @idDataset);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','dataset', @idDataset, v_idUser);
        RETURN @idDataset;
    END;


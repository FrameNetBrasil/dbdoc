create definer = fnbrasil@`%` view view_wflexemelemma as
select `wf`.`idWordForm`    AS `idWordForm`,
       `wf`.`form`          AS `form`,
       `wf`.`md5`           AS `md5`,
       `lx`.`idLexeme`      AS `idLexeme`,
       `lx`.`name`          AS `lexeme`,
       `pos1`.`idPOS`       AS `idPOSLexeme`,
       `pos1`.`POS`         AS `POSLexeme`,
       `lx`.`idLanguage`    AS `idLanguage`,
       `le`.`idLexemeEntry` AS `idLexemeEntry`,
       `le`.`lexemeOrder`   AS `lexemeOrder`,
       `le`.`breakBefore`   AS `breakBefore`,
       `le`.`headWord`      AS `headWord`,
       `lm`.`idLemma`       AS `idLemma`,
       `lm`.`name`          AS `lemma`,
       `pos2`.`idPOS`       AS `idPOSLemma`,
       `pos2`.`POS`         AS `POSLemma`,
       `lang`.`language`    AS `language`
from ((((((`webtool40_db`.`wordform` `wf` join `webtool40_db`.`lexeme` `lx`
           on (`wf`.`idLexeme` = `lx`.`idLexeme`)) join `webtool40_db`.`pos` `pos1`
          on (`lx`.`idPOS` = `pos1`.`idPOS`)) join `webtool40_db`.`language` `lang`
         on (`lx`.`idLanguage` = `lang`.`idLanguage`)) left join `webtool40_db`.`lexemeentry` `le`
        on (`lx`.`idLexeme` = `le`.`idLexeme`)) left join `webtool40_db`.`lemma` `lm`
       on (`le`.`idLemma` = `lm`.`idLemma`)) left join `webtool40_db`.`pos` `pos2` on (`lm`.`idPOS` = `pos2`.`idPOS`))
where `lm`.`idLanguage` = `lx`.`idLanguage`
   or `lm`.`idLanguage` is null;

-- comment on column view_wflexemelemma.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


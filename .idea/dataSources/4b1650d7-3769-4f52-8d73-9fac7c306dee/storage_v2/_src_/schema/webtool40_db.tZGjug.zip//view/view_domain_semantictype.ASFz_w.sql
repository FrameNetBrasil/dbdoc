create definer = fnbrasil@`%` view view_domain_semantictype as
select `d`.`idDomain`    AS `idDomain`,
       `d`.`entry`       AS `domainEntry`,
       `d`.`idEntity`    AS `domainIdEntity`,
       `d`.`name`        AS `domainName`,
       `st`.`idEntity`   AS `stIdEntity`,
       `st`.`entry`      AS `stEntry`,
       `st`.`name`       AS `stName`,
       `st`.`idLanguage` AS `idLanguage`
from (`webtool40_db`.`view_domain` `d` join `webtool40_db`.`view_semantictype` `st`
      on (`d`.`idDomain` = `st`.`idDomain`))
where `d`.`idLanguage` = `st`.`idLanguage`;


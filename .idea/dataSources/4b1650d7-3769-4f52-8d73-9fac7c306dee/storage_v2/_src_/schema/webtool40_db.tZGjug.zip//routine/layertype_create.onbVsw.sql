create
    definer = fnbrasil@`%` function layertype_create(par_layertype longtext) returns int
BEGIN
	DECLARE v_nameEn VARCHAR(255);
	DECLARE v_entry VARCHAR(255);
    DECLARE v_allowsApositional INT;
    DECLARE v_isAnnotation INT;
    DECLARE v_layerOrder INT;
    DECLARE v_idLayerGroup INT;
    DECLARE v_idUser INT;
    INSERT INTO entity (type) values ('LTY');
	SET @idEntity = (SELECT last_insert_id());
    SET v_allowsApositional = JSON_EXTRACT(par_layertype, '$.allowsApositional');
    SET v_isAnnotation = JSON_EXTRACT(par_layertype, '$.isAnnotation');
    SET v_layerOrder = JSON_EXTRACT(par_layertype, '$.layerOrder');
    SET v_idLayerGroup = JSON_EXTRACT(par_layertype, '$.idLayerGroup');
    SET v_nameEn = JSON_UNQUOTE(JSON_EXTRACT(par_layertype, '$.nameEn'));
    SET v_entry = CONCAT('lty_',lower(v_nameEn));
    CALL entry_create(v_entry, v_nameEn, @idEntity);
    INSERT INTO layertype(entry, allowsApositional, isAnnotation, layerOrder, idLayerGroup, idEntity) values (v_entry,v_allowsApositional, v_isAnnotation, v_layerOrder, v_idLayerGroup, @idEntity);
    SET @idLayerType = (SELECT last_insert_id());
    SET v_idUser = JSON_EXTRACT(par_layertype, '$.idUser');
    INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','layertype', @idLayerType, v_idUser);
    RETURN @idLayerType;
 END;


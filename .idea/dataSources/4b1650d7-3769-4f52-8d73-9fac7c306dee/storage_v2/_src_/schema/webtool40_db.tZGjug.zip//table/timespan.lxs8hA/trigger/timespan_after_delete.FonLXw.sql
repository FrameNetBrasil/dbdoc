create definer = fnbrasil@`%` trigger timespan_AFTER_DELETE
    after delete
    on timespan
    for each row
BEGIN
	DELETE FROM annotationobject where idAnnotationObject = OLD.idAnnotationObject;
END;


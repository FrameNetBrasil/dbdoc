create definer = fnbrasil@`%` view view_document as
select `webtool40_db`.`document`.`idDocument`         AS `idDocument`,
       `webtool40_db`.`document`.`author`             AS `author`,
       `webtool40_db`.`document`.`active`             AS `active`,
       `webtool40_db`.`document`.`idGenre`            AS `idGenre`,
       `webtool40_db`.`document`.`idCorpus`           AS `idCorpus`,
       `webtool40_db`.`document`.`idEntity`           AS `idEntity`,
       `webtool40_db`.`document`.`idAnnotationObject` AS `idAnnotationObject`,
       `view_corpus`.`name`                           AS `corpusName`,
       `view_corpus`.`description`                    AS `corpusDescription`,
       `webtool40_db`.`entry`.`name`                  AS `name`,
       `webtool40_db`.`entry`.`description`           AS `description`,
       `webtool40_db`.`entry`.`idLanguage`            AS `idLanguage`
from ((`webtool40_db`.`document` join `webtool40_db`.`view_corpus`
       on (`webtool40_db`.`document`.`idCorpus` = `view_corpus`.`idCorpus`)) join `webtool40_db`.`entry`
      on (`webtool40_db`.`document`.`idEntity` = `webtool40_db`.`entry`.`idEntity`))
where `view_corpus`.`idLanguage` = `webtool40_db`.`entry`.`idLanguage`;


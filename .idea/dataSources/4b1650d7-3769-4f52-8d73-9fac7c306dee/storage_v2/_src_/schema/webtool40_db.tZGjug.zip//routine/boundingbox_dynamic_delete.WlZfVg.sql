create
    definer = fnbrasil@`%` function boundingbox_dynamic_delete(par_idBoundingBox int, par_idUser int) returns int
BEGIN
		DECLARE v_idAnnotationObject INT;
        SELECT idAnnotationObject INTO v_idAnnotationObject FROM boundingbox WHERE (idBoundingBox = par_idBoundingBox);
        DELETE FROM annotation WHERE idAnnotationObject = v_idAnnotationObject;
        DELETE FROM annotationobjectrelation WHERE (idAnnotationObject1 = v_idAnnotationObject) or (idAnnotationObject2 = v_idAnnotationObject);
		DELETE FROM boundingbox WHERE idBoundingBox = par_idBoundingBox;	
        DELETE FROM annotationobject WHERE idAnnotationObject = v_idAnnotationObject;
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','boundingbox', par_idBoundingBox,par_idUser);
        RETURN par_idBoundingBox;
    END;


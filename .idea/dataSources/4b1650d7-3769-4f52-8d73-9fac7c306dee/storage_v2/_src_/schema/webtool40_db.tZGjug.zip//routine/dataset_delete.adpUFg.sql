create
    definer = fnbrasil@`%` function dataset_delete(par_idDataset int, par_idUser int) returns int
BEGIN
        DELETE FROM project_dataset where (idDataset = par_idDataset);
        DELETE FROM dataset where (idDataset = par_idDataset);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','D','dataset', par_idDataset, par_idUser);
        RETURN par_idDataset;
    END;


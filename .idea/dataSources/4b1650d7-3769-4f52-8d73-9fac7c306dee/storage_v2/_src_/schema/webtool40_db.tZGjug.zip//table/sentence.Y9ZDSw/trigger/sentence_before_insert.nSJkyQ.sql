create definer = fnbrasil@`%` trigger sentence_BEFORE_INSERT
    before insert
    on sentence
    for each row
BEGIN
IF (NEW.idAnnotationObject = 0) THEN
	SET NEW.idAnnotationObject = annotationobject_create(0,'SEN');
END IF;    
END;


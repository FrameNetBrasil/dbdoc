create definer = fnbrasil@`%` view view_constrainedby_constraint_cx as
select `e`.`idLanguage`           AS `idLanguage`,
       `e`.`name`                 AS `conName`,
       `c`.`idConstraint`         AS `idConstraint`,
       `c`.`idConstrained`        AS `idConstrained`,
       `c`.`idConstrainedBy`      AS `idConstrainedBy`,
       `c`.`constrainedByType`    AS `constrainedByType`,
       `c`.`idConstraintInstance` AS `idConstraintInstance`,
       `cx`.`name`                AS `name`
from ((((`webtool40_db`.`view_constraint` `c` join `webtool40_db`.`entry` `e`
         on (`c`.`idEntity` = `e`.`idEntity`)) join `webtool40_db`.`view_constraint` `con`
        on (`c`.`idConstrainedBy` = `con`.`idConstraint`)) join `webtool40_db`.`entry` `conentry`
       on (`e`.`idLanguage` = `conentry`.`idLanguage`)) join `webtool40_db`.`view_construction` `cx`
      on (`con`.`idConstrainedBy` = `cx`.`idEntity`))
where `cx`.`idLanguage` = `e`.`idLanguage`;


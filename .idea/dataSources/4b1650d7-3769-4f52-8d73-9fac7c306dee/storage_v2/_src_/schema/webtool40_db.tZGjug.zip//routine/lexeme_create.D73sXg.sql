create
    definer = fnbrasil@`%` function lexeme_create(par_lexeme longtext) returns int
BEGIN
		DECLARE v_name VARCHAR(255);
        DECLARE v_idLanguage INT;
        DECLARE v_idPOS INT;
        DECLARE v_idUser INT;
        INSERT INTO entity (type) values ('LEX');
        SET @idEntity = (SELECT last_insert_id());
        SET v_name = JSON_UNQUOTE(JSON_EXTRACT(par_lexeme, '$.name'));
        SET v_idLanguage = JSON_EXTRACT(par_lexeme, '$.idLanguage');
        SET v_idPOS = JSON_EXTRACT(par_lexeme, '$.idPOS');
        INSERT INTO lexeme(name, idLanguage, idPOS, idEntity) values (v_name, v_idLanguage, v_idPOS, @idEntity);
        SET @idLexeme = (SELECT last_insert_id());
        INSERT INTO wordform (form, md5, idLexeme) values (v_name, md5(v_name), @idLexeme);
        INSERT INTO timeline (tlDateTime,author,operation,tableName,id,idUser) VALUES (NOW(),'user','C','lexeme', @idLexeme, v_idUser);
        RETURN @idLexeme;
    END;


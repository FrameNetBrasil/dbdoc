create
    definer = fnbrasil@`%` function layergroup_create(par_layergroup longtext) returns int
BEGIN
	DECLARE v_name VARCHAR(255);
    DECLARE v_type VARCHAR(255);
    INSERT INTO layergroup(name, type) values (v_name, v_type);
    SET @idLayerGroup = (SELECT last_insert_id());
    RETURN @idLayerGroup;
 END;


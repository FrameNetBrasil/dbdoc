create definer = fnbrasil@`%` view view_frame_relation as
select `relation`.`idEntityRelation` AS `idEntityRelation`,
       `relation`.`idRelationType`   AS `idRelationType`,
       `relation`.`relationType`     AS `relationType`,
       `relation`.`nameCanonical`    AS `nameCanonical`,
       `relation`.`nameDirect`       AS `nameDirect`,
       `relation`.`nameInverse`      AS `nameInverse`,
       `relation`.`color`            AS `color`,
       `f1`.`name`                   AS `f1Name`,
       `f1`.`idFrame`                AS `f1IdFrame`,
       `f1`.`idEntity`               AS `f1IdEntity`,
       `f1`.`idLanguage`             AS `idLanguage`,
       `f2`.`name`                   AS `f2Name`,
       `f2`.`idFrame`                AS `f2IdFrame`,
       `f2`.`idEntity`               AS `f2IdEntity`
from ((`webtool40_db`.`view_frame` `f1` join `webtool40_db`.`view_relation` `relation`
       on (`f1`.`idEntity` = `relation`.`idEntity1`)) join `webtool40_db`.`view_frame` `f2`
      on (`relation`.`idEntity2` = `f2`.`idEntity`))
where `relation`.`relationType` in
      ('rel_causative_of', 'rel_inchoative_of', 'rel_inheritance', 'rel_perspective_on', 'rel_precedes', 'rel_see_also',
       'rel_subframe', 'rel_structure', 'rel_using')
  and `f1`.`idLanguage` = `f2`.`idLanguage`;


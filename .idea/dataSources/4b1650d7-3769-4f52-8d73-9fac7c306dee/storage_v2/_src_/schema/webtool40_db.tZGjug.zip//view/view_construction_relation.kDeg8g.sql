create definer = fnbrasil@`%` view view_construction_relation as
select `relation`.`idEntityRelation` AS `idEntityRelation`,
       `relation`.`idRelationType`   AS `idRelationType`,
       `relation`.`relationType`     AS `relationType`,
       `relation`.`nameCanonical`    AS `nameCanonical`,
       `relation`.`nameDirect`       AS `nameDirect`,
       `relation`.`nameInverse`      AS `nameInverse`,
       `relation`.`color`            AS `color`,
       `c1`.`name`                   AS `c1Name`,
       `c1`.`idConstruction`         AS `c1IdConstruction`,
       `c1`.`idEntity`               AS `c1IdEntity`,
       `c1`.`cxIdLanguage`           AS `cxIdLanguage`,
       `c1`.`idLanguage`             AS `idLanguage`,
       `c2`.`name`                   AS `c2Name`,
       `c2`.`idConstruction`         AS `c2IdConstruction`,
       `c2`.`idEntity`               AS `c2IdEntity`
from ((`webtool40_db`.`view_construction` `c1` join `webtool40_db`.`view_relation` `relation`
       on (`c1`.`idEntity` = `relation`.`idEntity1`)) join `webtool40_db`.`view_construction` `c2`
      on (`relation`.`idEntity2` = `c2`.`idEntity`))
where `relation`.`relationType` in ('rel_daughter_of', 'rel_inheritance_cxn')
  and `c1`.`idLanguage` = `c2`.`idLanguage`;


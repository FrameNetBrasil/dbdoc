create definer = fnbrasil@`%` view view_frameelement as
select `webtool40_db`.`frame`.`idFrame`     AS `idFrame`,
       `webtool40_db`.`frame`.`entry`       AS `frameEntry`,
       `webtool40_db`.`frame`.`idEntity`    AS `frameIdEntity`,
       `entryframe`.`name`                  AS `frameName`,
       `fe`.`idFrameElement`                AS `idFrameElement`,
       `fe`.`entry`                         AS `entry`,
       `fe`.`active`                        AS `active`,
       `fe`.`idEntity`                      AS `idEntity`,
       `fe`.`idColor`                       AS `idColor`,
       `fe`.`coreType`                      AS `coreType`,
       `webtool40_db`.`entry`.`name`        AS `name`,
       `webtool40_db`.`entry`.`description` AS `description`,
       `webtool40_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `entryen`.`name`                     AS `nameEn`
from (((((`webtool40_db`.`frameelement` `fe` join `webtool40_db`.`frame`
          on (`fe`.`idFrame` = `webtool40_db`.`frame`.`idFrame`)) join `webtool40_db`.`entry`
         on (`fe`.`idEntity` = `webtool40_db`.`entry`.`idEntity`)) join `webtool40_db`.`entry` `entryframe`
        on (`webtool40_db`.`frame`.`idEntity` = `entryframe`.`idEntity`)) join `webtool40_db`.`entry` `entryen`
       on (`fe`.`idEntity` = `entryen`.`idEntity` and `entryen`.`idLanguage` = 2)) join `webtool40_db`.`typeinstance` `ti`
      on (`fe`.`coreType` = `ti`.`entry`))
where `webtool40_db`.`entry`.`idLanguage` = `entryframe`.`idLanguage`
order by `ti`.`info`, `webtool40_db`.`entry`.`name`;


create definer = fnbrasil@`%` view view_annotationset as
select `a`.`idAnnotationSet`            AS `idAnnotationSet`,
       `a`.`idAnnotationStatus`         AS `idAnnotationStatus`,
       `webtool40_db`.`lu`.`idEntity`   AS `idEntityLU`,
       `webtool40_db`.`lu`.`idLU`       AS `idLU`,
       `cxn`.`idEntity`                 AS `idEntityCxn`,
       `cxn`.`idConstruction`           AS `idConstruction`,
       `ti`.`idEntity`                  AS `idEntityTypeInstance`,
       `a`.`idAnnotationObjectRelation` AS `idDocumentSentence`,
       `ds`.`idSentence`                AS `idSentence`,
       `ds`.`idDocument`                AS `idDocument`
from ((((`webtool40_db`.`annotationset` `a` join `webtool40_db`.`typeinstance` `ti`
         on (`a`.`idAnnotationStatus` = `ti`.`idTypeInstance`)) join `webtool40_db`.`view_document_sentence` `ds`
        on (`a`.`idAnnotationObjectRelation` = `ds`.`idDocumentSentence`)) left join `webtool40_db`.`lu`
       on (`a`.`idLU` = `webtool40_db`.`lu`.`idLU`)) left join `webtool40_db`.`construction` `cxn`
      on (`a`.`idConstruction` = `cxn`.`idConstruction`));


create definer = fnbrasil@localhost view view_layer as
select `l`.`idLayer`         AS `idLayer`,
       `l`.`rank`            AS `rank`,
       `l`.`idAnnotationSet` AS `idAnnotationSet`,
       `l`.`idLayerType`     AS `idLayerType`,
       `lt`.`entry`          AS `entry`,
       `lt`.`idEntity`       AS `idEntity`,
       `lt`.`layerOrder`     AS `layerOrder`
from (`mfn_db`.`layer` `l` join `mfn_db`.`layertype` `lt` on (`l`.`idLayerType` = `lt`.`idLayerType`));


create definer = fnbrasil@localhost view view_frameelement as
select `mfn_db`.`frame`.`idFrame`  AS `idFrame`,
       `mfn_db`.`frame`.`entry`    AS `frameEntry`,
       `mfn_db`.`frame`.`idEntity` AS `frameIdEntity`,
       `fe`.`idFrameElement`       AS `idFrameElement`,
       `fe`.`entry`                AS `entry`,
       `fe`.`active`               AS `active`,
       `fe`.`idEntity`             AS `idEntity`,
       `fe`.`idColor`              AS `idColor`,
       `fe`.`coreType`             AS `typeEntry`
from (`mfn_db`.`frameelement` `fe` join `mfn_db`.`frame` on (`fe`.`idFrame` = `mfn_db`.`frame`.`idFrame`));


create definer = fnbrasil@localhost view view_relation as
select `er`.`idEntityRelation` AS `idEntityRelation`,
       `d`.`entry`             AS `domain`,
       `rg`.`entry`            AS `relationGroup`,
       `rt`.`idRelationType`   AS `idRelationType`,
       `rt`.`entry`            AS `relationType`,
       `rt`.`prefix`           AS `prefix`,
       `er`.`idEntity1`        AS `idEntity1`,
       `e1`.`type`             AS `entity1Type`,
       `er`.`idEntity2`        AS `idEntity2`,
       `e2`.`type`             AS `entity2Type`,
       `er`.`idEntity3`        AS `idEntity3`,
       `e3`.`type`             AS `entity3Type`
from ((((((`mfn_db`.`entityrelation` `er` join `mfn_db`.`relationtype` `rt`
           on (`er`.`idRelationType` = `rt`.`idRelationType`)) join `mfn_db`.`relationgroup` `rg`
          on (`rt`.`idRelationGroup` = `rg`.`idRelationGroup`)) join `mfn_db`.`domain` `d`
         on (`rt`.`idDomain` = `d`.`idDomain`)) join `mfn_db`.`entity` `e1`
        on (`er`.`idEntity1` = `e1`.`idEntity`)) join `mfn_db`.`entity` `e2`
       on (`er`.`idEntity2` = `e2`.`idEntity`)) left join `mfn_db`.`entity` `e3`
      on (`er`.`idEntity3` = `e3`.`idEntity`));


create definer = fnbrasil@`kenobi.cpd.ufjf.br` view view_annotationsetmm as
select `a`.`idAnnotationSetMM` AS `idAnnotationSetMM`,
       `d`.`idDocumentMM`      AS `idDocumentMM`,
       `a`.`idSentenceMM`      AS `idSentenceMM`
from (((((`mfn_db`.`annotationsetmm` `a` join `mfn_db`.`sentencemm` `s`
          on (`a`.`idSentenceMM` = `s`.`idSentenceMM`)) join `mfn_db`.`sentence` `se`
         on (`s`.`idSentence` = `se`.`idSentence`)) join `mfn_db`.`paragraph` `p`
        on (`se`.`idParagraph` = `p`.`idParagraph`)) join `mfn_db`.`document` `dm`
       on (`p`.`idDocument` = `dm`.`idDocument`)) join `mfn_db`.`documentmm` `d`
      on (`dm`.`idDocument` = `d`.`idDocument`));


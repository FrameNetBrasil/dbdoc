create definer = fnbrasil@localhost view view_constructionelement as
select `mfn_db`.`construction`.`idConstruction` AS `idConstruction`,
       `mfn_db`.`construction`.`entry`          AS `constructionEntry`,
       `mfn_db`.`construction`.`idEntity`       AS `constructionIdEntity`,
       `ce`.`idConstructionElement`             AS `idConstructionElement`,
       `ce`.`entry`                             AS `entry`,
       `ce`.`active`                            AS `active`,
       `ce`.`idEntity`                          AS `idEntity`,
       `ce`.`idColor`                           AS `idColor`,
       `ce`.`optional`                          AS `optional`,
       `ce`.`head`                              AS `head`,
       `ce`.`multiple`                          AS `multiple`
from (`mfn_db`.`constructionelement` `ce` join `mfn_db`.`construction`
      on (`ce`.`idConstruction` = `mfn_db`.`construction`.`idConstruction`));


create definer = fnbrasil@localhost view view_annotationset as
select `a`.`idAnnotationSet`    AS `idAnnotationSet`,
       `a`.`idSubCorpus`        AS `idSubCorpus`,
       `a`.`idSentence`         AS `idSentence`,
       `a`.`idAnnotationStatus` AS `idAnnotationStatus`,
       `ti`.`entry`             AS `entry`
from (`mfn_db`.`annotationset` `a` join `mfn_db`.`typeinstance` `ti`
      on (`a`.`idAnnotationStatus` = `ti`.`idTypeInstance`));


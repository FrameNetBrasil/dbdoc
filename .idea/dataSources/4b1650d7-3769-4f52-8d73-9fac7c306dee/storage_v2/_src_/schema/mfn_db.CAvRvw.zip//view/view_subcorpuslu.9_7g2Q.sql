create definer = fnbrasil@localhost view view_subcorpuslu as
select `sc`.`idSubCorpus`   AS `idSubCorpus`,
       `sc`.`name`          AS `name`,
       `sc`.`rank`          AS `rank`,
       `mfn_db`.`lu`.`idLU` AS `idLU`
from (((`mfn_db`.`lu` join `mfn_db`.`entityrelation` `er1`
        on (`mfn_db`.`lu`.`idEntity` = `er1`.`idEntity1`)) join `mfn_db`.`relationtype` `rt1`
       on (`er1`.`idRelationType` = `rt1`.`idRelationType`)) join `mfn_db`.`subcorpus` `sc`
      on (`er1`.`idEntity2` = `sc`.`idEntity`))
where `rt1`.`entry` = 'rel_hassubcorpus';


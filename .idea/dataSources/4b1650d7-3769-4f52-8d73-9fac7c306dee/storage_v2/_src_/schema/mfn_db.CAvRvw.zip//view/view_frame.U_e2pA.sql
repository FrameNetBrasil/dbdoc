create definer = fnbrasil@localhost view view_frame as
select `mfn_db`.`frame`.`idFrame`  AS `idFrame`,
       `mfn_db`.`frame`.`entry`    AS `entry`,
       `mfn_db`.`frame`.`active`   AS `active`,
       `mfn_db`.`frame`.`idEntity` AS `idEntity`
from `mfn_db`.`frame`;


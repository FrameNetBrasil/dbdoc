create definer = fnbrasil@localhost view view_sentence as
select `s`.`idSentence`     AS `idSentence`,
       `s`.`text`           AS `text`,
       `s`.`paragraphOrder` AS `paragraphOrder`,
       `s`.`idParagraph`    AS `idParagraph`,
       `s`.`idLanguage`     AS `idLanguage`,
       `p`.`documentOrder`  AS `documentOrder`,
       `p`.`idDocument`     AS `idDocument`,
       `d`.`entry`          AS `documentEntry`,
       `d`.`author`         AS `author`,
       `d`.`idGenre`        AS `idGenre`,
       `d`.`idCorpus`       AS `idCorpus`,
       `c`.`entry`          AS `corpusEntry`
from (((`mfn_db`.`sentence` `s` join `mfn_db`.`paragraph` `p`
        on (`s`.`idParagraph` = `p`.`idParagraph`)) join `mfn_db`.`document` `d`
       on (`p`.`idDocument` = `d`.`idDocument`)) join `mfn_db`.`corpus` `c` on (`d`.`idCorpus` = `c`.`idCorpus`));


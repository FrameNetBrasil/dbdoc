create definer = fnbrasil@localhost view view_constraint as
select `ci`.`idConstraintInstance` AS `idConstraintInstance`,
       `ct`.`entry`                AS `entry`,
       `ct`.`prefix`               AS `prefix`,
       `ci`.`idConstraint`         AS `idConstraint`,
       `e1`.`type`                 AS `constraintType`,
       `ci`.`idConstrained`        AS `idConstrained`,
       `e2`.`type`                 AS `constrainedType`,
       `ci`.`idConstrainedBy`      AS `idConstrainedBy`,
       `e3`.`type`                 AS `constrainedByType`
from ((((`mfn_db`.`constraintinstance` `ci` join `mfn_db`.`constrainttype` `ct`
         on (`ci`.`idConstraintType` = `ct`.`idConstraintType`)) join `mfn_db`.`entity` `e1`
        on (`ci`.`idConstraint` = `e1`.`idEntity`)) join `mfn_db`.`entity` `e2`
       on (`ci`.`idConstrained` = `e2`.`idEntity`)) join `mfn_db`.`entity` `e3`
      on (`ci`.`idConstrainedBy` = `e3`.`idEntity`));


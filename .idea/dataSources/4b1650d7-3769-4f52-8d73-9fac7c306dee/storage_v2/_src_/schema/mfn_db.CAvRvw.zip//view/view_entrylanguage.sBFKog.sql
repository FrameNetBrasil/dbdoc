create definer = fnbrasil@localhost view view_entrylanguage as
select `mfn_db`.`entry`.`idEntry`     AS `idEntry`,
       `mfn_db`.`entry`.`entry`       AS `entry`,
       `mfn_db`.`entry`.`name`        AS `name`,
       `mfn_db`.`entry`.`description` AS `description`,
       `mfn_db`.`entry`.`nick`        AS `nick`,
       `mfn_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `mfn_db`.`language`.`language` AS `language`
from (`mfn_db`.`entry` join `mfn_db`.`language` on (`mfn_db`.`entry`.`idLanguage` = `mfn_db`.`language`.`idLanguage`));

-- comment on column view_entrylanguage.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


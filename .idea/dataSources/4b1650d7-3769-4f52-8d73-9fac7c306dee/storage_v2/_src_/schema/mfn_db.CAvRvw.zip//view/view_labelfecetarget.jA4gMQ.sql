create definer = fnbrasil@localhost view view_labelfecetarget as
select `mfn_db`.`annotationset`.`idAnnotationSet`                                 AS `idAnnotationSet`,
       `mfn_db`.`annotationset`.`idSubCorpus`                                     AS `idSubCorpus`,
       `mfn_db`.`annotationset`.`idSentence`                                      AS `idSentence`,
       `mfn_db`.`layertype`.`entry`                                               AS `layerTypeEntry`,
       `fe`.`idFrameElement`                                                      AS `idFrameElement`,
       `ce`.`idConstructionElement`                                               AS `idConstructionElement`,
       `gl`.`idGenericLabel`                                                      AS `idGenericLabel`,
       ifnull(`mfn_db`.`label`.`startChar`, -1)                                   AS `startChar`,
       ifnull(`mfn_db`.`label`.`endChar`, -1)                                     AS `endChar`,
       ifnull(`color_ce`.`rgbFg`, ifnull(`color_fe`.`rgbFg`, `color_gl`.`rgbFg`)) AS `rgbFg`,
       ifnull(`color_ce`.`rgbBg`, ifnull(`color_fe`.`rgbBg`, `color_gl`.`rgbBg`)) AS `rgbBg`,
       `entry_it`.`idLanguage`                                                    AS `idLanguage`,
       `entry_it`.`name`                                                          AS `instantiationType`
from (((((((((((`mfn_db`.`annotationset` join `mfn_db`.`layer` on (`mfn_db`.`annotationset`.`idAnnotationSet` =
                                                                   `mfn_db`.`layer`.`idAnnotationSet`)) join `mfn_db`.`layertype`
               on (`mfn_db`.`layer`.`idLayerType` = `mfn_db`.`layertype`.`idLayerType`)) join `mfn_db`.`label`
              on (`mfn_db`.`layer`.`idLayer` = `mfn_db`.`label`.`idLayer`)) join `mfn_db`.`typeinstance`
             on (`mfn_db`.`label`.`idInstantiationType` =
                 `mfn_db`.`typeinstance`.`idTypeInstance`)) join `mfn_db`.`entry` `entry_it`
            on (`mfn_db`.`typeinstance`.`entry` = `entry_it`.`entry`)) left join `mfn_db`.`frameelement` `fe`
           on (`mfn_db`.`label`.`idLabelType` = `fe`.`idEntity`)) left join `mfn_db`.`color` `color_fe`
          on (`fe`.`idColor` = `color_fe`.`idColor`)) left join `mfn_db`.`constructionelement` `ce`
         on (`mfn_db`.`label`.`idLabelType` = `ce`.`idEntity`)) left join `mfn_db`.`color` `color_ce`
        on (`ce`.`idColor` = `color_ce`.`idColor`)) left join `mfn_db`.`genericlabel` `gl`
       on (`mfn_db`.`label`.`idLabelType` = `gl`.`idEntity`)) left join `mfn_db`.`color` `color_gl`
      on (`gl`.`idColor` = `color_gl`.`idColor`))
where `mfn_db`.`layertype`.`entry` = 'lty_fe'
   or `mfn_db`.`layertype`.`entry` = 'lty_ce'
   or `mfn_db`.`layertype`.`entry` = 'lty_target'
order by `mfn_db`.`annotationset`.`idSentence`, `mfn_db`.`label`.`startChar`;


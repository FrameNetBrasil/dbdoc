create definer = fnbrasil@localhost view view_coretype as
select `ti`.`entry`    AS `entry`,
       `ti`.`info`     AS `info`,
       `ti`.`flag`     AS `flag`,
       `ti`.`idType`   AS `idType`,
       `ti`.`idColor`  AS `idColor`,
       `ti`.`idEntity` AS `idEntity`
from (`mfn_db`.`typeinstance` `ti` join `mfn_db`.`type` on (`ti`.`idType` = `mfn_db`.`type`.`idType`))
where `mfn_db`.`type`.`entry` = 'typ_coretype';


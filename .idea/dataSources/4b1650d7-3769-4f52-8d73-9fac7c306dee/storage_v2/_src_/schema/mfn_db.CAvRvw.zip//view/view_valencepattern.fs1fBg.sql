create definer = fnbrasil@localhost view view_valencepattern as
select `vl`.`idValenceLU`      AS `idValenceLU`,
       `vl`.`idFrame`          AS `idFrame`,
       `vl`.`idLU`             AS `idLU`,
       `vl`.`idLanguage`       AS `idLanguage`,
       `vp`.`idValencePattern` AS `idValencePattern`,
       `vp`.`countPattern`     AS `countPattern`,
       `vv`.`idFrameElement`   AS `idFrameElement`,
       `vv`.`GF`               AS `GF`,
       `vv`.`GFSource`         AS `GFSource`,
       `vv`.`PT`               AS `PT`,
       `mfn_db`.`lu`.`name`    AS `luName`,
       `fentry`.`name`         AS `frameName`,
       `feentry`.`name`        AS `feName`,
       `l`.`language`          AS `language`
from ((((((((`mfn_db`.`valencelu` `vl` join `mfn_db`.`valencepattern` `vp`
             on (`vl`.`idValenceLU` = `vp`.`idValenceLU`)) join `mfn_db`.`valencevalent` `vv`
            on (`vp`.`idValencePattern` = `vv`.`idValencePattern`)) join `mfn_db`.`frame` `f`
           on (`vl`.`idFrame` = `f`.`idFrame`)) join `mfn_db`.`frameelement` `fe`
          on (`vv`.`idFrameElement` = `fe`.`idFrameElement`)) join `mfn_db`.`lu`
         on (`vl`.`idLU` = `mfn_db`.`lu`.`idLU`)) join `mfn_db`.`language` `l`
        on (`vl`.`idLanguage` = `l`.`idLanguage`)) join `mfn_db`.`entry` `fentry`
       on (`f`.`entry` = `fentry`.`entry`)) join `mfn_db`.`entry` `feentry` on (`fe`.`entry` = `feentry`.`entry`))
where `fentry`.`idLanguage` = `vl`.`idLanguage`
  and `feentry`.`idLanguage` = `vl`.`idLanguage`;

-- comment on column view_valencepattern.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


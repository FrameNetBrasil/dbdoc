create definer = fnbrasil@localhost view view_domain as
select `d`.`idDomain`   AS `idDomain`,
       `d`.`entry`      AS `entry`,
       `d`.`idEntity`   AS `idEntity`,
       `e`.`name`       AS `name`,
       `st`.`idEntity`  AS `idEntityRel`,
       `en`.`type`      AS `entityType`,
       `e`.`idLanguage` AS `idLanguage`,
       `st`.`entry`     AS `entryRel`,
       `est`.`name`     AS `nameRel`
from ((((`mfn_db`.`domain` `d` join `mfn_db`.`entry` `e`
         on (`d`.`entry` = `e`.`entry`)) join `mfn_db`.`semantictype` `st`
        on (`d`.`idDomain` = `st`.`idDomain`)) join `mfn_db`.`entity` `en`
       on (`st`.`idEntity` = `en`.`idEntity`)) join `mfn_db`.`entry` `est` on (`st`.`entry` = `est`.`entry`))
where `e`.`idLanguage` = `est`.`idLanguage`
union
select `d`.`idDomain`   AS `idDomain`,
       `d`.`entry`      AS `entry`,
       `d`.`idEntity`   AS `idEntity`,
       `e`.`name`       AS `name`,
       `er`.`idEntity1` AS `idEntityRel`,
       'FR'             AS `entityType`,
       `e`.`idLanguage` AS `idLanguage`,
       `f`.`entry`      AS `entryRel`,
       `ef`.`name`      AS `nameRel`
from ((((`mfn_db`.`domain` `d` join `mfn_db`.`entry` `e`
         on (`d`.`entry` = `e`.`entry`)) join `mfn_db`.`entityrelation` `er`
        on (`d`.`idEntity` = `er`.`idEntity2`)) join `mfn_db`.`frame` `f`
       on (`er`.`idEntity1` = `f`.`idEntity`)) join `mfn_db`.`entry` `ef` on (`f`.`entry` = `ef`.`entry`))
where `e`.`idLanguage` = `ef`.`idLanguage`
union
select `d`.`idDomain`   AS `idDomain`,
       `d`.`entry`      AS `entry`,
       `d`.`idEntity`   AS `idEntity`,
       `e`.`name`       AS `name`,
       0                AS `0`,
       'DO'             AS `entityType`,
       `e`.`idLanguage` AS `idLanguage`,
       `d`.`entry`      AS `entryRel`,
       `e`.`name`       AS `nameRel`
from (`mfn_db`.`domain` `d` join `mfn_db`.`entry` `e` on (`d`.`entry` = `e`.`entry`));


create definer = fnbrasil@localhost view view_wflexemelemma as
select `wf`.`idWordForm`    AS `idWordForm`,
       `wf`.`form`          AS `form`,
       `lx`.`idLexeme`      AS `idLexeme`,
       `lx`.`name`          AS `lexeme`,
       `pos1`.`idPOS`       AS `idPOSLexeme`,
       `pos1`.`POS`         AS `POSLexeme`,
       `lx`.`idLanguage`    AS `idLanguage`,
       `le`.`idLexemeEntry` AS `idLexemeEntry`,
       `le`.`lexemeOrder`   AS `lexemeOrder`,
       `le`.`breakBefore`   AS `breakBefore`,
       `le`.`headWord`      AS `headWord`,
       `lm`.`idLemma`       AS `idLemma`,
       `lm`.`name`          AS `lemma`,
       `pos2`.`idPOS`       AS `idPOSLemma`,
       `pos2`.`POS`         AS `POSLemma`,
       `lang`.`language`    AS `language`
from ((((((`mfn_db`.`wordform` `wf` join `mfn_db`.`lexeme` `lx`
           on (`wf`.`idLexeme` = `lx`.`idLexeme`)) join `mfn_db`.`pos` `pos1`
          on (`lx`.`idPOS` = `pos1`.`idPOS`)) join `mfn_db`.`language` `lang`
         on (`lx`.`idLanguage` = `lang`.`idLanguage`)) left join `mfn_db`.`lexemeentry` `le`
        on (`lx`.`idLexeme` = `le`.`idLexeme`)) left join `mfn_db`.`lemma` `lm`
       on (`le`.`idLemma` = `lm`.`idLemma`)) left join `mfn_db`.`pos` `pos2` on (`lm`.`idPOS` = `pos2`.`idPOS`))
where `lm`.`idLanguage` = `lx`.`idLanguage`
   or `lm`.`idLanguage` is null;

-- comment on column view_wflexemelemma.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


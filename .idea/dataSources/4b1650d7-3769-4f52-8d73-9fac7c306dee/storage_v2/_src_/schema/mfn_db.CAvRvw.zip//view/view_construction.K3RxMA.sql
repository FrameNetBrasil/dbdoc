create definer = fnbrasil@localhost view view_construction as
select `mfn_db`.`construction`.`idConstruction` AS `idConstruction`,
       `mfn_db`.`construction`.`entry`          AS `entry`,
       `mfn_db`.`construction`.`abstract`       AS `abstract`,
       `mfn_db`.`construction`.`active`         AS `active`,
       `mfn_db`.`construction`.`idEntity`       AS `idEntity`,
       `mfn_db`.`construction`.`idLanguage`     AS `idLanguage`
from `mfn_db`.`construction`;


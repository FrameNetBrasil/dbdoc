create definer = fnbrasil@localhost view view_lu as
select `mfn_db`.`lu`.`idLU`             AS `idLU`,
       `mfn_db`.`lu`.`name`             AS `name`,
       `mfn_db`.`lu`.`senseDescription` AS `senseDescription`,
       `mfn_db`.`lu`.`active`           AS `active`,
       `mfn_db`.`lu`.`importNum`        AS `importNum`,
       `mfn_db`.`lu`.`incorporatedFE`   AS `incorporatedFE`,
       `mfn_db`.`lu`.`idEntity`         AS `idEntity`,
       `mfn_db`.`lu`.`idLemma`          AS `idLemma`,
       `mfn_db`.`frame`.`idFrame`       AS `idFrame`,
       `mfn_db`.`frame`.`entry`         AS `frameEntry`,
       `mfn_db`.`lemma`.`name`          AS `lemmaName`,
       `mfn_db`.`lemma`.`idPOS`         AS `idPOS`,
       `mfn_db`.`lemma`.`idLanguage`    AS `idLanguage`
from ((`mfn_db`.`lu` join `mfn_db`.`frame`
       on (`mfn_db`.`lu`.`idFrame` = `mfn_db`.`frame`.`idFrame`)) join `mfn_db`.`lemma`
      on (`mfn_db`.`lu`.`idLemma` = `mfn_db`.`lemma`.`idLemma`));


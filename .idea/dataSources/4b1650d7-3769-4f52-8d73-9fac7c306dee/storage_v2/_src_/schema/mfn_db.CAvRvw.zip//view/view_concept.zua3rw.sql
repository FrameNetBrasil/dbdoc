create definer = fnbrasil@localhost view view_concept as
select `cp`.`idConcept` AS `idConcept`, `cp`.`entry` AS `entry`, `cp`.`idEntity` AS `idEntity`
from `mfn_db`.`concept` `cp`;


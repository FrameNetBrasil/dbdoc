create definer = fnbrasil@`%` view view_constructionelement_old as
select `fnbr_db`.`construction`.`entry`    AS `constructionEntry`,
       `fnbr_db`.`construction`.`idEntity` AS `constructionIdEntity`,
       `ce`.`idConstructionElement`        AS `idConstructionElement`,
       `ce`.`entry`                        AS `entry`,
       `ce`.`active`                       AS `active`,
       `ce`.`idEntity`                     AS `idEntity`,
       `ce`.`idColor`                      AS `idColor`,
       `ce`.`optional`                     AS `optional`,
       `ce`.`head`                         AS `head`,
       `ce`.`multiple`                     AS `multiple`,
       `ce`.`idConstruction`               AS `idConstruction`
from (((`fnbr_db`.`constructionelement` `ce` join `fnbr_db`.`entityrelation` `er1`
        on (`ce`.`idEntity` = `er1`.`idEntity1`)) join `fnbr_db`.`relationtype` `rt1`
       on (`er1`.`idRelationType` = `rt1`.`idRelationType`)) join `fnbr_db`.`construction`
      on (`er1`.`idEntity2` = `fnbr_db`.`construction`.`idEntity`))
where `rt1`.`entry` = 'rel_elementof';


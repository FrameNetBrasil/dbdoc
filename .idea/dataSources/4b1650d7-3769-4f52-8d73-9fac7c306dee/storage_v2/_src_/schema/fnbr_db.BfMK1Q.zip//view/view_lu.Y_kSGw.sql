create definer = fnbrasil@`%` view view_lu as
select `fnbr_db`.`lu`.`idLU`             AS `idLU`,
       `fnbr_db`.`lu`.`name`             AS `name`,
       `fnbr_db`.`lu`.`senseDescription` AS `senseDescription`,
       `fnbr_db`.`lu`.`active`           AS `active`,
       `fnbr_db`.`lu`.`importNum`        AS `importNum`,
       `fnbr_db`.`lu`.`incorporatedFE`   AS `incorporatedFE`,
       `fnbr_db`.`lu`.`idEntity`         AS `idEntity`,
       `fnbr_db`.`lu`.`idLemma`          AS `idLemma`,
       `fnbr_db`.`frame`.`idFrame`       AS `idFrame`,
       `fnbr_db`.`frame`.`entry`         AS `frameEntry`,
       `fnbr_db`.`lemma`.`name`          AS `lemmaName`,
       `fnbr_db`.`lemma`.`idPOS`         AS `idPOS`,
       `fnbr_db`.`lemma`.`idLanguage`    AS `idLanguage`
from ((`fnbr_db`.`lu` join `fnbr_db`.`frame`
       on (`fnbr_db`.`lu`.`idFrame` = `fnbr_db`.`frame`.`idFrame`)) join `fnbr_db`.`lemma`
      on (`fnbr_db`.`lu`.`idLemma` = `fnbr_db`.`lemma`.`idLemma`));


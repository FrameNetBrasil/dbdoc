create definer = fnbrasil@`%` view view_constructionelement as
select `fnbr_db`.`construction`.`idConstruction` AS `idConstruction`,
       `fnbr_db`.`construction`.`entry`          AS `constructionEntry`,
       `fnbr_db`.`construction`.`idEntity`       AS `constructionIdEntity`,
       `ce`.`idConstructionElement`              AS `idConstructionElement`,
       `ce`.`entry`                              AS `entry`,
       `ce`.`active`                             AS `active`,
       `ce`.`idEntity`                           AS `idEntity`,
       `ce`.`idColor`                            AS `idColor`,
       `ce`.`optional`                           AS `optional`,
       `ce`.`head`                               AS `head`,
       `ce`.`multiple`                           AS `multiple`
from (`fnbr_db`.`constructionelement` `ce` join `fnbr_db`.`construction`
      on (`ce`.`idConstruction` = `fnbr_db`.`construction`.`idConstruction`));


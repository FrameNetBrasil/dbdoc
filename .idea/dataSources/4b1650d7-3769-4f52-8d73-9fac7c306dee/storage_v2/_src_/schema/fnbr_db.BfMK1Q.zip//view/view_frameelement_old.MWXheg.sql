create definer = fnbrasil@`%` view view_frameelement_old as
select `fnbr_db`.`frame`.`idFrame`  AS `idFrame`,
       `fnbr_db`.`frame`.`entry`    AS `frameEntry`,
       `fnbr_db`.`frame`.`idEntity` AS `frameIdEntity`,
       `fe`.`idFrameElement`        AS `idFrameElement`,
       `fe`.`entry`                 AS `entry`,
       `fe`.`active`                AS `active`,
       `fe`.`idEntity`              AS `idEntity`,
       `fe`.`idColor`               AS `idColor`,
       `ti`.`entry`                 AS `typeEntry`
from ((((((`fnbr_db`.`frameelement` `fe` join `fnbr_db`.`entityrelation` `er1`
           on (`fe`.`idEntity` = `er1`.`idEntity1`)) join `fnbr_db`.`relationtype` `rt1`
          on (`er1`.`idRelationType` = `rt1`.`idRelationType`)) join `fnbr_db`.`frame`
         on (`er1`.`idEntity2` = `fnbr_db`.`frame`.`idEntity`)) join `fnbr_db`.`entityrelation` `er2`
        on (`fe`.`idEntity` = `er2`.`idEntity1`)) join `fnbr_db`.`relationtype` `rt2`
       on (`er2`.`idRelationType` = `rt2`.`idRelationType`)) join `fnbr_db`.`typeinstance` `ti`
      on (`er2`.`idEntity2` = `ti`.`idEntity`))
where `rt1`.`entry` = 'rel_elementof'
  and `rt2`.`entry` = 'rel_hastype';


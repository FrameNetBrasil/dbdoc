create definer = fnbrasil@`%` view view_constraint as
select `ci`.`idEntityRelation` AS `idConstraintInstance`,
       `ct`.`entry`            AS `entry`,
       `ct`.`prefix`           AS `prefix`,
       `ci`.`idEntity1`        AS `idConstraint`,
       `e1`.`type`             AS `constraintType`,
       `ci`.`idEntity2`        AS `idConstrained`,
       `e2`.`type`             AS `constrainedType`,
       `ci`.`idEntity3`        AS `idConstrainedBy`,
       `e3`.`type`             AS `constrainedByType`,
       `ct`.`idRelationType`   AS `idConstraintType`
from ((((`fnbr_db`.`entityrelation` `ci` join `fnbr_db`.`relationtype` `ct`
         on (`ci`.`idRelationType` = `ct`.`idRelationType`)) join `fnbr_db`.`entity` `e1`
        on (`ci`.`idEntity1` = `e1`.`idEntity`)) join `fnbr_db`.`entity` `e2`
       on (`ci`.`idEntity2` = `e2`.`idEntity`)) left join `fnbr_db`.`entity` `e3`
      on (`ci`.`idEntity3` = `e3`.`idEntity`))
where `ct`.`idRelationGroup` = 6;


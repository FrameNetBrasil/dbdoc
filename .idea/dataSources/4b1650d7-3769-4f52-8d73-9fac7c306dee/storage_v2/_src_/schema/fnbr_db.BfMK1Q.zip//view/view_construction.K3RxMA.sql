create definer = fnbrasil@`%` view view_construction as
select `fnbr_db`.`construction`.`idConstruction` AS `idConstruction`,
       `fnbr_db`.`construction`.`entry`          AS `entry`,
       `fnbr_db`.`construction`.`abstract`       AS `abstract`,
       `fnbr_db`.`construction`.`active`         AS `active`,
       `fnbr_db`.`construction`.`idEntity`       AS `idEntity`,
       `fnbr_db`.`construction`.`idLanguage`     AS `idLanguage`
from `fnbr_db`.`construction`;


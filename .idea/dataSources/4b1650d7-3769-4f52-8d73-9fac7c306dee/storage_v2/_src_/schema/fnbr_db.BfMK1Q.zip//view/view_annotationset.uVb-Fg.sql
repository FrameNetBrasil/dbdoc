create definer = fnbrasil@`%` view view_annotationset as
select `a`.`idAnnotationSet`    AS `idAnnotationSet`,
       `a`.`idSubCorpus`        AS `idSubCorpus`,
       `a`.`idSentence`         AS `idSentence`,
       `a`.`idAnnotationStatus` AS `idAnnotationStatus`,
       `a`.`idEntityRelated`    AS `idEntityLU`,
       `fnbr_db`.`lu`.`idLU`    AS `idLU`,
       `a`.`idEntityRelated`    AS `idEntityCxn`,
       `cxn`.`idConstruction`   AS `idConstruction`,
       `ti`.`entry`             AS `entry`
from (((`fnbr_db`.`annotationset` `a` join `fnbr_db`.`typeinstance` `ti`
        on (`a`.`idAnnotationStatus` = `ti`.`idTypeInstance`)) left join `fnbr_db`.`lu`
       on (`a`.`idEntityRelated` = `fnbr_db`.`lu`.`idEntity`)) left join `fnbr_db`.`construction` `cxn`
      on (`a`.`idEntityRelated` = `cxn`.`idEntity`));


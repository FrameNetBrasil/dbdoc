create definer = fnbrasil@`%` view view_valencepattern as
select `vl`.`idValenceLU`      AS `idValenceLU`,
       `vl`.`idFrame`          AS `idFrame`,
       `vl`.`idLU`             AS `idLU`,
       `vl`.`idLanguage`       AS `idLanguage`,
       `vp`.`idValencePattern` AS `idValencePattern`,
       `vp`.`countPattern`     AS `countPattern`,
       `vv`.`idFrameElement`   AS `idFrameElement`,
       `vv`.`GF`               AS `GF`,
       `vv`.`GFSource`         AS `GFSource`,
       `vv`.`PT`               AS `PT`,
       `fnbr_db`.`lu`.`name`   AS `luName`,
       `fentry`.`name`         AS `frameName`,
       `feentry`.`name`        AS `feName`,
       `l`.`language`          AS `language`
from ((((((((`fnbr_db`.`valencelu` `vl` join `fnbr_db`.`valencepattern` `vp`
             on (`vl`.`idValenceLU` = `vp`.`idValenceLU`)) join `fnbr_db`.`valencevalent` `vv`
            on (`vp`.`idValencePattern` = `vv`.`idValencePattern`)) join `fnbr_db`.`frame` `f`
           on (`vl`.`idFrame` = `f`.`idFrame`)) join `fnbr_db`.`frameelement` `fe`
          on (`vv`.`idFrameElement` = `fe`.`idFrameElement`)) join `fnbr_db`.`lu`
         on (`vl`.`idLU` = `fnbr_db`.`lu`.`idLU`)) join `fnbr_db`.`language` `l`
        on (`vl`.`idLanguage` = `l`.`idLanguage`)) join `fnbr_db`.`entry` `fentry`
       on (`f`.`entry` = `fentry`.`entry`)) join `fnbr_db`.`entry` `feentry` on (`fe`.`entry` = `feentry`.`entry`))
where `fentry`.`idLanguage` = `vl`.`idLanguage`
  and `feentry`.`idLanguage` = `vl`.`idLanguage`;

-- comment on column view_valencepattern.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


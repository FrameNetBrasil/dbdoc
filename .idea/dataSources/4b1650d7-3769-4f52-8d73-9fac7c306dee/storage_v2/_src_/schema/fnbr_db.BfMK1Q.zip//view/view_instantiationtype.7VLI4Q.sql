create definer = fnbrasil@`%` view view_instantiationtype as
select `ti`.`entry`          AS `entry`,
       `ti`.`info`           AS `info`,
       `ti`.`flag`           AS `flag`,
       `ti`.`idTypeInstance` AS `idTypeInstance`,
       `ti`.`idType`         AS `idType`,
       `ti`.`idColor`        AS `idColor`,
       `ti`.`idEntity`       AS `idEntity`
from (`fnbr_db`.`typeinstance` `ti` join `fnbr_db`.`type` on (`ti`.`idType` = `fnbr_db`.`type`.`idType`))
where `fnbr_db`.`type`.`entry` = 'typ_instantiationtype';


create definer = fnbrasil@`%` view view_labelfecetarget as
select `fnbr_db`.`annotationset`.`idAnnotationSet`                                AS `idAnnotationSet`,
       `fnbr_db`.`annotationset`.`idSubCorpus`                                    AS `idSubCorpus`,
       `fnbr_db`.`annotationset`.`idSentence`                                     AS `idSentence`,
       `fnbr_db`.`layertype`.`entry`                                              AS `layerTypeEntry`,
       `fe`.`idFrameElement`                                                      AS `idFrameElement`,
       `ce`.`idConstructionElement`                                               AS `idConstructionElement`,
       `gl`.`idGenericLabel`                                                      AS `idGenericLabel`,
       ifnull(`fnbr_db`.`label`.`startChar`, -1)                                  AS `startChar`,
       ifnull(`fnbr_db`.`label`.`endChar`, -1)                                    AS `endChar`,
       ifnull(`color_ce`.`rgbFg`, ifnull(`color_fe`.`rgbFg`, `color_gl`.`rgbFg`)) AS `rgbFg`,
       ifnull(`color_ce`.`rgbBg`, ifnull(`color_fe`.`rgbBg`, `color_gl`.`rgbBg`)) AS `rgbBg`,
       `entry_it`.`idLanguage`                                                    AS `idLanguage`,
       `entry_it`.`name`                                                          AS `instantiationType`
from (((((((((((`fnbr_db`.`annotationset` join `fnbr_db`.`layer` on (`fnbr_db`.`annotationset`.`idAnnotationSet` =
                                                                     `fnbr_db`.`layer`.`idAnnotationSet`)) join `fnbr_db`.`layertype`
               on (`fnbr_db`.`layer`.`idLayerType` = `fnbr_db`.`layertype`.`idLayerType`)) join `fnbr_db`.`label`
              on (`fnbr_db`.`layer`.`idLayer` = `fnbr_db`.`label`.`idLayer`)) join `fnbr_db`.`typeinstance`
             on (`fnbr_db`.`label`.`idInstantiationType` =
                 `fnbr_db`.`typeinstance`.`idTypeInstance`)) join `fnbr_db`.`entry` `entry_it`
            on (`fnbr_db`.`typeinstance`.`entry` = `entry_it`.`entry`)) left join `fnbr_db`.`frameelement` `fe`
           on (`fnbr_db`.`label`.`idLabelType` = `fe`.`idEntity`)) left join `fnbr_db`.`color` `color_fe`
          on (`fe`.`idColor` = `color_fe`.`idColor`)) left join `fnbr_db`.`constructionelement` `ce`
         on (`fnbr_db`.`label`.`idLabelType` = `ce`.`idEntity`)) left join `fnbr_db`.`color` `color_ce`
        on (`ce`.`idColor` = `color_ce`.`idColor`)) left join `fnbr_db`.`genericlabel` `gl`
       on (`fnbr_db`.`label`.`idLabelType` = `gl`.`idEntity`)) left join `fnbr_db`.`color` `color_gl`
      on (`gl`.`idColor` = `color_gl`.`idColor`))
where `fnbr_db`.`layertype`.`entry` = 'lty_fe'
   or `fnbr_db`.`layertype`.`entry` = 'lty_ce'
   or `fnbr_db`.`layertype`.`entry` = 'lty_target'
order by `fnbr_db`.`annotationset`.`idSentence`, `fnbr_db`.`label`.`startChar`;


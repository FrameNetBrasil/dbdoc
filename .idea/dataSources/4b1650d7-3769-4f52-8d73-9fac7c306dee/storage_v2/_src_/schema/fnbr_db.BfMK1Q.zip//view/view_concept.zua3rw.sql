create definer = fnbrasil@`%` view view_concept as
select `cp`.`idConcept` AS `idConcept`, `cp`.`entry` AS `entry`, `cp`.`idEntity` AS `idEntity`
from `fnbr_db`.`concept` `cp`;


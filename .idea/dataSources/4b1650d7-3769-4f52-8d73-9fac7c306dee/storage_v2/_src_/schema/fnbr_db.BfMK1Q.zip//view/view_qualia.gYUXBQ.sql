create definer = fnbrasil@`%` view view_qualia as
select `ti`.`entry`      AS `qualiaType`,
       `q`.`idQualia`    AS `idQualia`,
       `q`.`entry`       AS `entry`,
       `f`.`entry`       AS `frameEntry`,
       `fe1`.`entry`     AS `fe1Entry`,
       `q`.`info`        AS `info`,
       `fe2`.`entry`     AS `fe2Entry`,
       `q`.`idEntity`    AS `idEntity`,
       `q`.`infoInverse` AS `infoInverse`
from ((((`fnbr_db`.`qualia` `q` join `fnbr_db`.`typeinstance` `ti`
         on (`q`.`idTypeInstance` = `ti`.`idTypeInstance`)) left join `fnbr_db`.`frame` `f`
        on (`q`.`idFrame` = `f`.`idFrame`)) left join `fnbr_db`.`frameelement` `fe1`
       on (`q`.`idFrameElement1` = `fe1`.`idFrameElement`)) left join `fnbr_db`.`frameelement` `fe2`
      on (`q`.`idFrameElement2` = `fe2`.`idFrameElement`));


create definer = fnbrasil@`%` view view_frame as
select `fnbr_db`.`frame`.`idFrame`  AS `idFrame`,
       `fnbr_db`.`frame`.`entry`    AS `entry`,
       `fnbr_db`.`frame`.`active`   AS `active`,
       `fnbr_db`.`frame`.`idEntity` AS `idEntity`
from `fnbr_db`.`frame`;


create definer = fnbrasil@`%` view view_relation as
select `er`.`idEntityRelation` AS `idEntityRelation`,
       `d`.`entry`             AS `domain`,
       `rg`.`entry`            AS `relationGroup`,
       `rt`.`idRelationType`   AS `idRelationType`,
       `rt`.`entry`            AS `relationType`,
       `rt`.`prefix`           AS `prefix`,
       `er`.`idEntity1`        AS `idEntity1`,
       `e1`.`type`             AS `entity1Type`,
       `er`.`idEntity2`        AS `idEntity2`,
       `e2`.`type`             AS `entity2Type`,
       `er`.`idEntity3`        AS `idEntity3`,
       `e3`.`type`             AS `entity3Type`,
       `er`.`idRelation`       AS `idRelation`
from ((((((`fnbr_db`.`entityrelation` `er` join `fnbr_db`.`relationtype` `rt`
           on (`er`.`idRelationType` = `rt`.`idRelationType`)) join `fnbr_db`.`relationgroup` `rg`
          on (`rt`.`idRelationGroup` = `rg`.`idRelationGroup`)) join `fnbr_db`.`domain` `d`
         on (`rt`.`idDomain` = `d`.`idDomain`)) join `fnbr_db`.`entity` `e1`
        on (`er`.`idEntity1` = `e1`.`idEntity`)) join `fnbr_db`.`entity` `e2`
       on (`er`.`idEntity2` = `e2`.`idEntity`)) left join `fnbr_db`.`entity` `e3`
      on (`er`.`idEntity3` = `e3`.`idEntity`));


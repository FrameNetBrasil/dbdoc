create definer = fnbrasil@`%` view view_entrylanguage as
select `fnbr_db`.`entry`.`idEntry`     AS `idEntry`,
       `fnbr_db`.`entry`.`entry`       AS `entry`,
       `fnbr_db`.`entry`.`name`        AS `name`,
       `fnbr_db`.`entry`.`description` AS `description`,
       `fnbr_db`.`entry`.`nick`        AS `nick`,
       `fnbr_db`.`entry`.`idLanguage`  AS `idLanguage`,
       `fnbr_db`.`language`.`language` AS `language`
from (`fnbr_db`.`entry` join `fnbr_db`.`language`
      on (`fnbr_db`.`entry`.`idLanguage` = `fnbr_db`.`language`.`idLanguage`));

-- comment on column view_entrylanguage.language not supported: Two-letter ISO 639-1 language codes + region, See: http://www.w3.org/International/articles/language-tags/


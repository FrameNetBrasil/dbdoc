create definer = fnbrasil@`%` view view_frameelement as
select `fnbr_db`.`frame`.`idFrame`  AS `idFrame`,
       `fnbr_db`.`frame`.`entry`    AS `frameEntry`,
       `fnbr_db`.`frame`.`idEntity` AS `frameIdEntity`,
       `fe`.`idFrameElement`        AS `idFrameElement`,
       `fe`.`entry`                 AS `entry`,
       `fe`.`active`                AS `active`,
       `fe`.`idEntity`              AS `idEntity`,
       `fe`.`idColor`               AS `idColor`,
       `fe`.`coreType`              AS `typeEntry`
from (`fnbr_db`.`frameelement` `fe` join `fnbr_db`.`frame` on (`fe`.`idFrame` = `fnbr_db`.`frame`.`idFrame`));

